/** @type {import('next').NextConfig} */
const nextConfig = {
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  // Allow dev origin for HMR in v0 sandbox environment
  experimental: {
    allowedDevOrigins: [
      'localhost',
      'vm-850fi4q1vw38y1jov0h6gaiv.vusercontent.net',
    ],
  },
}

export default nextConfig
