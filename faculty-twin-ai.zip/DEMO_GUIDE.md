# FacultyTwin AI - Demo & User Guide

## Quick Start Demo (2 minutes)

### Step 1: Load the Demo Faculty
When you open the application, you'll see the **Setup Screen**. Click the **"Load Demo Faculty"** button in the top right corner.

This instantly loads **Dr. Rajesh Kumar** - a pre-configured Computer Science professor with:
- Communication Style: Socratic (asks guiding questions)
- Teaching Approach: Example-based (uses real-world code examples)
- Personality: Enthusiastic, patient, and humorous
- Signature Phrases: "Think about it!", "Let me break it down", "Here's a real-world example"
- Quirks: Uses hand gestures, speaks quickly about passion topics, mentions pizza analogies

### Step 2: Watch the Analysis Pipeline
Click **"Start Analysis"** to see the 5-step animated pipeline:
1. ⚡ Video Frame Extraction - Simulates analyzing lecture video frames
2. 🎙️ Speech & Tone Analysis - Detects speaking patterns and tone
3. 📚 Pedagogical Style Modeling - Learns teaching methodology
4. 🧠 Personality Vector Embedding - Creates personality profile
5. ✨ Twin Synthesis - Generates the digital twin

Watch as detected traits appear: "Enthusiastic", "Patient", "Example-Based Teaching", "Socratic Method"

### Step 3: Chat with the AI Avatar
After analysis completes, enter the **Chat Screen** where you'll see:

**Left Side: Holographic Avatar**
- An animated professor face with:
  - Breathing glow effect
  - Blinking eyes that sync with conversation
  - Audio waveform bars that pulse when speaking
  - Realistic humanoid features

**Right Side: Chat Interface**
- Text input field for questions
- Microphone button for voice questions
- Chat message history
- Avatar will speak responses using text-to-speech

### Step 4: Try These Demo Questions

Ask the avatar these questions to see authentic faculty responses:

**Teaching Style Questions:**
- "How would you explain object-oriented programming?"
- "Can you give me an example of recursion?"
- "What's the best way to debug code?"

**Personality Questions:**
- "What's your favorite programming language?"
- "How do you handle students who are struggling?"
- "Do you prefer theory or practical coding?"

**Socratic Method Questions:**
- "How do I optimize my algorithm?"
- "What should I do about this compiler error?"
- "Can you help me with my project?"

**Watch for:**
- Signature phrases appearing naturally ("Think about it!", "Let me break it down")
- Example-based answers with real code scenarios
- Patient, encouraging tone
- Humorous comments about pizza analogies
- Questions back to the student (Socratic method)

---

## How to Create Your Own Faculty Twin

### Stage 1: Setup Screen

**1. Faculty Information**
- **Name**: Full name of the faculty member
- **Department**: e.g., "Computer Science", "Mathematics"
- **Designation**: e.g., "Assistant Professor", "Lecturer"
- **Years of Experience**: How long they've been teaching
- **Specialization**: Their main teaching area (e.g., "Data Structures", "Algorithms")

**2. Teaching Configuration**
- **Communication Style**: 
  - Conversational: Friendly, informal tone
  - Formal: Professional, structured delivery
  - Socratic: Questions students to guide thinking
  - Humorous: Uses jokes and humor frequently

- **Teaching Approach**:
  - Example-based: Explains with real-world examples
  - Socratic: Asks questions for student discovery
  - Visual: Uses diagrams, flowcharts, visual metaphors

**3. Personality Traits**
Select up to 8 traits that describe the faculty:
- Enthusiastic
- Patient
- Strict
- Encouraging
- Analytical
- Creative
- Supportive
- Humorous

**4. Voice Settings**
- **Voice Type**: Choose from available system voices (Male/Female/Neutral)
- **Pitch**: Adjust voice pitch (0.5 - 2.0)
- **Speaking Rate**: Adjust speaking speed (0.5 - 2.0)

**5. Signature Phrases**
Enter 3-5 phrases the professor uses frequently:
- "Think about it!"
- "Let me break it down"
- "Here's a real-world example"
- "Any questions so far?"

**6. Quirks & Habits**
Describe unique behaviors:
- "Uses hand gestures while explaining"
- "Speaks quickly about passion topics"
- "Often mentions pizza analogies"
- "Walks around the classroom"
- "Pauses for dramatic effect"

**7. Video Upload (Optional)**
- Drag and drop or browse for lecture video files
- The system simulates extracting frames and analyzing speech patterns
- In a full deployment, this would actually analyze video for accent, pace, and style

---

### Stage 2: Analysis Screen

The 5-step pipeline simulates creating the digital twin:

1. **Video Frame Extraction** (20%)
   - Simulates analyzing video frames
   - Extracts visual cues and gestures

2. **Speech & Tone Analysis** (40%)
   - Analyzes speaking patterns
   - Detects tone, pace, and emphasis

3. **Pedagogical Style Modeling** (60%)
   - Maps teaching methodology
   - Learns question patterns
   - Understands explanation structure

4. **Personality Vector Embedding** (80%)
   - Creates personality profile
   - Maps trait combinations
   - Generates response patterns

5. **Twin Synthesis** (100%)
   - Combines all analysis
   - Generates final AI model
   - Ready for conversation

Detected traits will appear as chips, showing the AI's understanding of the faculty's personality.

---

### Stage 3: Chat with Your Faculty Twin

The digital twin is now ready to interact!

**Capabilities:**
- Answers questions like the real faculty member would
- Uses their signature phrases naturally
- Matches their communication style
- Asks guiding questions if they're Socratic
- Provides examples based on their teaching approach
- Responds with their personality traits

**Voice Features:**
- The avatar speaks every response using the configured voice
- Click the microphone to ask questions by voice
- The avatar's face animates while speaking
- Audio waveforms pulse to show speaking activity

**Testing the Twin:**
- Ask open-ended questions about their subject
- Request explanations of concepts
- Ask for advice on learning
- See how they handle student questions
- Notice signature phrases appearing

---

## Architecture Overview

### Three Components:

**1. Setup Component** (`SetupStage.tsx`)
- Faculty profile configuration
- Form validation
- Video upload handling (simulated)
- Demo data loading

**2. Analysis Component** (`AnalysisStage.tsx`)
- 5-step animated pipeline
- Progress bar visualization
- Trait detection simulation
- Transition to chat

**3. Chat Component** (`ChatStage.tsx`)
- Message history
- Voice input/output
- Real-time responses
- Conversation management

**4. Avatar Component** (`HolographicAvatar.tsx`)
- Animated face rendering (SVG)
- Breathing glow effect
- Eye blinking sync
- Audio waveform visualization
- Voice-controlled lip sync simulation

---

## Technical Details

### AI Integration
- **Backend**: Claude 3.5 Sonnet API
- **System Prompt**: Dynamically generated based on faculty profile
- **Includes**: Communication style, teaching approach, personality traits, signature phrases
- **Endpoint**: `/api/chat` (Server-side API route)

### Voice Technology
- **Text-to-Speech**: Web Speech API (browser-native, no downloads)
- **Speech Recognition**: Web Speech API for voice input
- **Voice Options**: System voices available on user's device
- **Languages**: English and others depending on OS

### Browser Compatibility
- Chrome/Edge: Full support (all features)
- Firefox: Full support
- Safari: Full support (iOS 14.5+)
- Mobile browsers: Full support with voice limitations

---

## Customization Tips

### To Create a More Accurate Twin:

1. **Upload Real Lecture Videos**
   - In production, these are analyzed for speech patterns
   - Currently simulated for demo purposes

2. **Fine-Tune Signature Phrases**
   - Include unique catchphrases
   - Add specific terminology they use
   - Include their favorite idioms

3. **Describe Quirks Accurately**
   - Physical mannerisms
   - Speech patterns
   - Pacing and pauses
   - Emotional expressions

4. **Test and Refine**
   - Ask questions and see responses
   - Adjust traits if needed
   - Try different communication styles
   - Verify teaching approach comes through

---

## Use Cases

### 1. Student Learning Support
- Get help outside office hours
- Practice asking questions
- Review concepts multiple times
- Personalized learning style

### 2. Faculty Showcase
- Demonstrate teaching style
- Onboard new courses
- Share expertise broadly
- Create asynchronous support

### 3. Content Creation
- Generate lecture summaries
- Create study guides
- Answer FAQs
- Build knowledge bases

### 4. Accessibility
- Provide multiple access formats
- Support different learning preferences
- Enable voice interaction
- Accommodate scheduling needs

---

## Troubleshooting

### Avatar Not Speaking
- Check browser allows audio playback
- Enable audio in browser permissions
- Select a voice in the setup screen
- Test system speakers/audio

### Responses Don't Match Faculty Style
- Verify signature phrases were entered
- Check communication style selection
- Ensure personality traits are accurate
- Provide more specific quirk descriptions

### Voice Recognition Not Working
- Check microphone permissions
- Use HTTPS or localhost
- Try Chrome for best support
- Ensure microphone is working

### Chat Takes Long to Respond
- API may be processing (normal, takes 2-5 seconds)
- Check internet connection
- Verify ANTHROPIC_API_KEY is set
- Try shorter questions

---

## Environment Setup (For Developers)

### Required
```bash
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxx
```

### Optional Customization
Modify `lib/voice-config.ts` to:
- Add new voice options
- Change default speaking rate
- Adjust pitch levels
- Modify breathing animation speed

Edit `lib/demo-faculty.ts` to:
- Change demo faculty profile
- Add multiple demo profiles
- Pre-load institution examples
- Customize default traits

---

## Next Steps

1. **Load Demo** - Click "Load Demo Faculty" to see it in action
2. **Create Twin** - Set up your own faculty profile
3. **Analyze** - Run the analysis pipeline
4. **Chat** - Interact with your faculty's AI twin
5. **Refine** - Go back and adjust settings if needed

---

Enjoy creating and interacting with your Faculty Twin AI!
