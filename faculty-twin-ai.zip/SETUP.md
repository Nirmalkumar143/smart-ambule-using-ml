# FacultyTwin AI - Setup Guide

## Quick Start

### 1. Get Your Anthropic API Key
- Go to [console.anthropic.com](https://console.anthropic.com)
- Sign up or log in
- Navigate to API Keys
- Create a new API key
- Copy the key

### 2. Set Environment Variable
Edit `.env.local` in the project root and replace the placeholder:

```env
ANTHROPIC_API_KEY=sk-ant-v0-YOUR_ACTUAL_KEY_HERE
```

### 3. Start the App
```bash
pnpm dev
```

The app will be available at `http://localhost:3000`

## Features

### Setup Stage
- Configure faculty profile (name, department, designation, years of experience)
- Select communication style: Conversational, Formal, Socratic, or Humorous
- Choose teaching approach: Example-based, Socratic, or Visual
- Add signature phrases (unique phrases the faculty uses)
- Describe quirks and teaching habits
- Configure voice preferences

### Analysis Stage
- Watch the 5-step animated pipeline:
  1. Video frame extraction
  2. Speech & tone analysis
  3. Pedagogical style modeling
  4. Personality vector embedding
  5. Twin synthesis
- Visual progress indicators show completion

### Chat Stage
- Interact with the faculty digital twin
- The AI avatar responds using the faculty's:
  - Communication style
  - Teaching approach
  - Personality traits
  - Signature phrases
- Voice input/output support (browser-based Web Speech API)
- Avatar shows:
  - Animated blinking eyes
  - Breathing glow effect
  - Audio waveforms when speaking

## Demo Faculty
Click "Load Demo Faculty" to instantly load Dr. Rajesh Kumar, a pre-configured computer science professor. This lets you test all features immediately without setting up a new profile.

## Browser Support
- **Voice Features**: Chrome, Edge, Safari (10+), Opera
- **Avatar Animations**: All modern browsers
- **Web Speech API**: Works best in Chrome/Edge

## Customization

### Change Avatar Colors
Edit `components/HolographicAvatar.tsx` and modify the SVG fill colors:
- `bg-blue-500` for glow color
- `fill-blue-300` for accent colors

### Adjust Voice Settings
Edit `lib/voice-config.ts` to change:
- Default speech rate
- Default pitch
- Voice selection

### Modify Claude Behavior
Edit `lib/prompt-generator.ts` to adjust how the AI:
- Incorporates personality traits
- Uses signature phrases
- Follows the teaching approach
