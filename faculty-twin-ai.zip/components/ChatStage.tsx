'use client';

import React, { useState, useRef, useEffect } from 'react';
import { FacultyProfile, ChatMessage } from '@/lib/types';
import { HolographicAvatar } from './HolographicAvatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { useVoiceSynthesis } from '@/hooks/use-voice-synthesis';
import { useVoiceRecognition } from '@/hooks/use-voice-recognition';

interface ChatStageProps {
  faculty: FacultyProfile;
  messages: ChatMessage[];
  onAddMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => void;
}

export function ChatStage({ faculty, messages, onAddMessage }: ChatStageProps) {
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [lastResponse, setLastResponse] = useState('');

  const { speak, isSpeaking } = useVoiceSynthesis({
    voiceName: faculty.voicePreference?.voiceType,
    pitch: faculty.voicePreference?.pitch,
    rate: faculty.voicePreference?.rate,
    volume: faculty.voicePreference?.volume
  });

  const { startListening, stopListening, isListening, transcript, isBrowserSupported } = useVoiceRecognition();

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (transcript && !isListening) {
      setInputValue(transcript);
    }
  }, [transcript, isListening]);

  const handleSendMessage = async (messageText: string) => {
    if (!messageText.trim()) return;

    const userMessage: Omit<ChatMessage, 'id' | 'timestamp'> = {
      role: 'user',
      content: messageText,
      isVoice: false
    };

    onAddMessage(userMessage);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          message: messageText,
          faculty: faculty,
          conversationHistory: messages.map(m => ({
            role: m.role,
            content: m.content
          }))
        })
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();
      const assistantResponse = data.message;

      setLastResponse(assistantResponse);
      onAddMessage({
        role: 'assistant',
        content: assistantResponse,
        isVoice: false
      });

      // Speak the response
      speak(assistantResponse);
    } catch (error) {
      console.error('Chat error:', error);
      const errorMessage = 'Sorry, I encountered an error. Please make sure your ANTHROPIC_API_KEY is set.';
      onAddMessage({
        role: 'assistant',
        content: errorMessage,
        isVoice: false
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleVoiceInput = () => {
    if (isListening) {
      stopListening();
    } else {
      startListening();
    }
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-4">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-120px)]">
        {/* Avatar Panel */}
        <div className="lg:col-span-1 flex items-center justify-center bg-gradient-to-b from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 rounded-lg p-4">
          <HolographicAvatar
            isTyping={isLoading}
            isSpeaking={isSpeaking}
            name={faculty.name}
          />
        </div>

        {/* Chat Panel */}
        <div className="lg:col-span-2 flex flex-col rounded-lg border border-border bg-card">
          {/* Header */}
          <div className="border-b border-border p-4">
            <h2 className="text-2xl font-bold">{faculty.name}</h2>
            <p className="text-sm text-foreground/60">
              {faculty.designation} • {faculty.department}
            </p>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="flex items-center justify-center h-full text-center">
                <div className="space-y-4">
                  <p className="text-lg font-semibold">Welcome to your Faculty Twin chat!</p>
                  <p className="text-foreground/60">
                    Ask {faculty.name} any questions related to {faculty.specialisation}.
                  </p>
                  <p className="text-sm text-foreground/50">
                    {faculty.communicationStyle === 'Socratic'
                      ? 'Expect thought-provoking questions rather than direct answers.'
                      : 'Get direct, knowledgeable responses from your faculty.'}
                  </p>
                </div>
              </div>
            ) : (
              messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <Card
                    className={`max-w-xs lg:max-w-md px-4 py-2 ${
                      message.role === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted text-foreground'
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap break-words">{message.content}</p>
                    <p className={`text-xs mt-1 ${
                      message.role === 'user'
                        ? 'text-primary-foreground/70'
                        : 'text-foreground/50'
                    }`}>
                      {message.timestamp.toLocaleTimeString([], {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                  </Card>
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex justify-start">
                <Card className="bg-muted text-foreground px-4 py-2">
                  <div className="flex gap-2">
                    <div className="w-2 h-2 rounded-full bg-foreground/50 animate-bounce"></div>
                    <div className="w-2 h-2 rounded-full bg-foreground/50 animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 rounded-full bg-foreground/50 animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </Card>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="border-t border-border p-4 space-y-3">
            <div className="flex gap-2">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === 'Enter' && !isLoading) {
                    handleSendMessage(inputValue);
                  }
                }}
                placeholder="Ask a question..."
                disabled={isLoading}
                className="flex-1 bg-background"
              />
              <Button
                onClick={() => handleSendMessage(inputValue)}
                disabled={isLoading || !inputValue.trim()}
                className="px-6"
              >
                Send
              </Button>
            </div>

            {isBrowserSupported && (
              <div className="flex gap-2 text-xs">
                <Button
                  onClick={handleVoiceInput}
                  variant={isListening ? 'destructive' : 'outline'}
                  size="sm"
                  className="flex-1"
                >
                  {isListening ? '🎤 Stop Listening' : '🎤 Voice Input'}
                </Button>
                {isSpeaking && (
                  <span className="flex items-center text-sm text-foreground/60">
                    Faculty is speaking...
                  </span>
                )}
              </div>
            )}

            <div className="text-xs text-foreground/50 text-center">
              Tip: Press Enter to send or use the Voice Input button
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
