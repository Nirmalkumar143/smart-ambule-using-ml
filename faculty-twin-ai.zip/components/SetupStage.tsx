'use client';

import React, { useState } from 'react';
import { FacultyProfile } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';

interface SetupStageProps {
  onComplete: (faculty: FacultyProfile) => void;
  onLoadDemo: () => void;
  existingFaculty?: FacultyProfile;
}

const COMMUNICATION_STYLES = ['Conversational', 'Formal', 'Socratic', 'Humorous'] as const;
const TEACHING_APPROACHES = ['Example-based', 'Socratic', 'Visual'] as const;
const PERSONALITY_TRAITS = [
  'Patient', 'Enthusiastic', 'Analytical', 'Encouraging',
  'Detail-oriented', 'Mentor-like', 'Inspiring', 'Collaborative'
];

export function SetupStage({ onComplete, onLoadDemo, existingFaculty }: SetupStageProps) {
  const [faculty, setFaculty] = useState<FacultyProfile>(
    existingFaculty || {
      id: Date.now().toString(),
      name: '',
      department: '',
      designation: '',
      yearsOfExperience: 0,
      specialisation: '',
      communicationStyle: 'Socratic',
      teachingApproach: 'Example-based',
      personalityTraits: [],
      signaturePhrases: [''],
      quirksAndHabits: '',
      voicePreference: {
        voiceType: 'Google UK English Male',
        pitch: 1.0,
        rate: 0.9,
        volume: 1.0
      }
    }
  );

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFaculty(prev => ({
      ...prev,
      [name]: name === 'yearsOfExperience' ? parseInt(value) || 0 : value
    }));
  };

  const handleTraitToggle = (trait: string) => {
    setFaculty(prev => ({
      ...prev,
      personalityTraits: prev.personalityTraits.includes(trait)
        ? prev.personalityTraits.filter(t => t !== trait)
        : [...prev.personalityTraits, trait]
    }));
  };

  const handlePhrasesChange = (index: number, value: string) => {
    const newPhrases = [...faculty.signaturePhrases];
    newPhrases[index] = value;
    setFaculty(prev => ({
      ...prev,
      signaturePhrases: newPhrases
    }));
  };

  const addPhrase = () => {
    setFaculty(prev => ({
      ...prev,
      signaturePhrases: [...prev.signaturePhrases, '']
    }));
  };

  const removePhrase = (index: number) => {
    setFaculty(prev => ({
      ...prev,
      signaturePhrases: prev.signaturePhrases.filter((_, i) => i !== index)
    }));
  };

  const isFormValid = faculty.name && faculty.department && faculty.specialisation && faculty.signaturePhrases.some(p => p.trim());

  return (
    <div className="w-full max-w-4xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold">Faculty Twin Setup</h1>
        <p className="text-foreground/60">Configure your digital faculty twin profile</p>
      </div>

      <div className="flex gap-4 mb-6">
        <Button 
          onClick={onLoadDemo}
          variant="outline"
          className="flex-1"
        >
          Load Demo Faculty
        </Button>
      </div>

      <div className="grid gap-6">
        {/* Basic Information */}
        <Card className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold">Basic Information</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Faculty Name *</label>
              <Input
                name="name"
                value={faculty.name}
                onChange={handleInputChange}
                placeholder="e.g., Dr. Rajesh Kumar"
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Department *</label>
              <Input
                name="department"
                value={faculty.department}
                onChange={handleInputChange}
                placeholder="e.g., Computer Science"
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Designation</label>
              <Input
                name="designation"
                value={faculty.designation}
                onChange={handleInputChange}
                placeholder="e.g., Associate Professor"
                className="bg-background"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Years of Experience</label>
              <Input
                name="yearsOfExperience"
                type="number"
                value={faculty.yearsOfExperience}
                onChange={handleInputChange}
                placeholder="e.g., 12"
                className="bg-background"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Specialisation *</label>
            <Input
              name="specialisation"
              value={faculty.specialisation}
              onChange={handleInputChange}
              placeholder="e.g., Artificial Intelligence & Machine Learning"
              className="bg-background"
            />
          </div>
        </Card>

        {/* Teaching Style */}
        <Card className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold">Teaching Style</h2>

          <div className="space-y-3">
            <label className="text-sm font-medium">Communication Style</label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              {COMMUNICATION_STYLES.map(style => (
                <button
                  key={style}
                  onClick={() => setFaculty(prev => ({ ...prev, communicationStyle: style }))}
                  className={`px-4 py-2 rounded-lg border-2 transition-all ${
                    faculty.communicationStyle === style
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-border bg-background hover:border-primary/50'
                  }`}
                >
                  {style}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-3">
            <label className="text-sm font-medium">Teaching Approach</label>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {TEACHING_APPROACHES.map(approach => (
                <button
                  key={approach}
                  onClick={() => setFaculty(prev => ({ ...prev, teachingApproach: approach }))}
                  className={`px-4 py-2 rounded-lg border-2 transition-all ${
                    faculty.teachingApproach === approach
                      ? 'border-primary bg-primary text-primary-foreground'
                      : 'border-border bg-background hover:border-primary/50'
                  }`}
                >
                  {approach}
                </button>
              ))}
            </div>
          </div>
        </Card>

        {/* Personality */}
        <Card className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold">Personality Traits</h2>
          <p className="text-sm text-foreground/60">Select traits that describe this faculty member</p>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {PERSONALITY_TRAITS.map(trait => (
              <button
                key={trait}
                onClick={() => handleTraitToggle(trait)}
                className={`px-3 py-2 rounded-lg border-2 transition-all text-sm ${
                  faculty.personalityTraits.includes(trait)
                    ? 'border-primary bg-primary text-primary-foreground'
                    : 'border-border bg-background hover:border-primary/50'
                }`}
              >
                {trait}
              </button>
            ))}
          </div>
        </Card>

        {/* Signature Phrases */}
        <Card className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold">Signature Phrases *</h2>
          <p className="text-sm text-foreground/60">Add unique phrases this faculty member often uses</p>
          
          <div className="space-y-3">
            {faculty.signaturePhrases.map((phrase, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  value={phrase}
                  onChange={(e) => handlePhrasesChange(index, e.target.value)}
                  placeholder={`e.g., "Think about it from first principles"`}
                  className="bg-background flex-1"
                />
                {faculty.signaturePhrases.length > 1 && (
                  <Button
                    onClick={() => removePhrase(index)}
                    variant="destructive"
                    size="sm"
                  >
                    Remove
                  </Button>
                )}
              </div>
            ))}
          </div>
          
          <Button 
            onClick={addPhrase}
            variant="outline"
            className="w-full"
          >
            + Add Phrase
          </Button>
        </Card>

        {/* Quirks */}
        <Card className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold">Quirks & Habits</h2>
          <p className="text-sm text-foreground/60">Describe unique habits, gestures, or mannerisms</p>
          
          <textarea
            name="quirksAndHabits"
            value={faculty.quirksAndHabits}
            onChange={handleInputChange}
            placeholder="e.g., 'Often pauses to let ideas sink in, uses hand gestures, walks around classroom...'"
            className="w-full h-32 p-3 rounded-lg border border-border bg-background resize-none"
          />
        </Card>

        {/* Voice Preferences */}
        <Card className="p-6 space-y-4">
          <h2 className="text-2xl font-semibold">Voice Preferences</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Voice Type</label>
              <select
                value={faculty.voicePreference?.voiceType || ''}
                onChange={(e) => setFaculty(prev => ({
                  ...prev,
                  voicePreference: {
                    ...prev.voicePreference,
                    voiceType: e.target.value
                  }
                }))}
                className="w-full px-3 py-2 rounded-lg border border-border bg-background"
              >
                <option>Google UK English Male</option>
                <option>Google US English</option>
                <option>Google UK English Female</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Pitch ({faculty.voicePreference?.pitch})</label>
              <input
                type="range"
                min="0.5"
                max="2"
                step="0.1"
                value={faculty.voicePreference?.pitch || 1}
                onChange={(e) => setFaculty(prev => ({
                  ...prev,
                  voicePreference: {
                    ...prev.voicePreference,
                    pitch: parseFloat(e.target.value)
                  }
                }))}
                className="w-full"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Speed ({faculty.voicePreference?.rate})</label>
              <input
                type="range"
                min="0.5"
                max="2"
                step="0.1"
                value={faculty.voicePreference?.rate || 1}
                onChange={(e) => setFaculty(prev => ({
                  ...prev,
                  voicePreference: {
                    ...prev.voicePreference,
                    rate: parseFloat(e.target.value)
                  }
                }))}
                className="w-full"
              />
            </div>
          </div>
        </Card>

        {/* Action Buttons */}
        <div className="flex gap-4 pt-4">
          <Button 
            onClick={() => isFormValid && onComplete(faculty)}
            disabled={!isFormValid}
            className="flex-1 py-6 text-lg"
            size="lg"
          >
            Continue to Analysis
          </Button>
        </div>
      </div>
    </div>
  );
}
