'use client';

import React, { useEffect, useRef, useState } from 'react';

interface HolographicAvatarProps {
  isTyping?: boolean;
  isSpeaking?: boolean;
  name?: string;
}

export function HolographicAvatar({ isTyping = false, isSpeaking = false, name = 'Faculty Twin' }: HolographicAvatarProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [blinkState, setBlinkState] = useState(false);
  const animationRef = useRef<number>();

  useEffect(() => {
    const blink = setInterval(() => {
      setBlinkState(prev => !prev);
    }, 3000);

    return () => clearInterval(blink);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrame = 0;

    const drawAvatar = () => {
      const width = canvas.width;
      const height = canvas.height;

      // Clear canvas
      ctx.fillStyle = 'rgba(15, 23, 42, 0)';
      ctx.fillRect(0, 0, width, height);

      // Draw holographic glow effect
      const gradient = ctx.createRadialGradient(width / 2, height / 2, 30, width / 2, height / 2, Math.max(width, height));
      const glowIntensity = isSpeaking ? 0.4 : 0.2;
      gradient.addColorStop(0, `rgba(59, 130, 246, ${0.3 + glowIntensity * Math.sin(animationFrame * 0.05)})`);
      gradient.addColorStop(0.5, `rgba(59, 130, 246, ${0.1 + glowIntensity * 0.5})`);
      gradient.addColorStop(1, 'rgba(59, 130, 246, 0)');

      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, width, height);

      // Draw face circle (center)
      const centerX = width / 2;
      const centerY = height / 2;
      const faceRadius = 80;

      // Face gradient
      const faceGradient = ctx.createRadialGradient(
        centerX - 20, centerY - 30, 20,
        centerX, centerY, faceRadius
      );
      faceGradient.addColorStop(0, '#e0f2fe');
      faceGradient.addColorStop(1, '#bfdbfe');
      ctx.fillStyle = faceGradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, faceRadius, 0, Math.PI * 2);
      ctx.fill();

      // Face outline glow
      ctx.strokeStyle = `rgba(59, 130, 246, 0.6)`;
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(centerX, centerY, faceRadius, 0, Math.PI * 2);
      ctx.stroke();

      // Eyes
      const eyeY = centerY - 15;
      const eyeRadius = 8;
      const eyeSpacing = 25;

      // Left eye
      ctx.fillStyle = '#1e40af';
      ctx.beginPath();
      ctx.arc(centerX - eyeSpacing, eyeY, eyeRadius, 0, Math.PI * 2);
      ctx.fill();

      // Right eye
      ctx.beginPath();
      ctx.arc(centerX + eyeSpacing, eyeY, eyeRadius, 0, Math.PI * 2);
      ctx.fill();

      // Blink effect
      if (blinkState) {
        ctx.strokeStyle = '#1e40af';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(centerX - eyeSpacing - eyeRadius, eyeY);
        ctx.lineTo(centerX - eyeSpacing + eyeRadius, eyeY);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(centerX + eyeSpacing - eyeRadius, eyeY);
        ctx.lineTo(centerX + eyeSpacing + eyeRadius, eyeY);
        ctx.stroke();
      } else {
        // Pupils with shine
        ctx.fillStyle = 'white';
        ctx.beginPath();
        ctx.arc(centerX - eyeSpacing + 3, eyeY - 2, 2, 0, Math.PI * 2);
        ctx.fill();

        ctx.beginPath();
        ctx.arc(centerX + eyeSpacing + 3, eyeY - 2, 2, 0, Math.PI * 2);
        ctx.fill();
      }

      // Mouth
      const mouthY = centerY + 20;
      ctx.strokeStyle = '#dc2626';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(centerX, mouthY, 12, 0, Math.PI, false);
      ctx.stroke();

      // Animated mouth movement when speaking
      if (isSpeaking) {
        const mouthOpen = Math.abs(Math.sin(animationFrame * 0.1)) * 8;
        ctx.fillStyle = '#fca5a5';
        ctx.beginPath();
        ctx.ellipse(centerX, mouthY + 5, 10, mouthOpen, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // Audio waveform bars (visible when speaking)
      if (isSpeaking) {
        const barWidth = 3;
        const barSpacing = 4;
        const numBars = 5;
        const waveHeight = 40;

        for (let i = 0; i < numBars; i++) {
          const barX = centerX - (numBars * (barWidth + barSpacing)) / 2 + i * (barWidth + barSpacing);
          const barHeight = Math.abs(Math.sin(animationFrame * 0.08 + i * 0.3)) * waveHeight + 5;

          ctx.fillStyle = `rgba(59, 130, 246, ${0.5 + 0.5 * Math.sin(animationFrame * 0.08 + i * 0.3)})`;
          ctx.fillRect(barX, centerY + faceRadius + 20 - barHeight / 2, barWidth, barHeight);
        }
      }

      // Breathing glow animation
      const breathing = Math.sin(animationFrame * 0.03) * 0.3 + 0.7;
      ctx.strokeStyle = `rgba(59, 130, 246, ${breathing * 0.4})`;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(centerX, centerY, faceRadius + 10 + Math.sin(animationFrame * 0.03) * 5, 0, Math.PI * 2);
      ctx.stroke();

      animationFrame++;
      animationRef.current = requestAnimationFrame(drawAvatar);
    };

    animationRef.current = requestAnimationFrame(drawAvatar);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isSpeaking, blinkState]);

  return (
    <div className="flex flex-col items-center gap-4">
      <canvas
        ref={canvasRef}
        width={400}
        height={400}
        className="w-full max-w-sm rounded-lg"
      />
      
      <div className="text-center">
        <h3 className="text-xl font-semibold">{name}</h3>
        {isTyping && (
          <p className="text-sm text-foreground/60 mt-1">
            <span className="inline-block">Thinking</span>
            <span className="inline-block ml-1">
              <span className="animate-bounce">.</span>
              <span className="animate-bounce" style={{ animationDelay: '0.1s' }}>.</span>
              <span className="animate-bounce" style={{ animationDelay: '0.2s' }}>.</span>
            </span>
          </p>
        )}
        {isSpeaking && !isTyping && (
          <p className="text-sm text-green-600 dark:text-green-400 mt-1">Speaking...</p>
        )}
      </div>
    </div>
  );
}
