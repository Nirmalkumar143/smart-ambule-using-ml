'use client';

import React, { useState, useEffect } from 'react';
import { FacultyProfile, AnalysisStep } from '@/lib/types';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface AnalysisStageProps {
  faculty: FacultyProfile;
  onComplete: () => void;
}

const ANALYSIS_STEPS: AnalysisStep[] = [
  {
    step: 1,
    name: 'Video Frame Extraction',
    description: 'Extracting key frames from lecture videos...',
    progress: 0,
    complete: false,
    detectedTraits: []
  },
  {
    step: 2,
    name: 'Speech & Tone Analysis',
    description: 'Analyzing speech patterns, tone, and accent...',
    progress: 0,
    complete: false,
    detectedTraits: []
  },
  {
    step: 3,
    name: 'Pedagogical Style Modelling',
    description: 'Mapping teaching methodology and classroom approach...',
    progress: 0,
    complete: false,
    detectedTraits: []
  },
  {
    step: 4,
    name: 'Personality Vector Embedding',
    description: 'Creating personality and behavior embeddings...',
    progress: 0,
    complete: false,
    detectedTraits: []
  },
  {
    step: 5,
    name: 'Twin Synthesis',
    description: 'Synthesizing digital twin with all parameters...',
    progress: 0,
    complete: false,
    detectedTraits: []
  }
];

export function AnalysisStage({ faculty, onComplete }: AnalysisStageProps) {
  const [steps, setSteps] = useState<AnalysisStep[]>(ANALYSIS_STEPS);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  useEffect(() => {
    const simulateAnalysis = async () => {
      setIsAnalyzing(true);

      for (let i = 0; i < steps.length; i++) {
        // Simulate progressive analysis
        for (let progress = 0; progress <= 100; progress += Math.random() * 30) {
          await new Promise(resolve => setTimeout(resolve, 100));
          
          setSteps(prev => {
            const newSteps = [...prev];
            newSteps[i] = {
              ...newSteps[i],
              progress: Math.min(progress, 100)
            };
            return newSteps;
          });
        }

        // Mark as complete
        await new Promise(resolve => setTimeout(resolve, 300));
        
        setSteps(prev => {
          const newSteps = [...prev];
          newSteps[i] = {
            ...newSteps[i],
            progress: 100,
            complete: true,
            detectedTraits: getDetectedTraitsForStep(i, faculty)
          };
          return newSteps;
        });

        setCurrentStepIndex(i + 1);
      }

      setIsAnalyzing(false);
    };

    simulateAnalysis();
  }, []);

  const getDetectedTraitsForStep = (stepIndex: number, faculty: FacultyProfile): string[] => {
    const traitMap = {
      0: ['Formal Presentation', 'Structured Delivery', 'Clear Enunciation'],
      1: ['Patient Tone', 'Enthusiastic Delivery', 'Encouraging Feedback'],
      2: ['Interactive Method', 'Conceptual Approach', 'Example Usage'],
      3: faculty.personalityTraits.slice(0, 3),
      4: ['Twin Optimized', 'Parameters Aligned', 'Ready for Chat']
    };
    return traitMap[stepIndex as keyof typeof traitMap] || [];
  };

  const allComplete = steps.every(s => s.complete);

  return (
    <div className="w-full max-w-4xl mx-auto p-6 space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-4xl font-bold">Faculty Twin Analysis</h1>
        <p className="text-foreground/60">Processing faculty profile data...</p>
      </div>

      <div className="space-y-6">
        {steps.map((step, index) => (
          <Card key={step.step} className="p-6">
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${
                  step.complete
                    ? 'bg-green-500 text-white'
                    : index <= currentStepIndex
                    ? 'bg-blue-500 text-white animate-pulse'
                    : 'bg-border text-foreground/50'
                }`}>
                  {step.complete ? '✓' : step.step}
                </div>

                <div className="flex-1">
                  <h3 className="text-lg font-semibold">{step.name}</h3>
                  <p className="text-sm text-foreground/60">{step.description}</p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs font-medium text-foreground/70">Progress</span>
                  <span className="text-xs font-bold">{Math.round(step.progress)}%</span>
                </div>
                <div className="w-full bg-border rounded-full h-2 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all duration-300"
                    style={{ width: `${step.progress}%` }}
                  />
                </div>
              </div>

              {step.detectedTraits && step.detectedTraits.length > 0 && (
                <div className="pt-2">
                  <p className="text-xs font-medium mb-2 text-foreground/70">Detected Traits</p>
                  <div className="flex flex-wrap gap-2">
                    {step.detectedTraits.map((trait, idx) => (
                      <span
                        key={idx}
                        className="inline-block px-3 py-1 bg-blue-100 text-blue-800 text-xs rounded-full font-medium dark:bg-blue-900 dark:text-blue-100"
                      >
                        {trait}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </Card>
        ))}
      </div>

      {allComplete && (
        <Card className="p-8 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-950 dark:to-blue-950 border-green-200 dark:border-green-800">
          <div className="space-y-4 text-center">
            <div className="text-5xl">✨</div>
            <h2 className="text-2xl font-bold">Twin Synthesis Complete!</h2>
            <p className="text-foreground/70">
              Your {faculty.name} digital twin is ready for conversation. 
              The AI has learned their teaching style, personality, and unique mannerisms.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 text-left">
              <div className="bg-white dark:bg-background p-4 rounded-lg border border-border">
                <p className="text-sm font-medium text-foreground/70">Communication Style</p>
                <p className="text-lg font-semibold mt-1">{faculty.communicationStyle}</p>
              </div>
              <div className="bg-white dark:bg-background p-4 rounded-lg border border-border">
                <p className="text-sm font-medium text-foreground/70">Teaching Approach</p>
                <p className="text-lg font-semibold mt-1">{faculty.teachingApproach}</p>
              </div>
              <div className="bg-white dark:bg-background p-4 rounded-lg border border-border">
                <p className="text-sm font-medium text-foreground/70">Traits Embedded</p>
                <p className="text-lg font-semibold mt-1">{faculty.personalityTraits.length}</p>
              </div>
            </div>

            <Button 
              onClick={onComplete}
              className="w-full md:w-auto mt-6 px-8 py-6 text-lg"
              size="lg"
            >
              Start Chat with Twin
            </Button>
          </div>
        </Card>
      )}
    </div>
  );
}
