# FacultyTwin AI - Digital Twin Platform for Faculty

Create an AI avatar of your professor with authentic teaching style, personality, and communication patterns.

## What is FacultyTwin AI?

FacultyTwin AI is a web platform that creates a digital twin of college faculty members. Students can interact with an animated AI avatar that:

- **Speaks like your professor** - Uses signature phrases and communication style
- **Teaches like your professor** - Follows their teaching methodology
- **Acts like your professor** - Displays their personality traits and quirks
- **Available 24/7** - Students can learn anytime, anywhere
- **Voice enabled** - Ask questions by typing or speaking
- **Responds naturally** - Powered by Claude AI with custom personality injection

## Quick Start (2 minutes)

### 1. Open the Application
Navigate to the web app in your browser.

### 2. Load Demo Faculty
Click **"Load Demo Faculty"** button to instantly load Dr. Rajesh Kumar (Computer Science Professor) with pre-configured settings.

### 3. Start Analysis
Click **"Start Analysis"** to run the 5-step pipeline:
- Video Frame Extraction
- Speech & Tone Analysis
- Pedagogical Style Modeling
- Personality Vector Embedding
- Twin Synthesis

### 4. Chat with the Avatar
Ask questions in the chat interface. The animated avatar will:
- Read your question
- Think like your professor
- Respond with their teaching style
- Speak the answer using voice synthesis
- Display animated reactions

## Three-Stage Pipeline

### Stage 1: Setup
Configure the faculty profile with:
- Basic information (name, department, experience)
- Communication style (Conversational/Formal/Socratic/Humorous)
- Teaching approach (Example-based/Socratic/Visual)
- Personality traits selection
- Voice preferences (pitch, speed, voice type)
- Signature phrases they use
- Unique quirks and habits
- Optional lecture video upload

### Stage 2: Analysis
Watch the animated 5-step pipeline that:
- Extracts and analyzes video content
- Detects speech patterns and tone
- Models teaching methodology
- Embeds personality vectors
- Synthesizes the digital twin

Detected traits appear as chips showing the AI's understanding of the faculty.

### Stage 3: Chat
Interact with the faculty twin through:
- Text-based questions
- Voice input via microphone
- Voice output via avatar speech
- Animated holographic avatar
- Persistent message history

## Key Features

### 🎓 Authentic Faculty Representation
- Custom system prompt injecting faculty personality
- Signature phrases appear naturally in responses
- Teaching style reflected in explanations
- Communication pattern matched

### 🎙️ Voice Technology
- Text-to-speech for avatar responses
- Speech recognition for voice questions
- Configurable voice type, pitch, and speed
- Real-time audio waveform visualization

### 👁️ Animated Avatar
- Holographic face design
- Breathing glow effect
- Eye blinking synchronized with responses
- Mouth movement during speech
- Audio waveform bar animation

### 📱 Responsive Design
- Desktop: Side-by-side avatar and chat
- Mobile: Stacked layout with full functionality
- Touch-friendly interface
- Cross-browser support

### 🧠 AI-Powered Responses
- Claude 3.5 Sonnet API backend
- Context-aware conversations
- Personality-consistent answers
- Teaching methodology applied

### 💾 Session Management
- Conversation history stored locally
- Faculty profile persistence
- Resume conversations
- No server-side storage required

## Demo Faculty Profile

**Dr. Rajesh Kumar** - Computer Science
- **Experience**: 12 years of teaching
- **Communication Style**: Socratic (asks guiding questions)
- **Teaching Approach**: Example-based (uses real code)
- **Personality**: Enthusiastic, patient, humorous
- **Voice**: Deep, confident, moderate pace
- **Signature Phrases**: "Think about it!", "Let me break it down"
- **Quirks**: Hand gestures, pizza analogies, quick on passion topics

Try asking:
```
How would you explain recursion to a beginner?
Can you give me a real-world example of OOP?
What's the best way to approach debugging?
```

## Use Cases

### For Students
- **24/7 Learning Support** - Ask questions anytime
- **Multiple Attempts** - Practice without judgment
- **Personalized Style** - Learn from your professor's method
- **Accessibility** - Voice input/output for diverse needs

### For Faculty
- **Asynchronous Support** - Reduce office hour load
- **Demonstration Tool** - Show institutional innovation
- **Content Repository** - Build FAQ knowledge base
- **Teaching Showcase** - Display expertise broadly

### For Institutions
- **Student Retention** - Improved support systems
- **Innovation Demo** - Show education technology advancement
- **Faculty Documentation** - Preserve teaching expertise
- **Scalable Learning** - Serve more students efficiently

## Technical Stack

- **Frontend**: Next.js 16, React 19, TypeScript, Tailwind CSS
- **Backend**: Claude API (Anthropic)
- **Voice**: Web Speech API (browser-native)
- **State**: Context API + localStorage
- **Storage**: Client-side (no database required)

## Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- Anthropic API key (for production)
- Microphone/speakers (for voice features)

### Setup

1. **Clone or Download** the project

2. **Install Dependencies**
   ```bash
   pnpm install
   # or: npm install, yarn install, bun install
   ```

3. **Configure API Key**
   Create `.env.local`:
   ```
   ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx
   ```
   Get your key from [console.anthropic.com](https://console.anthropic.com)

4. **Run Development Server**
   ```bash
   pnpm dev
   # or: npm run dev, yarn dev, bun dev
   ```

5. **Open Browser**
   Navigate to `http://localhost:3000`

### Usage

1. Click **"Load Demo Faculty"** to see instant demo
2. Or fill out setup form to create your own faculty twin
3. Click **"Start Analysis"** to initialize
4. Begin chatting in the chat interface

## Project Structure

```
/app
  /api/chat          - Claude API integration
  /layout.tsx        - Root layout with provider
  /page.tsx          - Main application page

/components
  SetupStage.tsx     - Faculty profile configuration
  AnalysisStage.tsx  - Pipeline visualization
  ChatStage.tsx      - Conversation interface
  HolographicAvatar.tsx - Animated avatar

/lib
  faculty-context.tsx    - Global state management
  types.ts              - TypeScript interfaces
  prompt-generator.ts   - System prompt creation
  voice-config.ts       - Voice settings
  demo-faculty.ts       - Pre-configured examples

/hooks
  use-faculty-state.ts  - Faculty profile hook
  use-voice-synthesis.ts - Text-to-speech hook
  use-voice-recognition.ts - Voice input hook
```

## Configuration

### Customize Voice
Edit `lib/voice-config.ts`:
- Add new voice options
- Adjust default pitch/speed
- Modify animation timing

### Customize Demo
Edit `lib/demo-faculty.ts`:
- Change demo faculty profile
- Add multiple profiles
- Pre-load institution examples

### Customize System Prompt
Edit `lib/prompt-generator.ts`:
- Adjust personality injection
- Modify teaching style guidance
- Change interaction patterns

## Environment Variables

```
ANTHROPIC_API_KEY     - Required: Anthropic Claude API key
```

### Optional (for customization)
```
NEXT_PUBLIC_VOICE_TYPE=female
NEXT_PUBLIC_DEFAULT_PITCH=1.0
NEXT_PUBLIC_DEFAULT_RATE=1.0
```

## Browser Compatibility

| Browser | Desktop | Mobile |
|---------|---------|--------|
| Chrome  | ✓ Full  | ✓ Full |
| Firefox | ✓ Full  | ✓ Full |
| Safari  | ✓ Full  | ✓ Full |
| Edge    | ✓ Full  | ✓ Full |

Voice features require HTTPS or localhost. Speech recognition works best in Chrome.

## Troubleshooting

### Issue: Avatar not speaking
**Solution**: Check browser audio permissions, verify speakers/volume, select voice in setup

### Issue: Responses don't match faculty style
**Solution**: Add specific signature phrases, select correct communication style, describe quirks accurately

### Issue: Slow response times
**Solution**: API processing takes 2-5 seconds (normal), check internet connection, verify API key

### Issue: Voice recognition not working
**Solution**: Check microphone permissions, use Chrome for best support, enable HTTPS

## API Integration

The app uses **Claude 3.5 Sonnet** via Anthropic API.

### How It Works

1. **User Question** sent to `/api/chat`
2. **System Prompt** generated with faculty personality
3. **Claude Processes** with personality constraints
4. **Response Generated** matching faculty style
5. **Text-to-Speech** converts to audio
6. **Avatar Animates** while speaking

### Rate Limits
- Standard Anthropic API limits apply
- Typical response: 2-5 seconds
- Handles multiple concurrent conversations

## Privacy & Data

- **No Cloud Storage** - All data stored locally in browser
- **Session-Based** - Data cleared on browser close
- **No Tracking** - Only error monitoring if enabled
- **API Calls Only** - Only Claude API receives data

## Limitations & Future Enhancements

### Current
- Simulated video analysis (visual pipeline only)
- Text-based system prompt (no audio processing)
- Single conversation thread
- Local storage only

### Future Enhancements
- Real video upload and speech analysis
- Multi-faculty support
- Conversation templates
- Cloud backup and sync
- Export transcripts
- Learning analytics
- Mobile app version

## Support & Feedback

For issues or feature requests:
1. Check DEMO_GUIDE.md for detailed documentation
2. Check QUICK_START.md for quick reference
3. Review SETUP.md for configuration help
4. Open an issue in the project repository

## License

This project is created for educational purposes.

## Created With

Built with Next.js 16, React 19, TypeScript, Tailwind CSS, and Claude API.

---

## Ready to Get Started?

1. **See the Demo** - Click "Load Demo Faculty"
2. **Ask a Question** - Interact with Dr. Rajesh Kumar
3. **Create Your Twin** - Set up your own faculty profile
4. **Enjoy 24/7 Learning** - Your faculty is always available

Questions? See DEMO_GUIDE.md for comprehensive documentation.

Enjoy your Faculty Twin! 🎓✨
