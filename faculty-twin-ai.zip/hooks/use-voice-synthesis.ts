import { useCallback, useRef, useEffect, useState } from 'react';
import { getVoiceByName } from '@/lib/voice-config';

interface VoiceSynthesisOptions {
  voiceName?: string;
  pitch?: number;
  rate?: number;
  volume?: number;
}

export function useVoiceSynthesis(options: VoiceSynthesisOptions = {}) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const utteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      synthRef.current = window.speechSynthesis;
    }
  }, []);

  const speak = useCallback(
    (text: string) => {
      if (!synthRef.current) return;

      // Cancel any ongoing speech
      synthRef.current.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      
      if (options.voiceName) {
        const voice = getVoiceByName(options.voiceName);
        if (voice) {
          utterance.voice = voice;
        }
      }

      utterance.pitch = options.pitch ?? 1.0;
      utterance.rate = options.rate ?? 1.0;
      utterance.volume = options.volume ?? 1.0;

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      utteranceRef.current = utterance;
      synthRef.current.speak(utterance);
    },
    [options.voiceName, options.pitch, options.rate, options.volume]
  );

  const stop = useCallback(() => {
    if (synthRef.current) {
      synthRef.current.cancel();
      setIsSpeaking(false);
    }
  }, []);

  const pause = useCallback(() => {
    if (synthRef.current && isSpeaking) {
      synthRef.current.pause();
    }
  }, [isSpeaking]);

  const resume = useCallback(() => {
    if (synthRef.current && isSpeaking) {
      synthRef.current.resume();
    }
  }, [isSpeaking]);

  return {
    speak,
    stop,
    pause,
    resume,
    isSpeaking,
    isListening
  };
}
