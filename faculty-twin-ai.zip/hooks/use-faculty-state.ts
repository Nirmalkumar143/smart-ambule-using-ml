import { useCallback, useState, useEffect } from 'react';
import { FacultyProfile, ChatMessage } from '@/lib/types';
import { DEMO_FACULTY } from '@/lib/demo-faculty';

const STORAGE_KEY = 'facultyTwin_faculty';
const MESSAGES_KEY = 'facultyTwin_messages';

export function useFacultyState() {
  const [faculty, setFaculty] = useState<FacultyProfile | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Load from localStorage on mount
  useEffect(() => {
    const savedFaculty = localStorage.getItem(STORAGE_KEY);
    const savedMessages = localStorage.getItem(MESSAGES_KEY);

    if (savedFaculty) {
      try {
        setFaculty(JSON.parse(savedFaculty));
      } catch {
        setFaculty(DEMO_FACULTY);
      }
    } else {
      setFaculty(DEMO_FACULTY);
    }

    if (savedMessages) {
      try {
        const parsedMessages = JSON.parse(savedMessages);
        setMessages(parsedMessages.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        })));
      } catch {
        setMessages([]);
      }
    }

    setIsLoading(false);
  }, []);

  const saveFaculty = useCallback((newFaculty: FacultyProfile) => {
    setFaculty(newFaculty);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newFaculty));
  }, []);

  const loadDemoFaculty = useCallback(() => {
    setFaculty(DEMO_FACULTY);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEMO_FACULTY));
    setMessages([]);
    localStorage.removeItem(MESSAGES_KEY);
  }, []);

  const addMessage = useCallback((message: Omit<ChatMessage, 'id' | 'timestamp'>) => {
    const newMessage: ChatMessage = {
      ...message,
      id: Date.now().toString(),
      timestamp: new Date()
    };
    setMessages(prev => {
      const updated = [...prev, newMessage];
      localStorage.setItem(MESSAGES_KEY, JSON.stringify(updated));
      return updated;
    });
    return newMessage;
  }, []);

  const clearMessages = useCallback(() => {
    setMessages([]);
    localStorage.removeItem(MESSAGES_KEY);
  }, []);

  return {
    faculty,
    messages,
    isLoading,
    saveFaculty,
    loadDemoFaculty,
    addMessage,
    clearMessages
  };
}
