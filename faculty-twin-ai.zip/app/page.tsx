'use client';

import React, { useState } from 'react';
import { SetupStage } from '@/components/SetupStage';
import { AnalysisStage } from '@/components/AnalysisStage';
import { ChatStage } from '@/components/ChatStage';
import { useFaculty } from '@/lib/faculty-context';
import { FacultyProfile } from '@/lib/types';

type Stage = 'setup' | 'analysis' | 'chat';

export default function Home() {
  const { faculty, messages, isLoading, saveFaculty, loadDemoFaculty, addMessage } = useFaculty();
  const [currentStage, setCurrentStage] = useState<Stage>('setup');

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <div className="inline-block">
            <div className="w-12 h-12 border-4 border-border border-t-primary rounded-full animate-spin"></div>
          </div>
          <p className="text-foreground/70">Loading Faculty Twin...</p>
        </div>
      </div>
    );
  }

  const handleSetupComplete = (newFaculty: FacultyProfile) => {
    saveFaculty(newFaculty);
    setCurrentStage('analysis');
  };

  const handleAnalysisComplete = () => {
    setCurrentStage('chat');
  };

  return (
    <main className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white font-bold text-sm">
              FT
            </div>
            <h1 className="text-xl font-bold">FacultyTwin AI</h1>
          </div>
          
          <div className="flex items-center gap-4">
            {currentStage === 'chat' && faculty && (
              <button
                onClick={() => {
                  setCurrentStage('setup');
                }}
                className="text-sm px-4 py-2 rounded-lg border border-border hover:bg-muted transition-colors"
              >
                New Twin
              </button>
            )}
            <span className="text-sm text-foreground/60 hidden md:block">
              {currentStage === 'setup' && 'Setup Profile'}
              {currentStage === 'analysis' && 'Analyzing...'}
              {currentStage === 'chat' && faculty?.name}
            </span>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="py-8 md:py-12">
        {currentStage === 'setup' && (
          <SetupStage
            onComplete={handleSetupComplete}
            onLoadDemo={() => {
              loadDemoFaculty();
              setCurrentStage('analysis');
            }}
            existingFaculty={faculty || undefined}
          />
        )}

        {currentStage === 'analysis' && faculty && (
          <AnalysisStage
            faculty={faculty}
            onComplete={handleAnalysisComplete}
          />
        )}

        {currentStage === 'chat' && faculty && (
          <ChatStage
            faculty={faculty}
            messages={messages}
            onAddMessage={addMessage}
          />
        )}
      </div>
    </main>
  );
}
