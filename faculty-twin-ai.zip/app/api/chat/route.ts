import { NextRequest, NextResponse } from 'next/server';
import { generateFacultySystemPrompt } from '@/lib/prompt-generator';
import { FacultyProfile } from '@/lib/types';

export async function POST(request: NextRequest) {
  try {
    const { message, faculty, conversationHistory } = await request.json();

    if (!message || !faculty) {
      return NextResponse.json(
        { error: 'Missing message or faculty profile' },
        { status: 400 }
      );
    }

    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      return NextResponse.json(
        { error: 'ANTHROPIC_API_KEY environment variable not set' },
        { status: 500 }
      );
    }

    const systemPrompt = generateFacultySystemPrompt(faculty as FacultyProfile);

    // Build messages array with conversation history
    const messages = [
      ...(conversationHistory || []),
      { role: 'user', content: message }
    ];

    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json'
      },
      body: JSON.stringify({
        model: 'claude-3-5-sonnet-20241022',
        max_tokens: 1024,
        system: systemPrompt,
        messages: messages
      })
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('Claude API Error:', error);
      return NextResponse.json(
        { error: 'Failed to get response from Claude API' },
        { status: response.status }
      );
    }

    const data = await response.json();
    const assistantMessage = data.content[0].text;

    return NextResponse.json({
      message: assistantMessage,
      success: true
    });
  } catch (error) {
    console.error('Chat API Error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
