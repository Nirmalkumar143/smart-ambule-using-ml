# FacultyTwin AI - Quick Start (30 seconds)

## For Faculty Demo - Just 2 Clicks!

### Click 1: "Load Demo Faculty"
When the app opens on the Setup Screen, click the **"Load Demo Faculty"** button in the top right.

✓ Instantly loads: **Dr. Rajesh Kumar** - Computer Science Professor

### Click 2: "Start Analysis"
Click the blue **"Start Analysis"** button to watch the 5-step pipeline.

Wait 3 seconds for completion...

### You're In! Now Chat
The chat screen appears with:
- **Holographic Avatar** on the left (face that talks!)
- **Chat Interface** on the right

## Try These Questions

**Type in the chat box:**
```
How would you explain recursion to a beginner?
```

**Watch:**
- Avatar's face animates
- Avatar speaks the response
- Response includes their teaching style
- See signature phrases like "Let me break it down"

---

## Demo Faculty Profile

| Property | Value |
|----------|-------|
| **Name** | Dr. Rajesh Kumar |
| **Department** | Computer Science |
| **Teaching Style** | Socratic (asks questions) |
| **Approach** | Example-based learning |
| **Voice** | Deep, confident male voice |
| **Signature Phrases** | "Think about it!", "Let me break it down" |
| **Personality** | Enthusiastic, patient, humorous |

---

## Voice Features

### 🎤 Use Your Voice
Click the microphone icon to ask questions by voice instead of typing.

### 🔊 Avatar Speaks
Every response is spoken through the avatar with emotion and pace.

### 👁️ Watch the Face
Avatar eyes blink and mouth moves while speaking.

---

## What's Happening Behind the Scenes

1. **Your Question** → Sent to Claude AI
2. **System Prompt** → Tells Claude to act like Dr. Rajesh Kumar
3. **Faculty Personality Injected** → Teaching style, phrases, traits
4. **AI Response** → Generated to match faculty
5. **Avatar Speaks** → Text-to-speech with configured voice
6. **Animation** → Face animates while speaking

---

## Questions to Try

### Easy (Start Here)
- "What is Python?"
- "How do I learn programming?"
- "Can you explain loops?"

### Medium (See Teaching Style)
- "How would you teach object-oriented programming?"
- "What's the best way to debug code?"
- "Can you give me a real-world programming example?"

### Hard (See Socratic Method)
- "I'm stuck on this algorithm problem"
- "How should I approach system design?"
- "What's the difference between composition and inheritance?"

### Fun (See Personality)
- "What's your favorite programming language?"
- "Do you prefer theory or practice?"
- "What's a funny programming story you have?"

---

## Create Your Own Faculty Twin

### In the Setup Screen:

1. **Enter Faculty Info** - Name, department, experience
2. **Pick Communication Style** - Formal/Conversational/Socratic/Humorous
3. **Choose Teaching Approach** - Example-based/Socratic/Visual
4. **Select Personality Traits** - Enthusiastic, patient, etc.
5. **Set Voice** - Male/Female/Neutral + pitch + speed
6. **Add Signature Phrases** - Things they always say
7. **Describe Quirks** - Hand gestures, pacing, habits
8. **Upload Video** (Optional) - For real speech analysis
9. **Click "Start Analysis"** - Pipeline runs (3 seconds)
10. **Chat Away!** - Your faculty twin is ready

---

## Mobile & Desktop

### Desktop (Best Experience)
- Avatar on left
- Chat on right
- Full animation effects
- All voice features

### Mobile (Still Works)
- Avatar above chat
- Stacked layout
- Touch-friendly buttons
- Voice input enabled

---

## Supported Browsers

✓ Chrome / Edge - Full support
✓ Firefox - Full support
✓ Safari - Full support
✓ Mobile Chrome - Full support
✓ Mobile Safari - Full support

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Avatar not speaking | Check speakers/volume, browser allows audio |
| Questions not like faculty | Add more signature phrases, check personality traits |
| Slow responses | API takes 2-5 seconds, check internet |
| Microphone not working | Check browser permissions, use Chrome |

---

## Key Features

✨ **Holographic Avatar** - Animated face with breathing glow
🎙️ **Voice Chat** - Ask by voice, get spoken responses
🎨 **Custom Personality** - Match any faculty style
🧠 **AI-Powered** - Claude 3.5 Sonnet backend
📱 **Mobile Ready** - Works on phones and tablets
💾 **Session Memory** - Remembers conversation history
🎓 **Teaching Style** - Reflects pedagogy automatically

---

## Ready? Start Here:

1. Open the app
2. Click "Load Demo Faculty"
3. Click "Start Analysis"
4. Ask a question
5. Watch the magic happen!

Enjoy your Faculty Twin! 🎓
