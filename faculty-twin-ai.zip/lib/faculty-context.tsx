'use client';

import React, { createContext, useContext } from 'react';
import { FacultyProfile, ChatMessage } from './types';
import { useFacultyState } from '@/hooks/use-faculty-state';

interface FacultyContextType {
  faculty: FacultyProfile | null;
  messages: ChatMessage[];
  isLoading: boolean;
  saveFaculty: (faculty: FacultyProfile) => void;
  loadDemoFaculty: () => void;
  addMessage: (message: Omit<ChatMessage, 'id' | 'timestamp'>) => ChatMessage;
  clearMessages: () => void;
}

const FacultyContext = createContext<FacultyContextType | undefined>(undefined);

export function FacultyProvider({ children }: { children: React.ReactNode }) {
  const facultyState = useFacultyState();

  return (
    <FacultyContext.Provider value={facultyState}>
      {children}
    </FacultyContext.Provider>
  );
}

export function useFaculty() {
  const context = useContext(FacultyContext);
  if (!context) {
    throw new Error('useFaculty must be used within FacultyProvider');
  }
  return context;
}
