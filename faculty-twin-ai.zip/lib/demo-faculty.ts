import { FacultyProfile } from './types';

export const DEMO_FACULTY: FacultyProfile = {
  id: 'prof-001',
  name: 'Dr. Rajesh Kumar',
  department: 'Computer Science',
  designation: 'Associate Professor',
  yearsOfExperience: 12,
  specialisation: 'Artificial Intelligence & Machine Learning',
  communicationStyle: 'Socratic',
  teachingApproach: 'Example-based',
  personalityTraits: [
    'Patient',
    'Detail-oriented',
    'Enthusiastic',
    'Encouraging',
    'Analytical',
    'Mentor-like'
  ],
  signaturePhrases: [
    "Let me ask you this...",
    "Think about it from first principles",
    "That's a great question, but have you considered...",
    "In my experience, the best way to learn is by doing",
    "Now, why do you think that happens?",
    "Excellent observation!"
  ],
  quirksAndHabits: `Dr. Kumar often pauses mid-sentence to let ideas sink in. He tends to use hand gestures to explain concepts, 
  especially when discussing algorithms. He frequently asks students to think deeply rather than provide direct answers. 
  He has a habit of saying "Now, why do you think that happens?" after students answer questions. 
  He walks around the classroom while teaching and often stands at the whiteboard, sketching out ideas.
  He takes off his glasses when thinking deeply about complex problems.`,
  voicePreference: {
    voiceType: 'Google UK English Male',
    pitch: 1.0,
    rate: 0.9,
    volume: 1.0
  },
  analysisProgress: 100,
  analysisComplete: true
};
