// Faculty Twin Types
export interface FacultyProfile {
  id: string;
  name: string;
  department: string;
  designation: string;
  yearsOfExperience: number;
  specialisation: string;
  communicationStyle: 'Conversational' | 'Formal' | 'Socratic' | 'Humorous';
  teachingApproach: 'Example-based' | 'Socratic' | 'Visual';
  personalityTraits: string[];
  signaturePhrases: string[];
  quirksAndHabits: string;
  voicePreference?: {
    voiceType: string;
    pitch: number;
    rate: number;
    volume: number;
  };
  videoFiles?: File[];
  analysisProgress?: number;
  analysisComplete?: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  isVoice?: boolean;
}

export interface AnalysisStep {
  step: number;
  name: string;
  description: string;
  progress: number;
  complete: boolean;
  detectedTraits?: string[];
}

export interface ConversationContext {
  faculty: FacultyProfile;
  messages: ChatMessage[];
  currentStep?: number;
}
