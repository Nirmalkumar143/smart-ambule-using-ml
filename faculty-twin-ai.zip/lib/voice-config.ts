export interface VoiceOption {
  name: string;
  voices: string[];
}

export const AVAILABLE_VOICES: VoiceOption[] = [
  {
    name: 'English (US)',
    voices: ['Google US English', 'Microsoft David']
  },
  {
    name: 'English (UK)',
    voices: ['Google UK English Male', 'Google UK English Female']
  },
  {
    name: 'English (Indian)',
    voices: ['Google हिन्दी', 'Microsoft Ravi']
  }
];

export const VOICE_RATES = {
  slow: 0.7,
  normal: 1.0,
  fast: 1.3
};

export const VOICE_PITCH = {
  low: 0.8,
  normal: 1.0,
  high: 1.3
};

export function getAvailableVoices(): SpeechSynthesisVoice[] {
  return window.speechSynthesis.getVoices();
}

export function getVoiceByName(name: string): SpeechSynthesisVoice | undefined {
  const voices = getAvailableVoices();
  return voices.find(v => v.name.includes(name) || v.name === name);
}
