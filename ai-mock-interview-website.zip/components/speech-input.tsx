"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { Mic, Square } from "lucide-react"

type Props = {
  value: string
  onChange: (val: string) => void
  placeholder?: string
  className?: string
}

export function SpeechInput({ value, onChange, placeholder, className }: Props) {
  const [listening, setListening] = useState(false)
  const recognitionRef = useRef<SpeechRecognition | null>(null)

  useEffect(() => {
    if (typeof window === "undefined") return

    const SpeechRecognitionImpl = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    if (!SpeechRecognitionImpl) {
      console.warn("[v0] SpeechRecognition not supported in this browser.")
      return
    }

    const rec: SpeechRecognition = new SpeechRecognitionImpl()
    rec.lang = "en-US"
    rec.interimResults = true
    rec.continuous = true

    rec.onresult = (e: SpeechRecognitionEvent) => {
      let transcript = ""
      for (let i = e.resultIndex; i < e.results.length; i++) {
        transcript += e.results[i][0].transcript
      }
      onChange(transcript)
    }

    rec.onend = () => {
      setListening(false)
    }

    recognitionRef.current = rec
    return () => {
      try {
        rec.stop()
      } catch {}
    }
  }, [onChange])

  const start = () => {
    if (!recognitionRef.current) return
    setListening(true)
    recognitionRef.current.start()
  }

  const stop = () => {
    if (!recognitionRef.current) return
    recognitionRef.current.stop()
    setListening(false)
  }

  return (
    <div className={className}>
      <div className="flex items-center gap-2">
        {!listening ? (
          <Button type="button" variant="default" onClick={start} aria-label="Start recording">
            <Mic className="h-4 w-4 mr-2" />
            Start
          </Button>
        ) : (
          <Button type="button" variant="destructive" onClick={stop} aria-label="Stop recording">
            <Square className="h-4 w-4 mr-2" />
            Stop
          </Button>
        )}
        <span className="text-sm text-muted-foreground">{listening ? "Listening..." : "Click Start to speak"}</span>
      </div>
      <textarea
        className="mt-3 w-full rounded-md border bg-input p-3 text-sm text-foreground"
        rows={4}
        placeholder={placeholder || "Speak or type your answer here..."}
        value={value}
        onChange={(e) => onChange(e.target.value)}
      />
    </div>
  )
}

declare global {
  interface Window {
    webkitSpeechRecognition?: any
    SpeechRecognition?: any
  }
  interface SpeechRecognition extends EventTarget {
    lang: string
    continuous: boolean
    interimResults: boolean
    start: () => void
    stop: () => void
    onresult: (event: SpeechRecognitionEvent) => void
    onend: () => void
  }
  interface SpeechRecognitionEvent extends Event {
    resultIndex: number
    results: SpeechRecognitionResultList
  }
}
