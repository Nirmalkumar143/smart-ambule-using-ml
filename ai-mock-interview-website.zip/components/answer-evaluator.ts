// Simple text normalization for strict and lenient comparisons
function normalize(text: string) {
  return text
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, "") // strip punctuation (unicode-safe)
    .replace(/\s+/g, " ")
    .trim()
}

// Tokenize by space, drop empties
function tokens(text: string) {
  return normalize(text).split(" ").filter(Boolean)
}

// Jaccard similarity for quick semantic-ish overlap
function jaccard(a: string, b: string) {
  const setA = new Set(tokens(a))
  const setB = new Set(tokens(b))
  if (setA.size === 0 && setB.size === 0) return 1
  const inter = new Set([...setA].filter((t) => setB.has(t))).size
  const union = new Set([...setA, ...setB]).size
  return union === 0 ? 0 : inter / union
}

export type EvaluationBreakdown = {
  exactMatch: boolean
  keywordHits: number
  totalKeywords: number
  similarity: number
  notes: string[]
}

export type EvaluationResult = {
  score: number // 0-10
  breakdown: EvaluationBreakdown
}

export type FreeformQuestion = {
  prompt: string
  expectedAnswer: string
  keywords?: string[] // optional: key terms you want covered
}

export type MCQQuestion = {
  prompt: string
  options: string[]
  correctIndex: number
}

export function evaluateFreeform(
  q: FreeformQuestion,
  userAnswer: string,
  opts?: { strict?: boolean },
): EvaluationResult {
  const strict = !!opts?.strict
  const notes: string[] = []
  const expected = normalize(q.expectedAnswer)
  const user = normalize(userAnswer)

  // Strict exact match
  if (strict) {
    const exact = user === expected
    return {
      score: exact ? 10 : 0,
      breakdown: {
        exactMatch: exact,
        keywordHits: 0,
        totalKeywords: q.keywords?.length || 0,
        similarity: exact ? 1 : jaccard(q.expectedAnswer, userAnswer),
        notes: [exact ? "Exact match." : "Strict mode: answer must exactly match."],
      },
    }
  }

  // Lenient: combine exact (10), keyword coverage (up to 8), plus similarity (up to 2)
  const exact = user === expected
  if (exact) {
    return {
      score: 10,
      breakdown: {
        exactMatch: true,
        keywordHits: q.keywords?.length || 0,
        totalKeywords: q.keywords?.length || 0,
        similarity: 1,
        notes: ["Exact match (lenient)."],
      },
    }
  }

  let keywordScore = 0
  let hits = 0
  const total = q.keywords?.length || 0
  if (q.keywords && q.keywords.length > 0) {
    const u = " " + user + " "
    q.keywords.forEach((k) => {
      // crude contains check on normalized text
      if (u.includes(" " + normalize(k) + " ")) hits += 1
    })
    // up to 8 points for keywords
    keywordScore = Math.round((hits / q.keywords.length) * 8)
    notes.push(`Covered ${hits}/${q.keywords.length} keywords.`)
  }

  const sim = jaccard(q.expectedAnswer, userAnswer) // 0..1
  const simScore = Math.round(sim * 2) // up to 2 points
  if (simScore > 0) notes.push("Answer is similar to expected content.")
  if (keywordScore === 0 && simScore === 0) notes.push("Low overlap with expected content.")

  const totalScore = Math.min(10, Math.max(0, keywordScore + simScore))
  return {
    score: totalScore,
    breakdown: {
      exactMatch: false,
      keywordHits: hits,
      totalKeywords: total,
      similarity: sim,
      notes,
    },
  }
}

export function evaluateMCQ(q: MCQQuestion, userIndex: number): EvaluationResult {
  const correct = userIndex === q.correctIndex
  return {
    score: correct ? 10 : 0,
    breakdown: {
      exactMatch: correct,
      keywordHits: 0,
      totalKeywords: 0,
      similarity: correct ? 1 : 0,
      notes: [correct ? "Correct option selected." : "Incorrect option selected."],
    },
  }
}
