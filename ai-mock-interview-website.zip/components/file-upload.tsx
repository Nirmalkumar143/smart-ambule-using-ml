"use client"

import type React from "react"

import { useState, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Upload, FileText, Table, CheckCircle, AlertCircle, X, Download } from "lucide-react"

interface FileUploadProps {
  onUploadComplete?: (data: any) => void
}

export default function FileUpload({ onUploadComplete }: FileUploadProps) {
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [isProcessing, setIsProcessing] = useState(false)
  const [uploadStatus, setUploadStatus] = useState<"idle" | "processing" | "success" | "error">("idle")
  const [extractedData, setExtractedData] = useState<any>(null)
  const [selectedCompany, setSelectedCompany] = useState("TCS")
  const [selectedType, setSelectedType] = useState("Technical")

  const companies = ["TCS", "Infosys", "Wipro", "Accenture", "Cognizant", "HCL", "Tech Mahindra"]
  const questionTypes = ["Technical", "HR", "Coding", "Aptitude", "Behavioral", "System Design"]

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      // Validate file type
      const validTypes = [
        "application/pdf",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "application/vnd.ms-excel",
        "text/csv",
      ]

      if (!validTypes.includes(file.type)) {
        setUploadStatus("error")
        return
      }

      setSelectedFile(file)
      setUploadStatus("idle")
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    const file = e.dataTransfer.files[0]
    if (file) {
      setSelectedFile(file)
      setUploadStatus("idle")
    }
  }, [])

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
  }, [])

  const processFile = async () => {
    if (!selectedFile) return

    setIsProcessing(true)
    setUploadStatus("processing")
    setUploadProgress(0)

    // Simulate file processing with progress
    const progressInterval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(progressInterval)
          return 90
        }
        return prev + 10
      })
    }, 200)

    try {
      // Simulate API call delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Mock extracted data based on file type
      const mockData = generateMockExtractedData(selectedFile)

      setUploadProgress(100)
      setExtractedData(mockData)
      setUploadStatus("success")

      if (onUploadComplete) {
        onUploadComplete(mockData)
      }
    } catch (error) {
      setUploadStatus("error")
    } finally {
      setIsProcessing(false)
      clearInterval(progressInterval)
    }
  }

  const generateMockExtractedData = (file: File) => {
    const isPDF = file.type === "application/pdf"
    const isExcel = file.type.includes("spreadsheet") || file.type.includes("excel")

    if (isPDF) {
      return {
        type: "PDF",
        questionsFound: 15,
        questions: [
          {
            question: "What is polymorphism in object-oriented programming?",
            answer: "Polymorphism allows objects of different types to be treated as objects of a common base type.",
            category: "Technical",
            difficulty: "Medium",
          },
          {
            question: "Explain the difference between abstract class and interface.",
            answer:
              "Abstract classes can have both abstract and concrete methods, while interfaces only have abstract methods.",
            category: "Technical",
            difficulty: "Medium",
          },
          {
            question: "What are your strengths and weaknesses?",
            answer: "Focus on relevant strengths and show how you're working on weaknesses.",
            category: "HR",
            difficulty: "Easy",
          },
        ],
      }
    } else if (isExcel) {
      return {
        type: "Excel",
        questionsFound: 25,
        questions: [
          {
            question: "Write a function to reverse a linked list",
            answer: "Use iterative or recursive approach to reverse pointers",
            category: "Coding",
            difficulty: "Medium",
          },
          {
            question: "What is time complexity of binary search?",
            answer: "O(log n)",
            category: "Technical",
            difficulty: "Easy",
          },
          {
            question: "Describe a challenging project you worked on",
            answer: "Use STAR method to structure your response",
            category: "Behavioral",
            difficulty: "Medium",
          },
        ],
      }
    }

    return null
  }

  const removeFile = () => {
    setSelectedFile(null)
    setUploadStatus("idle")
    setUploadProgress(0)
    setExtractedData(null)
  }

  const downloadTemplate = () => {
    // Create a sample CSV template
    const csvContent = `Question,Answer,Category,Difficulty,Company
"What is polymorphism?","Polymorphism allows objects of different types to be treated as objects of a common base type","Technical","Medium","TCS"
"Explain your greatest strength","Focus on relevant skills and provide specific examples","HR","Easy","TCS"
"Write a function to reverse a string","Use two pointers or built-in reverse method","Coding","Easy","TCS"`

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "question-template.csv"
    a.click()
    window.URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      {/* File Upload Area */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5" />
            Upload Questions File
          </CardTitle>
          <CardDescription>
            Upload questions via PDF, Excel, or CSV files. The system will automatically extract and categorize
            questions.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {!selectedFile ? (
            <div
              className="border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
              onDrop={handleDrop}
              onDragOver={handleDragOver}
              onClick={() => document.getElementById("file-input")?.click()}
            >
              <div className="space-y-4">
                <Upload className="h-12 w-12 text-muted-foreground mx-auto" />
                <div>
                  <p className="text-lg font-medium">Drop files here or click to browse</p>
                  <p className="text-sm text-muted-foreground mt-1">Supports PDF, Excel (.xlsx, .xls), and CSV files</p>
                </div>
                <div className="flex justify-center space-x-4 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <FileText className="h-4 w-4" />
                    <span>PDF</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Table className="h-4 w-4" />
                    <span>Excel</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Table className="h-4 w-4" />
                    <span>CSV</span>
                  </div>
                </div>
              </div>
              <input
                id="file-input"
                type="file"
                accept=".pdf,.xlsx,.xls,.csv"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : (
            <div className="space-y-4">
              {/* Selected File Display */}
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-3">
                  {selectedFile.type === "application/pdf" ? (
                    <FileText className="h-8 w-8 text-red-500" />
                  ) : (
                    <Table className="h-8 w-8 text-green-500" />
                  )}
                  <div>
                    <p className="font-medium">{selectedFile.name}</p>
                    <p className="text-sm text-muted-foreground">{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" onClick={removeFile}>
                  <X className="h-4 w-4" />
                </Button>
              </div>

              {/* Configuration */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="company">Target Company</Label>
                  <select
                    id="company"
                    value={selectedCompany}
                    onChange={(e) => setSelectedCompany(e.target.value)}
                    className="w-full mt-1 p-2 border rounded-md"
                  >
                    {companies.map((company) => (
                      <option key={company} value={company}>
                        {company}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label htmlFor="type">Default Question Type</Label>
                  <select
                    id="type"
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="w-full mt-1 p-2 border rounded-md"
                  >
                    {questionTypes.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Processing Status */}
              {uploadStatus === "processing" && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Processing file...</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} />
                </div>
              )}

              {/* Success/Error Messages */}
              {uploadStatus === "success" && (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    File processed successfully! {extractedData?.questionsFound} questions extracted.
                  </AlertDescription>
                </Alert>
              )}

              {uploadStatus === "error" && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>
                    Error processing file. Please check the file format and try again.
                  </AlertDescription>
                </Alert>
              )}

              {/* Action Button */}
              {uploadStatus !== "success" && (
                <Button onClick={processFile} disabled={isProcessing} className="w-full">
                  {isProcessing ? "Processing..." : "Process & Upload Questions"}
                </Button>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Extracted Data Preview */}
      {extractedData && (
        <Card>
          <CardHeader>
            <CardTitle>Extracted Questions Preview</CardTitle>
            <CardDescription>Review the questions extracted from your {extractedData.type} file</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <Badge variant="outline" className="text-sm">
                  {extractedData.questionsFound} questions found
                </Badge>
                <Button size="sm">Save All Questions</Button>
              </div>

              <div className="space-y-3 max-h-96 overflow-y-auto">
                {extractedData.questions.map((q: any, index: number) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex items-start justify-between mb-2">
                      <p className="font-medium text-sm">{q.question}</p>
                      <div className="flex space-x-1">
                        <Badge variant="secondary" className="text-xs">
                          {q.category}
                        </Badge>
                        <Badge variant="outline" className="text-xs">
                          {q.difficulty}
                        </Badge>
                      </div>
                    </div>
                    {q.answer && <p className="text-sm text-muted-foreground mt-2">{q.answer}</p>}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Instructions and Template */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>File Format Guidelines</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">PDF Format:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Questions should be clearly formatted</li>
                <li>• One question per paragraph or line</li>
                <li>• Include answers if available</li>
                <li>• Use clear headings for categories</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Excel/CSV Format:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Column A: Question</li>
                <li>• Column B: Answer (optional)</li>
                <li>• Column C: Category/Type</li>
                <li>• Column D: Difficulty Level</li>
                <li>• Column E: Company (optional)</li>
              </ul>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Download Template</CardTitle>
            <CardDescription>Use our template to ensure proper formatting</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Download our CSV template with sample questions to get started quickly.
            </p>
            <Button variant="outline" onClick={downloadTemplate} className="w-full bg-transparent">
              <Download className="h-4 w-4 mr-2" />
              Download CSV Template
            </Button>
            <div className="text-xs text-muted-foreground">
              <p>Template includes:</p>
              <ul className="mt-1 space-y-1">
                <li>• Sample technical questions</li>
                <li>• HR interview questions</li>
                <li>• Coding problems</li>
                <li>• Proper formatting examples</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
