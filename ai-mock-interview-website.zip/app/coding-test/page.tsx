"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import { Code, Play, CheckCircle, XCircle, Clock, ArrowLeft, RotateCcw } from "lucide-react"

export default function CodingTestPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [code, setCode] = useState("")
  const [timeLeft, setTimeLeft] = useState(1800) // 30 minutes
  const [isRunning, setIsRunning] = useState(false)
  const [testResults, setTestResults] = useState<any[]>([])
  const [showResults, setShowResults] = useState(false)

  const questions = [
    {
      id: 1,
      title: "Two Sum",
      difficulty: "Easy",
      company: "TCS",
      description:
        "Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.",
      example:
        "Input: nums = [2,7,11,15], target = 9\nOutput: [0,1]\nExplanation: Because nums[0] + nums[1] == 9, we return [0, 1].",
      testCases: [
        { input: "[2,7,11,15], 9", expected: "[0,1]" },
        { input: "[3,2,4], 6", expected: "[1,2]" },
        { input: "[3,3], 6", expected: "[0,1]" },
      ],
      template: `function twoSum(nums, target) {
    // Your code here
    
}`,
    },
    {
      id: 2,
      title: "Reverse String",
      difficulty: "Easy",
      company: "Infosys",
      description: "Write a function that reverses a string. The input string is given as an array of characters s.",
      example: 'Input: s = ["h","e","l","l","o"]\nOutput: ["o","l","l","e","h"]',
      testCases: [
        { input: '["h","e","l","l","o"]', expected: '["o","l","l","e","h"]' },
        { input: '["H","a","n","n","a","h"]', expected: '["h","a","n","n","a","H"]' },
      ],
      template: `function reverseString(s) {
    // Your code here
    
}`,
    },
    {
      id: 3,
      title: "Binary Tree Inorder Traversal",
      difficulty: "Medium",
      company: "Wipro",
      description: "Given the root of a binary tree, return the inorder traversal of its nodes' values.",
      example: "Input: root = [1,null,2,3]\nOutput: [1,3,2]",
      testCases: [
        { input: "[1,null,2,3]", expected: "[1,3,2]" },
        { input: "[]", expected: "[]" },
        { input: "[1]", expected: "[1]" },
      ],
      template: `function inorderTraversal(root) {
    // Your code here
    
}`,
    },
  ]

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(timeLeft - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      handleSubmitTest()
    }
    return () => clearInterval(interval)
  }, [isRunning, timeLeft])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const startTest = () => {
    setIsRunning(true)
    setCode(questions[currentQuestion].template)
  }

  const runCode = () => {
    // Simulate code execution
    const results = questions[currentQuestion].testCases.map((testCase, index) => ({
      testCase: index + 1,
      input: testCase.input,
      expected: testCase.expected,
      actual: testCase.expected, // Simulate passing for demo
      passed: Math.random() > 0.3, // 70% pass rate for demo
    }))

    setTestResults(results)
  }

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setCode(questions[currentQuestion + 1].template)
      setTestResults([])
    }
  }

  const handleSubmitTest = () => {
    setIsRunning(false)
    setShowResults(true)
  }

  const resetTest = () => {
    setCurrentQuestion(0)
    setCode("")
    setTimeLeft(1800)
    setIsRunning(false)
    setTestResults([])
    setShowResults(false)
  }

  if (showResults) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-xl font-bold">Coding Test Results</h1>
            <Button onClick={resetTest}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Take Another Test
            </Button>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Test Completed!</CardTitle>
              <CardDescription>Here's your performance summary</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">8.5/10</div>
                <p className="text-muted-foreground">Overall Score</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">2/3</div>
                  <div className="text-sm text-muted-foreground">Questions Solved</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">85%</div>
                  <div className="text-sm text-muted-foreground">Test Cases Passed</div>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold">Detailed Feedback:</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <span className="text-sm">Code Quality</span>
                    <Badge variant="default">Excellent</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                    <span className="text-sm">Time Complexity</span>
                    <Badge variant="secondary">Good</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <span className="text-sm">Problem Solving</span>
                    <Badge variant="outline">Very Good</Badge>
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <Button className="flex-1" onClick={() => (window.location.href = "/dashboard")}>
                  Back to Dashboard
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent" onClick={resetTest}>
                  Practice More
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (!isRunning) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Code className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-bold">Coding Test</h1>
            </div>
            <Button onClick={() => (window.location.href = "/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">Ready for Your Coding Challenge?</h2>
              <p className="text-muted-foreground text-balance">
                Test your programming skills with company-specific coding problems
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Test Overview</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Questions:</span>
                    <span className="font-semibold">{questions.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Time Limit:</span>
                    <span className="font-semibold">30 minutes</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Difficulty:</span>
                    <span className="font-semibold">Mixed</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Companies:</span>
                    <span className="font-semibold">TCS, Infosys, Wipro</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Instructions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <span className="text-sm">Read each problem carefully</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <span className="text-sm">Write clean, efficient code</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <span className="text-sm">Test your solution with provided examples</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <span className="text-sm">Submit before time runs out</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-8">
              <Button size="lg" onClick={startTest}>
                <Play className="h-5 w-5 mr-2" />
                Start Coding Test
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const question = questions[currentQuestion]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-bold">Coding Test</h1>
            <Badge variant="outline">{question.company}</Badge>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4" />
              <span className="font-mono text-lg">{formatTime(timeLeft)}</span>
            </div>
            <Button variant="outline" onClick={handleSubmitTest}>
              Submit Test
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between text-sm mb-2">
            <span>
              Question {currentQuestion + 1} of {questions.length}
            </span>
            <span>{Math.round(((currentQuestion + 1) / questions.length) * 100)}% Complete</span>
          </div>
          <Progress value={((currentQuestion + 1) / questions.length) * 100} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Problem Statement */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center space-x-2">
                  <span>{question.title}</span>
                  <Badge
                    variant={
                      question.difficulty === "Easy"
                        ? "default"
                        : question.difficulty === "Medium"
                          ? "secondary"
                          : "destructive"
                    }
                  >
                    {question.difficulty}
                  </Badge>
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h3 className="font-semibold mb-2">Problem Description:</h3>
                <p className="text-sm text-muted-foreground">{question.description}</p>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Example:</h3>
                <pre className="text-sm bg-muted p-3 rounded-lg overflow-x-auto">{question.example}</pre>
              </div>

              <div>
                <h3 className="font-semibold mb-2">Test Cases:</h3>
                <div className="space-y-2">
                  {question.testCases.map((testCase, index) => (
                    <div key={index} className="text-sm bg-muted p-2 rounded">
                      <div>
                        <strong>Input:</strong> {testCase.input}
                      </div>
                      <div>
                        <strong>Expected:</strong> {testCase.expected}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Code Editor */}
          <Card>
            <CardHeader>
              <CardTitle>Code Editor</CardTitle>
              <div className="flex space-x-2">
                <Button size="sm" onClick={runCode}>
                  <Play className="h-4 w-4 mr-2" />
                  Run Code
                </Button>
                {currentQuestion < questions.length - 1 && (
                  <Button size="sm" variant="outline" onClick={nextQuestion}>
                    Next Question
                  </Button>
                )}
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Write your code here..."
                className="font-mono text-sm min-h-[300px]"
              />

              {testResults.length > 0 && (
                <div>
                  <h3 className="font-semibold mb-2">Test Results:</h3>
                  <div className="space-y-2">
                    {testResults.map((result, index) => (
                      <div
                        key={index}
                        className={`flex items-center justify-between p-2 rounded text-sm ${
                          result.passed ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
                        }`}
                      >
                        <span>Test Case {result.testCase}</span>
                        {result.passed ? <CheckCircle className="h-4 w-4" /> : <XCircle className="h-4 w-4" />}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
