"use client"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Bot, Mic, MicOff, Volume2, VolumeX, Play, Pause, ArrowLeft, RotateCcw } from "lucide-react"
import { evaluateFreeform, type EvaluationResult } from "@/components/answer-evaluator"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export default function AIAvatarPage() {
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [interviewStarted, setInterviewStarted] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const [transcript, setTranscript] = useState("")
  const [typedAnswer, setTypedAnswer] = useState("")
  const [strictMode, setStrictMode] = useState(false)
  const [evaluations, setEvaluations] = useState<EvaluationResult[]>([])
  const [avatarText, setAvatarText] = useState("")
  const [selectedCompany, setSelectedCompany] = useState("TCS")
  const [audioEnabled, setAudioEnabled] = useState(true)

  const recognitionRef = useRef<any>(null)
  const speechSynthRef = useRef<any>(null)

  const companies = ["TCS", "Infosys", "Wipro", "Accenture"]

  const questions = {
    TCS: [
      {
        id: 1,
        question:
          "Hello! I'm your AI interviewer for TCS. Let's start with a simple question. Can you tell me about yourself and why you're interested in joining TCS?",
        expectedKeywords: ["experience", "skills", "TCS", "technology", "career"],
        type: "Introduction",
        expectedAnswer:
          "I am a software engineer interested in TCS because of its large-scale technology projects and growth opportunities. My skills include JavaScript, React, and problem-solving, and I want to contribute to innovative solutions.",
      },
      {
        id: 2,
        question:
          "Great! Now, can you explain what object-oriented programming is and give me an example of how you've used it in your projects?",
        expectedKeywords: ["OOP", "classes", "objects", "inheritance", "polymorphism", "encapsulation"],
        type: "Technical",
        expectedAnswer:
          "Object-oriented programming organizes code using classes and objects with concepts like encapsulation, inheritance, and polymorphism. I used OOP to model domain entities, creating classes and reusing behavior via inheritance.",
      },
      {
        id: 3,
        question:
          "Excellent! Let's talk about problem-solving. Describe a challenging technical problem you faced and how you solved it.",
        expectedKeywords: ["problem", "solution", "approach", "debugging", "testing"],
        type: "Problem Solving",
        expectedAnswer:
          "I describe the problem context, my approach to debugging, testing hypotheses, and implementing a solution with verification and lessons learned.",
      },
      {
        id: 4,
        question:
          "Very good! Finally, where do you see yourself in 5 years, and how does TCS fit into your career goals?",
        expectedKeywords: ["career", "growth", "goals", "TCS", "future", "development"],
        type: "Career Goals",
        expectedAnswer:
          "In five years I aim to be a strong contributor leading features or teams. TCS aligns with my goals for growth, learning, and impactful software delivery.",
      },
    ],
  }

  const currentQuestions = questions[selectedCompany as keyof typeof questions] || questions.TCS

  useEffect(() => {
    // Initialize speech recognition
    if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) {
      const SpeechRecognition = (window as any).webkitSpeechRecognition || (window as any).SpeechRecognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = true
      recognitionRef.current.interimResults = true
      recognitionRef.current.lang = "en-US"

      recognitionRef.current.onresult = (event: any) => {
        let finalTranscript = ""
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript
          }
        }
        if (finalTranscript) {
          setTranscript((prev) => prev + " " + finalTranscript)
        }
      }

      recognitionRef.current.onerror = (event: any) => {
        console.error("Speech recognition error:", event.error)
        setIsListening(false)
      }
    }

    // Initialize speech synthesis
    if ("speechSynthesis" in window) {
      speechSynthRef.current = window.speechSynthesis
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
      if (speechSynthRef.current) {
        speechSynthRef.current.cancel()
      }
    }
  }, [])

  const startListening = () => {
    if (recognitionRef.current) {
      setIsListening(true)
      recognitionRef.current.start()
    }
  }

  const stopListening = () => {
    if (recognitionRef.current) {
      setIsListening(false)
      recognitionRef.current.stop()
    }
  }

  const speakText = (text: string) => {
    if (speechSynthRef.current && audioEnabled) {
      setIsSpeaking(true)
      const utterance = new SpeechSynthesisUtterance(text)
      utterance.rate = 0.9
      utterance.pitch = 1
      utterance.volume = 0.8

      utterance.onend = () => {
        setIsSpeaking(false)
      }

      speechSynthRef.current.speak(utterance)
    }
  }

  const startInterview = () => {
    setInterviewStarted(true)
    setCurrentQuestion(0)
    const firstQuestion = currentQuestions[0].question
    setAvatarText(firstQuestion)
    speakText(firstQuestion)
    setTranscript("")
    setTypedAnswer("")
    setEvaluations([]) //
  }

  const nextQuestion = () => {
    const r = computeScore() // score before moving
    if (r) {
      setEvaluations((prev) => {
        const next = [...prev]
        next[currentQuestion] = r
        return next
      })
    }
    if (currentQuestion < currentQuestions.length - 1) {
      const nextQ = currentQuestion + 1
      setCurrentQuestion(nextQ)
      const questionText = currentQuestions[nextQ].question
      setAvatarText(questionText)
      speakText(questionText)
      setTranscript("")
      setTypedAnswer("") //
    } else {
      finishInterview()
    }
  }

  const finishInterview = () => {
    const r = computeScore() // ensure last question scored
    if (r) {
      setEvaluations((prev) => {
        const next = [...prev]
        next[currentQuestion] = r
        return next
      })
    }
    setInterviewStarted(false)
    setShowResults(true)
    stopListening()
  }

  const resetInterview = () => {
    setInterviewStarted(false)
    setShowResults(false)
    setCurrentQuestion(0)
    setTranscript("")
    setAvatarText("")
    setIsListening(false)
    setIsSpeaking(false)
    setTypedAnswer("") //
    setEvaluations([]) //
  }

  const evaluateAnswer = () => {
    const question = currentQuestions[currentQuestion]
    const keywords = question.expectedKeywords
    const answerWords = transcript.toLowerCase().split(" ")
    const matchedKeywords = keywords.filter((keyword) =>
      answerWords.some((word) => word.includes(keyword.toLowerCase())),
    )
    return (matchedKeywords.length / keywords.length) * 100
  }

  const computeScore = () => {
    const q = currentQuestions[currentQuestion] as any
    const answerText = (typedAnswer || transcript || "").trim()
    if (!q?.expectedAnswer || !answerText) return null
    return evaluateFreeform(
      { prompt: q.question, expectedAnswer: q.expectedAnswer, keywords: q.expectedKeywords || [] },
      answerText,
      { strict: strictMode },
    )
  }

  if (showResults) {
    const scored = evaluations.filter(Boolean)
    const overall = scored.length ? scored.reduce((s, r) => s + r.score, 0) / scored.length : 0
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-xl font-bold">AI Avatar Interview Results</h1>
            <Button onClick={resetInterview}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Take Another Interview
            </Button>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">AI Interview Completed!</CardTitle>
              <CardDescription>Here's your comprehensive evaluation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">{overall.toFixed(1)}/10</div>
                <p className="text-muted-foreground">Overall AI Interview Score</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">{currentQuestions.length}</div>
                  <div className="text-sm text-muted-foreground">Questions Completed</div>
                </div>
                <div className="text-center p-4 bg-muted rounded-lg">
                  <div className="text-2xl font-bold">18 min</div>
                  <div className="text-sm text-muted-foreground">Total Duration</div>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold">AI Evaluation Breakdown:</h3>
                <div className="space-y-2">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <span className="text-sm">Speech Clarity</span>
                    <Badge variant="default">Excellent (9.2/10)</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <span className="text-sm">Technical Accuracy</span>
                    <Badge variant="outline">Very Good (8.5/10)</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <span className="text-sm">Response Relevance</span>
                    <Badge variant="outline">Very Good (8.8/10)</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                    <span className="text-sm">Confidence Level</span>
                    <Badge variant="secondary">Good (8.2/10)</Badge>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold">AI Recommendations:</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Excellent use of technical terminology and concepts</li>
                  <li>• Good structure in your responses using examples</li>
                  <li>• Consider speaking slightly slower for better clarity</li>
                  <li>• Strong alignment with company values and goals</li>
                  <li>• Continue practicing behavioral question responses</li>
                </ul>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold">Speech Analysis:</h3>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="font-semibold">145 WPM</div>
                    <div className="text-xs text-muted-foreground">Speaking Rate</div>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="font-semibold">92%</div>
                    <div className="text-xs text-muted-foreground">Accuracy</div>
                  </div>
                  <div className="p-3 bg-muted rounded-lg">
                    <div className="font-semibold">3.2s</div>
                    <div className="text-xs text-muted-foreground">Avg Pause</div>
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <Button className="flex-1" onClick={() => (window.location.href = "/dashboard")}>
                  Back to Dashboard
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent" onClick={resetInterview}>
                  Practice More
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (!interviewStarted) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Bot className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-bold">AI Avatar Interview</h1>
            </div>
            <Button onClick={() => (window.location.href = "/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">AI-Powered Interview Experience</h2>
              <p className="text-muted-foreground text-balance">
                Practice with our advanced AI interviewer that evaluates your speech, content, and confidence
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>AI Interview Features</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <Bot className="h-4 w-4 text-blue-600" />
                    </div>
                    <div>
                      <p className="font-medium">AI-Powered Evaluation</p>
                      <p className="text-sm text-muted-foreground">Advanced speech and content analysis</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                      <Mic className="h-4 w-4 text-green-600" />
                    </div>
                    <div>
                      <p className="font-medium">Voice Recognition</p>
                      <p className="text-sm text-muted-foreground">Real-time speech-to-text conversion</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                      <Volume2 className="h-4 w-4 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-medium">Text-to-Speech</p>
                      <p className="text-sm text-muted-foreground">AI interviewer speaks questions aloud</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Interview Setup</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Select Company:</label>
                    <select
                      value={selectedCompany}
                      onChange={(e) => setSelectedCompany(e.target.value)}
                      className="w-full mt-1 p-2 border rounded-md"
                    >
                      {companies.map((company) => (
                        <option key={company} value={company}>
                          {company}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex justify-between">
                    <span>Questions:</span>
                    <span className="font-semibold">{currentQuestions.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Duration:</span>
                    <span className="font-semibold">15-20 minutes</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Evaluation:</span>
                    <span className="font-semibold">Real-time AI analysis</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Audio:</span>
                    <Button variant="outline" size="sm" onClick={() => setAudioEnabled(!audioEnabled)}>
                      {audioEnabled ? (
                        <>
                          <Volume2 className="h-4 w-4 mr-2" />
                          Enabled
                        </>
                      ) : (
                        <>
                          <VolumeX className="h-4 w-4 mr-2" />
                          Disabled
                        </>
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-8">
              <div className="mb-4">
                <div className="w-24 h-24 bg-gradient-to-br from-primary to-primary/70 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bot className="h-12 w-12 text-white" />
                </div>
                <p className="text-sm text-muted-foreground">Your AI interviewer is ready to begin</p>
              </div>
              <Button size="lg" onClick={startInterview}>
                <Play className="h-5 w-5 mr-2" />
                Start AI Interview
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const question = currentQuestions[currentQuestion]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-bold">AI Avatar Interview</h1>
            <Badge variant="outline">{selectedCompany}</Badge>
            <Badge variant="secondary">{question.type}</Badge>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center gap-2">
              <Switch id="strict-mode" checked={strictMode} onCheckedChange={setStrictMode} />
              <Label htmlFor="strict-mode" className="text-sm">
                Strict
              </Label>
            </div>
            <Button variant="outline" size="sm" onClick={() => setAudioEnabled(!audioEnabled)}>
              {audioEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
            </Button>
            <Button variant="outline" onClick={finishInterview}>
              End Interview
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between text-sm mb-2">
            <span>
              Question {currentQuestion + 1} of {currentQuestions.length}
            </span>
            <span>{Math.round(((currentQuestion + 1) / currentQuestions.length) * 100)}% Complete</span>
          </div>
          <Progress value={((currentQuestion + 1) / currentQuestions.length) * 100} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* AI Avatar */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Bot className="h-5 w-5" />
                <span>AI Interviewer</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Avatar Display */}
              <div className="text-center">
                <div
                  className={`w-32 h-32 bg-gradient-to-br from-primary to-primary/70 rounded-full flex items-center justify-center mx-auto mb-4 ${isSpeaking ? "animate-pulse" : ""}`}
                >
                  <Bot className="h-16 w-16 text-white" />
                </div>
                <div className="flex items-center justify-center space-x-2">
                  {isSpeaking ? (
                    <>
                      <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                      <span className="text-sm text-green-600">AI is speaking...</span>
                    </>
                  ) : (
                    <>
                      <div className="w-2 h-2 bg-gray-400 rounded-full"></div>
                      <span className="text-sm text-muted-foreground">Waiting for response...</span>
                    </>
                  )}
                </div>
              </div>

              {/* AI Question */}
              <div className="p-4 bg-muted rounded-lg">
                <p className="text-sm font-medium mb-2">AI Interviewer says:</p>
                <p className="text-sm">{avatarText || question.question}</p>
              </div>

              <div className="flex space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => speakText(avatarText || question.question)}
                  disabled={isSpeaking}
                >
                  {isSpeaking ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                  {isSpeaking ? "Speaking..." : "Repeat Question"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* User Response */}
          <Card>
            <CardHeader>
              <CardTitle>Your Response</CardTitle>
              <CardDescription>Speak clearly into your microphone or type below</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Microphone Control */}
              <div className="text-center">
                <Button
                  size="lg"
                  variant={isListening ? "destructive" : "default"}
                  onClick={isListening ? stopListening : startListening}
                  className="w-24 h-24 rounded-full"
                >
                  {isListening ? <MicOff className="h-8 w-8" /> : <Mic className="h-8 w-8" />}
                </Button>
                <p className="text-sm mt-2">{isListening ? "Click to stop recording" : "Click to start recording"}</p>
              </div>

              {/* Live Transcript */}
              <div className="p-4 bg-muted rounded-lg min-h-[120px]">
                <p className="text-sm font-medium mb-2">Live Transcript:</p>
                <p className="text-sm text-muted-foreground">{transcript || "Your speech will appear here..."}</p>
              </div>

              {/* Typed Fallback */}
              <div>
                <Label htmlFor="typed-answer" className="text-sm">
                  Typed Answer (optional)
                </Label>
                <Textarea
                  id="typed-answer"
                  value={typedAnswer}
                  onChange={(e) => setTypedAnswer(e.target.value)}
                  placeholder="Type here if you prefer typing..."
                  className="mt-2"
                  rows={4}
                />
              </div>

              {/* Live Estimate */}
              {(() => {
                const r = computeScore()
                if (!r) return null
                return (
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="text-sm font-medium text-blue-800">Live Estimate: {r.score}/10</p>
                    <p className="text-xs text-blue-700">
                      Exact match: {r.breakdown.exactMatch ? "Yes" : "No"} · Keywords {r.breakdown.keywordHits}/
                      {r.breakdown.totalKeywords}
                    </p>
                  </div>
                )
              })()}

              <div className="flex justify-between">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setTranscript("")
                    setTypedAnswer("")
                  }}
                >
                  Clear Response
                </Button>
                <Button size="sm" onClick={nextQuestion} disabled={!(typedAnswer || transcript).trim()}>
                  {currentQuestion < currentQuestions.length - 1 ? "Next Question" : "Finish Interview"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
