"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { FileText, Plus, Building2, Users, BarChart3, LogOut, Trash2, Edit, Save, X } from "lucide-react"
import FileUpload from "@/components/file-upload"

interface Question {
  id: number
  question: string
  answer: string
  company: string
  type: string
  difficulty: string
  category?: string
}

export default function AdminDashboard() {
  const [newCompany, setNewCompany] = useState({ name: "", rounds: "", difficulty: "Medium" })
  const [newQuestion, setNewQuestion] = useState({
    question: "",
    answer: "",
    company: "TCS",
    type: "Technical",
    difficulty: "Medium",
    category: "General",
  })
  const [editingQuestion, setEditingQuestion] = useState<number | null>(null)
  const [questions, setQuestions] = useState<Question[]>([
    // Technical Questions
    {
      id: 1,
      question: "What is polymorphism in OOP?",
      answer: "Polymorphism allows objects of different types to be treated as objects of a common base type.",
      company: "TCS",
      type: "Technical",
      difficulty: "Medium",
      category: "OOP",
    },
    {
      id: 2,
      question: "Explain the difference between abstract class and interface.",
      answer:
        "Abstract classes can have both abstract and concrete methods, while interfaces only have abstract methods.",
      company: "TCS",
      type: "Technical",
      difficulty: "Medium",
      category: "OOP",
    },
    {
      id: 3,
      question: "What is the time complexity of binary search?",
      answer: "O(log n)",
      company: "Infosys",
      type: "Technical",
      difficulty: "Easy",
      category: "Algorithms",
    },
    {
      id: 4,
      question: "Explain database normalization.",
      answer:
        "Database normalization is the process of organizing data to reduce redundancy and improve data integrity.",
      company: "Wipro",
      type: "Technical",
      difficulty: "Hard",
      category: "Database",
    },
    {
      id: 5,
      question: "What is REST API?",
      answer: "REST is an architectural style for designing networked applications using HTTP methods.",
      company: "TCS",
      type: "Technical",
      difficulty: "Medium",
      category: "Web Development",
    },

    // HR Questions
    {
      id: 6,
      question: "Tell me about yourself.",
      answer: "Focus on professional background, skills, and career goals relevant to the position.",
      company: "Infosys",
      type: "HR",
      difficulty: "Easy",
      category: "Personal",
    },
    {
      id: 7,
      question: "What are your strengths and weaknesses?",
      answer: "Highlight relevant strengths and show how you're working on weaknesses.",
      company: "TCS",
      type: "HR",
      difficulty: "Easy",
      category: "Personal",
    },
    {
      id: 8,
      question: "Why do you want to work for our company?",
      answer: "Research the company and align your goals with their mission and values.",
      company: "Wipro",
      type: "HR",
      difficulty: "Medium",
      category: "Company",
    },
    {
      id: 9,
      question: "Describe a challenging project you worked on.",
      answer: "Use STAR method to structure your response with specific examples.",
      company: "Infosys",
      type: "HR",
      difficulty: "Medium",
      category: "Experience",
    },
    {
      id: 10,
      question: "Where do you see yourself in 5 years?",
      answer: "Show ambition while staying realistic and relevant to the role.",
      company: "TCS",
      type: "HR",
      difficulty: "Easy",
      category: "Career Goals",
    },

    // Coding Questions
    {
      id: 11,
      question: "Write a function to reverse a string.",
      answer: "Use two pointers or built-in reverse method.",
      company: "Wipro",
      type: "Coding",
      difficulty: "Easy",
      category: "String Manipulation",
    },
    {
      id: 12,
      question: "Implement binary search algorithm.",
      answer: "Use divide and conquer approach with O(log n) complexity.",
      company: "TCS",
      type: "Coding",
      difficulty: "Medium",
      category: "Algorithms",
    },
    {
      id: 13,
      question: "Find the maximum element in an array.",
      answer: "Iterate through array keeping track of maximum value.",
      company: "Infosys",
      type: "Coding",
      difficulty: "Easy",
      category: "Arrays",
    },
    {
      id: 14,
      question: "Implement a stack using arrays.",
      answer: "Use array with top pointer and push/pop operations.",
      company: "Wipro",
      type: "Coding",
      difficulty: "Medium",
      category: "Data Structures",
    },
    {
      id: 15,
      question: "Write a program to check if a number is prime.",
      answer: "Check divisibility from 2 to sqrt(n).",
      company: "TCS",
      type: "Coding",
      difficulty: "Easy",
      category: "Mathematics",
    },

    // Aptitude Questions
    {
      id: 16,
      question: "If a train travels 120 km in 2 hours, what is its speed?",
      answer: "Speed = Distance/Time = 120/2 = 60 km/h",
      company: "TCS",
      type: "Aptitude",
      difficulty: "Easy",
      category: "Speed & Distance",
    },
    {
      id: 17,
      question: "What is 25% of 200?",
      answer: "25% of 200 = (25/100) × 200 = 50",
      company: "Infosys",
      type: "Aptitude",
      difficulty: "Easy",
      category: "Percentage",
    },
    {
      id: 18,
      question: "Find the next number: 2, 4, 8, 16, ?",
      answer: "32 (each number is doubled)",
      company: "Wipro",
      type: "Aptitude",
      difficulty: "Easy",
      category: "Series",
    },
    {
      id: 19,
      question: "A pipe fills a tank in 6 hours, another empties it in 8 hours. Time to fill with both open?",
      answer: "24 hours (net rate = 1/6 - 1/8 = 1/24 per hour)",
      company: "TCS",
      type: "Aptitude",
      difficulty: "Medium",
      category: "Work & Time",
    },
    {
      id: 20,
      question: "The average of 5 numbers is 27. If one is excluded, average becomes 25. Find the excluded number.",
      answer: "35 (Sum of 5 = 135, Sum of 4 = 100, Excluded = 35)",
      company: "Infosys",
      type: "Aptitude",
      difficulty: "Medium",
      category: "Average",
    },

    // Behavioral Questions
    {
      id: 21,
      question: "Describe a time when you had to work under pressure.",
      answer: "Use STAR method with specific example showing problem-solving skills.",
      company: "Wipro",
      type: "Behavioral",
      difficulty: "Medium",
      category: "Pressure Handling",
    },
    {
      id: 22,
      question: "How do you handle conflicts in a team?",
      answer: "Focus on communication, understanding different perspectives, and finding common ground.",
      company: "TCS",
      type: "Behavioral",
      difficulty: "Medium",
      category: "Teamwork",
    },
    {
      id: 23,
      question: "Tell me about a time you failed and how you handled it.",
      answer: "Show learning from failure and how it led to improvement.",
      company: "Infosys",
      type: "Behavioral",
      difficulty: "Hard",
      category: "Failure & Learning",
    },

    // System Design Questions
    {
      id: 24,
      question: "Design a URL shortener like bit.ly",
      answer: "Discuss database design, hashing algorithms, caching, and scalability.",
      company: "Wipro",
      type: "System Design",
      difficulty: "Hard",
      category: "Web Systems",
    },
    {
      id: 25,
      question: "How would you design a chat application?",
      answer: "Cover real-time messaging, database schema, WebSockets, and scaling.",
      company: "TCS",
      type: "System Design",
      difficulty: "Hard",
      category: "Real-time Systems",
    },
    // Technical
    {
      id: 26,
      question: "What is encapsulation in OOP?",
      answer: "Bundling data and methods together while restricting direct access to some components.",
      company: "Infosys",
      type: "Technical",
      difficulty: "Easy",
      category: "OOP",
    },
    {
      id: 27,
      question: "Process vs Thread difference?",
      answer: "A process has its own memory space; threads share memory within a process.",
      company: "Wipro",
      type: "Technical",
      difficulty: "Medium",
      category: "OS",
    },
    // HR
    {
      id: 28,
      question: "Describe a time you resolved a team conflict.",
      answer: "Use STAR; emphasize communication, root-cause analysis, and collaborative resolution.",
      company: "TCS",
      type: "HR",
      difficulty: "Medium",
      category: "Teamwork",
    },
    {
      id: 29,
      question: "What motivates you at work?",
      answer: "Impactful projects, learning opportunities, autonomy, and team outcomes.",
      company: "Infosys",
      type: "HR",
      difficulty: "Easy",
      category: "Motivation",
    },
    // Coding
    {
      id: 30,
      question: "Write a function to generate the first N Fibonacci numbers.",
      answer: "Iterate using two pointers (prev, curr) pushing to array; O(N) time.",
      company: "TCS",
      type: "Coding",
      difficulty: "Easy",
      category: "Sequences",
    },
    {
      id: 31,
      question: "Check if a string is a palindrome ignoring non-alphanumerics.",
      answer: "Two-pointer compare after normalization; O(N).",
      company: "Wipro",
      type: "Coding",
      difficulty: "Medium",
      category: "Strings",
    },
    // Aptitude
    {
      id: 32,
      question: "A bag has 3 red and 5 blue balls. Probability of drawing a red ball?",
      answer: "3/8",
      company: "TCS",
      type: "Aptitude",
      difficulty: "Easy",
      category: "Probability",
    },
    {
      id: 33,
      question: "Cost price ₹400, profit 15%. Selling price?",
      answer: "₹460",
      company: "Infosys",
      type: "Aptitude",
      difficulty: "Easy",
      category: "Profit & Loss",
    },
    // Behavioral
    {
      id: 34,
      question: "Tell me about a time you led without authority.",
      answer: "STAR; influence via expertise, coordination, and clear communication.",
      company: "Wipro",
      type: "Behavioral",
      difficulty: "Medium",
      category: "Leadership",
    },
    {
      id: 35,
      question: "How do you handle tight deadlines?",
      answer: "Prioritize, break down tasks, communicate risks early, and focus on critical path.",
      company: "TCS",
      type: "Behavioral",
      difficulty: "Easy",
      category: "Time Management",
    },
    // System Design
    {
      id: 36,
      question: "Design a news feed for a social network.",
      answer: "Cover write/read patterns, fan-out on write vs read, ranking, caching, pagination, storage.",
      company: "Infosys",
      type: "System Design",
      difficulty: "Hard",
      category: "Feeds",
    },
    {
      id: 37,
      question: "Design a URL availability checker at scale.",
      answer: "Discuss crawling, rate-limiting, async queues, retries, storage, and service decomposition.",
      company: "Wipro",
      type: "System Design",
      difficulty: "Hard",
      category: "Distributed Systems",
    },
  ])

  const companies = [
    {
      id: 1,
      name: "TCS",
      rounds: 4,
      questions: questions.filter((q) => q.company === "TCS").length,
      difficulty: "Medium",
    },
    {
      id: 2,
      name: "Infosys",
      rounds: 3,
      questions: questions.filter((q) => q.company === "Infosys").length,
      difficulty: "Easy",
    },
    {
      id: 3,
      name: "Wipro",
      rounds: 5,
      questions: questions.filter((q) => q.company === "Wipro").length,
      difficulty: "Hard",
    },
  ]

  const handleFileUploadComplete = (data: any) => {
    console.log("File upload completed:", data)
    // Here you would typically save the extracted questions to your database
  }

  const handleAddQuestion = () => {
    if (newQuestion.question.trim() && newQuestion.answer.trim()) {
      const question: Question = {
        id: Math.max(...questions.map((q) => q.id)) + 1,
        ...newQuestion,
      }
      setQuestions([...questions, question])
      setNewQuestion({
        question: "",
        answer: "",
        company: "TCS",
        type: "Technical",
        difficulty: "Medium",
        category: "General",
      })
    }
  }

  const handleEditQuestion = (id: number) => {
    setEditingQuestion(id)
  }

  const handleSaveQuestion = (id: number, updatedQuestion: Partial<Question>) => {
    setQuestions(questions.map((q) => (q.id === id ? { ...q, ...updatedQuestion } : q)))
    setEditingQuestion(null)
  }

  const handleDeleteQuestion = (id: number) => {
    setQuestions(questions.filter((q) => q.id !== id))
  }

  const [filterCompany, setFilterCompany] = useState<string>("All")
  const [filterType, setFilterType] = useState<string>("All")
  const [filterDifficulty, setFilterDifficulty] = useState<string>("All")

  const filteredQuestions = questions.filter((q) => {
    if (filterCompany !== "All" && q.company !== filterCompany) return false
    if (filterType !== "All" && q.type !== filterType) return false
    if (filterDifficulty !== "All" && q.difficulty !== filterDifficulty) return false
    return true
  })

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Building2 className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold">Admin Dashboard</h1>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">Admin Panel</span>
            <Button variant="outline" size="sm" onClick={() => (window.location.href = "/")}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Building2 className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{companies.length}</p>
                  <p className="text-sm text-muted-foreground">Companies</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <FileText className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{questions.length}</p>
                  <p className="text-sm text-muted-foreground">Total Questions</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Users className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">1,247</p>
                  <p className="text-sm text-muted-foreground">Active Users</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <BarChart3 className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">89%</p>
                  <p className="text-sm text-muted-foreground">Success Rate</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="upload" className="space-y-6">
          <TabsList>
            <TabsTrigger value="upload">Question Upload</TabsTrigger>
            <TabsTrigger value="add-question">Add Question</TabsTrigger>
            <TabsTrigger value="companies">Manage Companies</TabsTrigger>
            <TabsTrigger value="questions">Manage Questions</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* File Upload Tab */}
          <TabsContent value="upload">
            <FileUpload onUploadComplete={handleFileUploadComplete} />
          </TabsContent>

          <TabsContent value="add-question">
            <Card>
              <CardHeader>
                <CardTitle>Add Question Manually</CardTitle>
                <CardDescription>Add individual questions with detailed information</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="company">Company</Label>
                    <Select
                      value={newQuestion.company}
                      onValueChange={(value) => setNewQuestion({ ...newQuestion, company: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="TCS">TCS</SelectItem>
                        <SelectItem value="Infosys">Infosys</SelectItem>
                        <SelectItem value="Wipro">Wipro</SelectItem>
                        <SelectItem value="Accenture">Accenture</SelectItem>
                        <SelectItem value="Cognizant">Cognizant</SelectItem>
                        <SelectItem value="HCL">HCL</SelectItem>
                        <SelectItem value="Tech Mahindra">Tech Mahindra</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="type">Question Type</Label>
                    <Select
                      value={newQuestion.type}
                      onValueChange={(value) => setNewQuestion({ ...newQuestion, type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Technical">Technical</SelectItem>
                        <SelectItem value="HR">HR</SelectItem>
                        <SelectItem value="Coding">Coding</SelectItem>
                        <SelectItem value="Aptitude">Aptitude</SelectItem>
                        <SelectItem value="Behavioral">Behavioral</SelectItem>
                        <SelectItem value="System Design">System Design</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="difficulty">Difficulty</Label>
                    <Select
                      value={newQuestion.difficulty}
                      onValueChange={(value) => setNewQuestion({ ...newQuestion, difficulty: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Easy">Easy</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Input
                      id="category"
                      value={newQuestion.category}
                      onChange={(e) => setNewQuestion({ ...newQuestion, category: e.target.value })}
                      placeholder="e.g., OOP, Algorithms, Personal"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="question">Question</Label>
                  <Textarea
                    id="question"
                    value={newQuestion.question}
                    onChange={(e) => setNewQuestion({ ...newQuestion, question: e.target.value })}
                    placeholder="Enter the interview question..."
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="answer">Answer/Explanation</Label>
                  <Textarea
                    id="answer"
                    value={newQuestion.answer}
                    onChange={(e) => setNewQuestion({ ...newQuestion, answer: e.target.value })}
                    placeholder="Enter the expected answer or explanation..."
                    rows={4}
                  />
                </div>

                <Button onClick={handleAddQuestion} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Question
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Companies Tab */}
          <TabsContent value="companies">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Companies</CardTitle>
                  <CardDescription>Manage interview companies and their processes</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {companies.map((company) => (
                      <div key={company.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-semibold">{company.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {company.rounds} rounds • {company.questions} questions
                          </p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">{company.difficulty}</Badge>
                          <Button size="sm" variant="outline">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Add Company</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <Label>Company Name</Label>
                    <Input
                      value={newCompany.name}
                      onChange={(e) => setNewCompany({ ...newCompany, name: e.target.value })}
                      placeholder="Enter company name"
                    />
                  </div>
                  <div>
                    <Label>Number of Rounds</Label>
                    <Input
                      type="number"
                      value={newCompany.rounds}
                      onChange={(e) => setNewCompany({ ...newCompany, rounds: e.target.value })}
                      placeholder="e.g., 4"
                    />
                  </div>
                  <div>
                    <Label>Difficulty</Label>
                    <select
                      className="w-full mt-1 p-2 border rounded-md"
                      value={newCompany.difficulty}
                      onChange={(e) => setNewCompany({ ...newCompany, difficulty: e.target.value })}
                    >
                      <option>Easy</option>
                      <option>Medium</option>
                      <option>Hard</option>
                    </select>
                  </div>
                  <Button className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Company
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="questions">
            <Card>
              <CardHeader>
                <CardTitle>Question Bank ({filteredQuestions.length} questions)</CardTitle>
                <CardDescription>Manage individual questions and answers</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                  <div>
                    <Label>Filter by Company</Label>
                    <Select value={filterCompany} onValueChange={setFilterCompany}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All">All Companies</SelectItem>
                        <SelectItem value="TCS">TCS</SelectItem>
                        <SelectItem value="Infosys">Infosys</SelectItem>
                        <SelectItem value="Wipro">Wipro</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Filter by Type</Label>
                    <Select value={filterType} onValueChange={setFilterType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All">All Types</SelectItem>
                        <SelectItem value="Technical">Technical</SelectItem>
                        <SelectItem value="HR">HR</SelectItem>
                        <SelectItem value="Coding">Coding</SelectItem>
                        <SelectItem value="Aptitude">Aptitude</SelectItem>
                        <SelectItem value="Behavioral">Behavioral</SelectItem>
                        <SelectItem value="System Design">System Design</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Filter by Difficulty</Label>
                    <Select value={filterDifficulty} onValueChange={setFilterDifficulty}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="All">All Difficulties</SelectItem>
                        <SelectItem value="Easy">Easy</SelectItem>
                        <SelectItem value="Medium">Medium</SelectItem>
                        <SelectItem value="Hard">Hard</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex items-end">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setFilterCompany("All")
                        setFilterType("All")
                        setFilterDifficulty("All")
                      }}
                    >
                      Clear Filters
                    </Button>
                  </div>
                </div>

                <div className="space-y-4 max-h-96 overflow-y-auto">
                  {filteredQuestions.map((q) => (
                    <div key={q.id} className="p-4 border rounded-lg">
                      {editingQuestion === q.id ? (
                        <EditQuestionForm
                          question={q}
                          onSave={(updated) => handleSaveQuestion(q.id, updated)}
                          onCancel={() => setEditingQuestion(null)}
                        />
                      ) : (
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <p className="font-medium">{q.question}</p>
                            <p className="text-sm text-muted-foreground mt-1">{q.answer}</p>
                            <div className="flex items-center space-x-2 mt-2">
                              <Badge variant="outline">{q.company}</Badge>
                              <Badge variant="secondary">{q.type}</Badge>
                              <Badge variant="outline">{q.difficulty}</Badge>
                              {q.category && <Badge variant="outline">{q.category}</Badge>}
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" onClick={() => handleEditQuestion(q.id)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline" onClick={() => handleDeleteQuestion(q.id)}>
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>User Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Average Score</span>
                      <span className="font-semibold">8.2/10</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Completion Rate</span>
                      <span className="font-semibold">89%</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Most Popular Company</span>
                      <span className="font-semibold">TCS</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Question Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span>Total Questions</span>
                      <span className="font-semibold">135</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Technical Questions</span>
                      <span className="font-semibold">78</span>
                    </div>
                    <div className="flex justify-between">
                      <span>HR Questions</span>
                      <span className="font-semibold">35</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Coding Questions</span>
                      <span className="font-semibold">22</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}

function EditQuestionForm({
  question,
  onSave,
  onCancel,
}: {
  question: Question
  onSave: (updated: Partial<Question>) => void
  onCancel: () => void
}) {
  const [editedQuestion, setEditedQuestion] = useState(question)

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Select
          value={editedQuestion.company}
          onValueChange={(value) => setEditedQuestion({ ...editedQuestion, company: value })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="TCS">TCS</SelectItem>
            <SelectItem value="Infosys">Infosys</SelectItem>
            <SelectItem value="Wipro">Wipro</SelectItem>
          </SelectContent>
        </Select>
        <Select
          value={editedQuestion.type}
          onValueChange={(value) => setEditedQuestion({ ...editedQuestion, type: value })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Technical">Technical</SelectItem>
            <SelectItem value="HR">HR</SelectItem>
            <SelectItem value="Coding">Coding</SelectItem>
            <SelectItem value="Aptitude">Aptitude</SelectItem>
            <SelectItem value="Behavioral">Behavioral</SelectItem>
            <SelectItem value="System Design">System Design</SelectItem>
          </SelectContent>
        </Select>
        <Select
          value={editedQuestion.difficulty}
          onValueChange={(value) => setEditedQuestion({ ...editedQuestion, difficulty: value })}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Easy">Easy</SelectItem>
            <SelectItem value="Medium">Medium</SelectItem>
            <SelectItem value="Hard">Hard</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <Textarea
        value={editedQuestion.question}
        onChange={(e) => setEditedQuestion({ ...editedQuestion, question: e.target.value })}
        rows={2}
      />
      <Textarea
        value={editedQuestion.answer}
        onChange={(e) => setEditedQuestion({ ...editedQuestion, answer: e.target.value })}
        rows={3}
      />
      <div className="flex space-x-2">
        <Button size="sm" onClick={() => onSave(editedQuestion)}>
          <Save className="h-4 w-4 mr-2" />
          Save
        </Button>
        <Button size="sm" variant="outline" onClick={onCancel}>
          <X className="h-4 w-4 mr-2" />
          Cancel
        </Button>
      </div>
    </div>
  )
}
