"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Building2, Users, Clock, CheckCircle, XCircle, ArrowLeft, ArrowRight, Play } from "lucide-react"

export default function CompaniesPage() {
  const [selectedCompany, setSelectedCompany] = useState<string | null>(null)

  const companies = [
    {
      id: "tcs",
      name: "Tata Consultancy Services (TCS)",
      logo: "🏢",
      difficulty: "Medium",
      rounds: [
        { name: "Online Assessment", duration: "90 mins", type: "Aptitude + Coding" },
        { name: "Technical Interview", duration: "45 mins", type: "Technical" },
        { name: "Managerial Round", duration: "30 mins", type: "Behavioral" },
        { name: "HR Round", duration: "20 mins", type: "HR" },
      ],
      process: {
        overview:
          "TCS follows a structured 4-round interview process focusing on technical skills, problem-solving, and cultural fit.",
        tips: [
          "Strong foundation in programming concepts",
          "Good communication skills",
          "Understanding of software development lifecycle",
          "Awareness of current technology trends",
        ],
      },
      dos: [
        "Prepare data structures and algorithms thoroughly",
        "Practice coding problems on platforms like HackerRank",
        "Research TCS projects and values",
        "Prepare examples of teamwork and leadership",
        "Dress professionally and arrive early",
      ],
      donts: [
        "Don't ignore aptitude and logical reasoning",
        "Don't be overconfident about your technical skills",
        "Don't speak negatively about previous employers",
        "Don't lie about your experience or skills",
        "Don't forget to ask thoughtful questions",
      ],
      questions: 45,
      successRate: "78%",
    },
    {
      id: "infosys",
      name: "Infosys",
      logo: "💼",
      difficulty: "Easy",
      rounds: [
        { name: "Online Test", duration: "120 mins", type: "Aptitude + Programming" },
        { name: "Technical Interview", duration: "40 mins", type: "Technical" },
        { name: "HR Interview", duration: "25 mins", type: "HR" },
      ],
      process: {
        overview: "Infosys has a 3-round process with emphasis on logical thinking and basic programming skills.",
        tips: [
          "Focus on logical reasoning and quantitative aptitude",
          "Basic programming knowledge is sufficient",
          "Good English communication skills",
          "Understanding of software engineering principles",
        ],
      },
      dos: [
        "Practice aptitude questions regularly",
        "Learn basic programming in Java/C++/Python",
        "Understand object-oriented programming concepts",
        "Prepare for puzzles and logical questions",
        "Show enthusiasm for learning new technologies",
      ],
      donts: [
        "Don't neglect English language skills",
        "Don't skip practicing coding basics",
        "Don't appear disinterested in training programs",
        "Don't give vague answers to technical questions",
        "Don't forget to mention relevant projects",
      ],
      questions: 32,
      successRate: "85%",
    },
    {
      id: "wipro",
      name: "Wipro",
      logo: "🏭",
      difficulty: "Hard",
      rounds: [
        { name: "Written Test", duration: "150 mins", type: "Aptitude + Technical" },
        { name: "Technical Interview 1", duration: "50 mins", type: "Technical Deep Dive" },
        { name: "Technical Interview 2", duration: "45 mins", type: "System Design" },
        { name: "Managerial Round", duration: "35 mins", type: "Behavioral" },
        { name: "HR Round", duration: "25 mins", type: "HR" },
      ],
      process: {
        overview:
          "Wipro has an intensive 5-round process with strong focus on technical depth and problem-solving abilities.",
        tips: [
          "Deep technical knowledge required",
          "System design understanding important",
          "Strong problem-solving skills",
          "Leadership and project management experience valued",
        ],
      },
      dos: [
        "Master advanced data structures and algorithms",
        "Understand system design principles",
        "Prepare for multiple technical rounds",
        "Show leadership experience and initiative",
        "Research Wipro's business domains thoroughly",
      ],
      donts: [
        "Don't underestimate the technical difficulty",
        "Don't skip system design preparation",
        "Don't give superficial answers to deep technical questions",
        "Don't appear inflexible about role assignments",
        "Don't forget to prepare behavioral examples",
      ],
      questions: 58,
      successRate: "65%",
    },
  ]

  const selectedCompanyData = companies.find((c) => c.id === selectedCompany)

  if (selectedCompany && selectedCompanyData) {
    return (
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm" onClick={() => setSelectedCompany(null)}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Companies
              </Button>
              <div className="flex items-center space-x-2">
                <span className="text-2xl">{selectedCompanyData.logo}</span>
                <h1 className="text-xl font-bold">{selectedCompanyData.name}</h1>
              </div>
            </div>
            <Button onClick={() => (window.location.href = "/dashboard")}>Go to Dashboard</Button>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          {/* Company Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-primary">{selectedCompanyData.rounds.length}</div>
                <div className="text-sm text-muted-foreground">Interview Rounds</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-primary">{selectedCompanyData.questions}</div>
                <div className="text-sm text-muted-foreground">Practice Questions</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <div className="text-2xl font-bold text-primary">{selectedCompanyData.successRate}</div>
                <div className="text-sm text-muted-foreground">Success Rate</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center">
                <Badge
                  variant={
                    selectedCompanyData.difficulty === "Easy"
                      ? "default"
                      : selectedCompanyData.difficulty === "Medium"
                        ? "secondary"
                        : "destructive"
                  }
                >
                  {selectedCompanyData.difficulty}
                </Badge>
                <div className="text-sm text-muted-foreground mt-2">Difficulty Level</div>
              </CardContent>
            </Card>
          </div>

          <Tabs defaultValue="process" className="space-y-6">
            <TabsList>
              <TabsTrigger value="process">Interview Process</TabsTrigger>
              <TabsTrigger value="preparation">Preparation Guide</TabsTrigger>
              <TabsTrigger value="practice">Practice Tests</TabsTrigger>
            </TabsList>

            <TabsContent value="process">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Interview Process Overview</CardTitle>
                    <CardDescription>{selectedCompanyData.process.overview}</CardDescription>
                  </CardHeader>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Interview Rounds</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {selectedCompanyData.rounds.map((round, index) => (
                        <div key={index} className="flex items-center space-x-4 p-4 border rounded-lg">
                          <div className="flex-shrink-0 w-8 h-8 bg-primary text-primary-foreground rounded-full flex items-center justify-center font-semibold">
                            {index + 1}
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold">{round.name}</h3>
                            <p className="text-sm text-muted-foreground">{round.type}</p>
                          </div>
                          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                            <Clock className="h-4 w-4" />
                            <span>{round.duration}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="preparation">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <CheckCircle className="h-5 w-5 text-green-500" />
                      <span>Do's</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {selectedCompanyData.dos.map((item, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <XCircle className="h-5 w-5 text-red-500" />
                      <span>Don'ts</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-3">
                      {selectedCompanyData.donts.map((item, index) => (
                        <li key={index} className="flex items-start space-x-2">
                          <XCircle className="h-4 w-4 text-red-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm">{item}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card className="lg:col-span-2">
                  <CardHeader>
                    <CardTitle>Key Preparation Tips</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {selectedCompanyData.process.tips.map((tip, index) => (
                        <div key={index} className="flex items-center space-x-2 p-3 bg-muted rounded-lg">
                          <div className="w-2 h-2 bg-primary rounded-full"></div>
                          <span className="text-sm">{tip}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="practice">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => (window.location.href = "/aptitude-test")}
                >
                  <CardContent className="p-6 text-center">
                    <div className="mb-4">
                      <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto">
                        <Building2 className="h-6 w-6 text-orange-600" />
                      </div>
                    </div>
                    <h3 className="font-semibold mb-2">Aptitude Test</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Practice quantitative, logical & verbal reasoning
                    </p>
                    <Button className="w-full">Start Aptitude Test</Button>
                  </CardContent>
                </Card>

                <Card
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => (window.location.href = "/coding-test")}
                >
                  <CardContent className="p-6 text-center">
                    <div className="mb-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                        <Play className="h-6 w-6 text-blue-600" />
                      </div>
                    </div>
                    <h3 className="font-semibold mb-2">Coding Test</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Practice coding problems specific to {selectedCompanyData.name}
                    </p>
                    <Button className="w-full">Start Coding Test</Button>
                  </CardContent>
                </Card>

                <Card
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => (window.location.href = "/mock-interview")}
                >
                  <CardContent className="p-6 text-center">
                    <div className="mb-4">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto">
                        <Users className="h-6 w-6 text-green-600" />
                      </div>
                    </div>
                    <h3 className="font-semibold mb-2">Mock Interview</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Practice with {selectedCompanyData.name}-specific questions
                    </p>
                    <Button className="w-full">Start Mock Interview</Button>
                  </CardContent>
                </Card>

                <Card
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => (window.location.href = "/ai-avatar")}
                >
                  <CardContent className="p-6 text-center">
                    <div className="mb-4">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto">
                        <Building2 className="h-6 w-6 text-purple-600" />
                      </div>
                    </div>
                    <h3 className="font-semibold mb-2">AI Avatar Interview</h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      Practice with AI interviewer for {selectedCompanyData.name}
                    </p>
                    <Button className="w-full">Start AI Interview</Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Building2 className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold">Companies</h1>
          </div>
          <Button onClick={() => (window.location.href = "/dashboard")}>Go to Dashboard</Button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Choose Your Target Company</h2>
          <p className="text-muted-foreground text-balance">
            Select a company to explore their interview process, preparation guides, and practice tests
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {companies.map((company) => (
            <Card
              key={company.id}
              className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:-translate-y-1"
              onClick={() => setSelectedCompany(company.id)}
            >
              <CardHeader className="text-center">
                <div className="text-4xl mb-2">{company.logo}</div>
                <CardTitle className="text-lg">{company.name}</CardTitle>
                <CardDescription>
                  {company.rounds.length} rounds • {company.questions} questions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Difficulty:</span>
                  <Badge
                    variant={
                      company.difficulty === "Easy"
                        ? "default"
                        : company.difficulty === "Medium"
                          ? "secondary"
                          : "destructive"
                    }
                  >
                    {company.difficulty}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Success Rate:</span>
                  <span className="font-semibold text-primary">{company.successRate}</span>
                </div>
                <Button className="w-full">
                  Explore Company
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Info */}
        <div className="mt-12 text-center">
          <Card className="max-w-2xl mx-auto">
            <CardContent className="p-6">
              <h3 className="font-semibold mb-2">Can't find your target company?</h3>
              <p className="text-sm text-muted-foreground mb-4">
                We're constantly adding new companies. Practice with similar companies to build your skills.
              </p>
              <Button variant="outline">Request New Company</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
