"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart3, TrendingUp, Download, Filter, ArrowLeft, Trophy, Target, Clock, Brain } from "lucide-react"

export default function ResultsPage() {
  const [selectedFilter, setSelectedFilter] = useState("all")
  const [selectedTimeframe, setSelectedTimeframe] = useState("month")

  const overallStats = {
    totalTests: 24,
    averageScore: 8.3,
    bestScore: 9.7,
    timeSpent: 18.5, // hours
    improvement: 12.5, // percentage
  }

  const testHistory = [
    {
      id: 1,
      type: "Coding Test",
      company: "TCS",
      score: 9.2,
      date: "2024-01-15",
      duration: "45 min",
      status: "completed",
      details: {
        questionsAnswered: 8,
        totalQuestions: 10,
        accuracy: 92,
        timeEfficiency: 85,
      },
    },
    {
      id: 2,
      type: "Mock Interview",
      company: "Infosys",
      score: 8.7,
      date: "2024-01-14",
      duration: "30 min",
      status: "completed",
      details: {
        questionsAnswered: 5,
        totalQuestions: 5,
        communication: 90,
        technical: 85,
        confidence: 88,
      },
    },
    {
      id: 3,
      type: "AI Avatar",
      company: "Wipro",
      score: 8.1,
      date: "2024-01-12",
      duration: "25 min",
      status: "completed",
      details: {
        speechClarity: 88,
        responseRelevance: 82,
        confidence: 79,
        technicalAccuracy: 85,
      },
    },
    {
      id: 4,
      type: "Coding Test",
      company: "Accenture",
      score: 7.8,
      date: "2024-01-10",
      duration: "50 min",
      status: "completed",
      details: {
        questionsAnswered: 6,
        totalQuestions: 8,
        accuracy: 78,
        timeEfficiency: 75,
      },
    },
    {
      id: 5,
      type: "Mock Interview",
      company: "TCS",
      score: 9.1,
      date: "2024-01-08",
      duration: "35 min",
      status: "completed",
      details: {
        questionsAnswered: 6,
        totalQuestions: 6,
        communication: 95,
        technical: 88,
        confidence: 92,
      },
    },
  ]

  const skillProgress = [
    { skill: "Technical Knowledge", current: 85, target: 90, improvement: 8 },
    { skill: "Communication", current: 88, target: 92, improvement: 12 },
    { skill: "Problem Solving", current: 82, target: 88, improvement: 15 },
    { skill: "Confidence", current: 79, target: 85, improvement: 18 },
    { skill: "Code Quality", current: 86, target: 90, improvement: 6 },
  ]

  const companyPerformance = [
    { company: "TCS", tests: 8, avgScore: 8.6, bestScore: 9.2, trend: "up" },
    { company: "Infosys", tests: 6, avgScore: 8.2, bestScore: 8.7, trend: "up" },
    { company: "Wipro", tests: 5, avgScore: 7.9, bestScore: 8.4, trend: "stable" },
    { company: "Accenture", tests: 5, avgScore: 8.0, bestScore: 8.3, trend: "up" },
  ]

  const filteredTests = testHistory.filter((test) => {
    if (selectedFilter === "all") return true
    return test.type.toLowerCase().includes(selectedFilter.toLowerCase())
  })

  const getScoreColor = (score: number) => {
    if (score >= 9) return "text-green-600"
    if (score >= 8) return "text-blue-600"
    if (score >= 7) return "text-yellow-600"
    return "text-red-600"
  }

  const getScoreBadge = (score: number) => {
    if (score >= 9) return "default"
    if (score >= 8) return "secondary"
    if (score >= 7) return "outline"
    return "destructive"
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <BarChart3 className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold">Results & Analytics</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
            <Button onClick={() => (window.location.href = "/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <Trophy className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">{overallStats.totalTests}</div>
              <div className="text-sm text-muted-foreground">Total Tests</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Target className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">{overallStats.averageScore}/10</div>
              <div className="text-sm text-muted-foreground">Average Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Brain className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">{overallStats.bestScore}/10</div>
              <div className="text-sm text-muted-foreground">Best Score</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Clock className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">{overallStats.timeSpent}h</div>
              <div className="text-sm text-muted-foreground">Time Practiced</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-8 w-8 text-primary mx-auto mb-2" />
              <div className="text-2xl font-bold">+{overallStats.improvement}%</div>
              <div className="text-sm text-muted-foreground">Improvement</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="history" className="space-y-6">
          <TabsList>
            <TabsTrigger value="history">Test History</TabsTrigger>
            <TabsTrigger value="skills">Skill Progress</TabsTrigger>
            <TabsTrigger value="companies">Company Performance</TabsTrigger>
            <TabsTrigger value="analytics">Detailed Analytics</TabsTrigger>
          </TabsList>

          {/* Test History */}
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>Test History</CardTitle>
                    <CardDescription>Your recent interview practice sessions</CardDescription>
                  </div>
                  <div className="flex space-x-2">
                    <select
                      value={selectedFilter}
                      onChange={(e) => setSelectedFilter(e.target.value)}
                      className="px-3 py-1 border rounded-md text-sm"
                    >
                      <option value="all">All Tests</option>
                      <option value="coding">Coding Tests</option>
                      <option value="mock">Mock Interviews</option>
                      <option value="ai">AI Avatar</option>
                    </select>
                    <Button variant="outline" size="sm">
                      <Filter className="h-4 w-4 mr-2" />
                      Filter
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {filteredTests.map((test) => (
                    <div key={test.id} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div>
                            <h3 className="font-semibold">{test.type}</h3>
                            <p className="text-sm text-muted-foreground">{test.company}</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-3">
                          <Badge variant={getScoreBadge(test.score)}>{test.score}/10</Badge>
                          <div className="text-right">
                            <p className="text-sm font-medium">{test.date}</p>
                            <p className="text-sm text-muted-foreground">{test.duration}</p>
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        {test.type === "Coding Test" && (
                          <>
                            <div>
                              <span className="text-muted-foreground">Questions:</span>
                              <span className="ml-2 font-medium">
                                {test.details.questionsAnswered}/{test.details.totalQuestions}
                              </span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Accuracy:</span>
                              <span className="ml-2 font-medium">{test.details.accuracy}%</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Efficiency:</span>
                              <span className="ml-2 font-medium">{test.details.timeEfficiency}%</span>
                            </div>
                          </>
                        )}
                        {test.type === "Mock Interview" && (
                          <>
                            <div>
                              <span className="text-muted-foreground">Communication:</span>
                              <span className="ml-2 font-medium">{test.details.communication}%</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Technical:</span>
                              <span className="ml-2 font-medium">{test.details.technical}%</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Confidence:</span>
                              <span className="ml-2 font-medium">{test.details.confidence}%</span>
                            </div>
                          </>
                        )}
                        {test.type === "AI Avatar" && (
                          <>
                            <div>
                              <span className="text-muted-foreground">Speech Clarity:</span>
                              <span className="ml-2 font-medium">{test.details.speechClarity}%</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Relevance:</span>
                              <span className="ml-2 font-medium">{test.details.responseRelevance}%</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Technical:</span>
                              <span className="ml-2 font-medium">{test.details.technicalAccuracy}%</span>
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Skill Progress */}
          <TabsContent value="skills">
            <Card>
              <CardHeader>
                <CardTitle>Skill Development</CardTitle>
                <CardDescription>Track your improvement across different skill areas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {skillProgress.map((skill, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <h3 className="font-medium">{skill.skill}</h3>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-muted-foreground">
                            {skill.current}% / {skill.target}%
                          </span>
                          <Badge variant="outline" className="text-xs">
                            +{skill.improvement}%
                          </Badge>
                        </div>
                      </div>
                      <div className="space-y-1">
                        <Progress value={skill.current} className="h-2" />
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Current: {skill.current}%</span>
                          <span>Target: {skill.target}%</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Company Performance */}
          <TabsContent value="companies">
            <Card>
              <CardHeader>
                <CardTitle>Company-wise Performance</CardTitle>
                <CardDescription>Your performance across different companies</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {companyPerformance.map((company, index) => (
                    <Card key={index}>
                      <CardContent className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="font-semibold text-lg">{company.company}</h3>
                          <div className="flex items-center space-x-1">
                            <TrendingUp
                              className={`h-4 w-4 ${
                                company.trend === "up"
                                  ? "text-green-500"
                                  : company.trend === "down"
                                    ? "text-red-500"
                                    : "text-gray-500"
                              }`}
                            />
                            <span className="text-sm text-muted-foreground capitalize">{company.trend}</span>
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div className="flex justify-between">
                            <span className="text-sm text-muted-foreground">Tests Taken:</span>
                            <span className="font-medium">{company.tests}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-muted-foreground">Average Score:</span>
                            <span className="font-medium">{company.avgScore}/10</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm text-muted-foreground">Best Score:</span>
                            <span className="font-medium">{company.bestScore}/10</span>
                          </div>
                          <Progress value={company.avgScore * 10} className="mt-2" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Detailed Analytics */}
          <TabsContent value="analytics">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Performance Trends</CardTitle>
                  <CardDescription>Your improvement over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-green-50 rounded-lg">
                      <h4 className="font-semibold text-green-800">Strengths</h4>
                      <ul className="text-sm text-green-700 mt-2 space-y-1">
                        <li>• Excellent technical knowledge in OOP concepts</li>
                        <li>• Strong problem-solving approach</li>
                        <li>• Good communication skills</li>
                        <li>• Consistent improvement in coding efficiency</li>
                      </ul>
                    </div>

                    <div className="p-4 bg-yellow-50 rounded-lg">
                      <h4 className="font-semibold text-yellow-800">Areas for Improvement</h4>
                      <ul className="text-sm text-yellow-700 mt-2 space-y-1">
                        <li>• Work on system design concepts</li>
                        <li>• Practice more behavioral questions</li>
                        <li>• Improve time management in coding tests</li>
                        <li>• Build confidence in AI avatar interviews</li>
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recommendations</CardTitle>
                  <CardDescription>Personalized suggestions for improvement</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-semibold mb-2">Next Steps</h4>
                      <ul className="text-sm space-y-2">
                        <li className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                          <span>Focus on Wipro preparation - your weakest company performance</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                          <span>Practice more AI avatar interviews to build confidence</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                          <span>Work on system design questions for senior roles</span>
                        </li>
                        <li className="flex items-start space-x-2">
                          <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                          <span>Take more coding tests to improve speed</span>
                        </li>
                      </ul>
                    </div>

                    <div className="p-4 bg-blue-50 rounded-lg">
                      <h4 className="font-semibold text-blue-800 mb-2">Study Plan</h4>
                      <div className="text-sm text-blue-700 space-y-1">
                        <p>
                          <strong>This Week:</strong> 3 coding tests, 2 mock interviews
                        </p>
                        <p>
                          <strong>Next Week:</strong> Focus on system design, 1 AI avatar session
                        </p>
                        <p>
                          <strong>Goal:</strong> Achieve 9+ average score across all test types
                        </p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
