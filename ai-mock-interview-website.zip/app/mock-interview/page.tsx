"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { MessageSquare, Clock, ArrowLeft, ArrowRight, CheckCircle, RotateCcw, Mic, MicOff } from "lucide-react"
import { evaluateFreeform, type EvaluationResult } from "@/components/answer-evaluator"
import { SpeechInput } from "@/components/speech-input"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"

export default function MockInterviewPage() {
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answer, setAnswer] = useState("")
  const [timeLeft, setTimeLeft] = useState(300) // 5 minutes per question
  const [isRunning, setIsRunning] = useState(false)
  const [showResults, setShowResults] = useState(false)
  const [strictMode, setStrictMode] = useState(false)
  const [evaluations, setEvaluations] = useState<EvaluationResult[]>([])
  const [selectedCompany, setSelectedCompany] = useState("TCS")
  const [isRecording, setIsRecording] = useState(false)

  const companies = ["TCS", "Infosys", "Wipro", "Accenture"]

  const questions = {
    TCS: [
      {
        id: 1,
        question: "Tell me about yourself and your background in software development.",
        type: "HR",
        difficulty: "Easy",
        tips: "Keep it concise, focus on relevant experience, and connect it to the role.",
        expectedAnswer:
          "I am a software developer with experience in building web applications using technologies like JavaScript, React, and Node.js. I enjoy solving problems and have completed projects involving APIs, databases, and agile teamwork.",
        keywords: ["software developer", "web applications", "JavaScript", "React", "Node.js", "projects", "agile"],
      },
      {
        id: 2,
        question: "Explain the difference between abstract class and interface in Java.",
        type: "Technical",
        difficulty: "Medium",
        tips: "Mention key differences: implementation, inheritance, access modifiers.",
        expectedAnswer:
          "An interface defines a contract with abstract methods and default/static methods, while an abstract class can have both abstract and concrete methods, state via fields, and constructors. A class can implement multiple interfaces but can extend only one abstract class.",
        keywords: [
          "interface",
          "abstract class",
          "multiple inheritance",
          "abstract methods",
          "concrete methods",
          "constructors",
        ],
      },
      {
        id: 3,
        question: "Describe a challenging project you worked on and how you overcame obstacles.",
        type: "Behavioral",
        difficulty: "Medium",
        tips: "Use the STAR method: Situation, Task, Action, Result.",
        expectedAnswer:
          "Using the STAR method, I describe the situation, the task I had, the actions I took like prioritizing tasks and collaborating, and the result which improved performance or user satisfaction.",
        keywords: ["STAR", "situation", "task", "action", "result", "collaboration", "performance"],
      },
      {
        id: 4,
        question: "How do you handle working under tight deadlines?",
        type: "HR",
        difficulty: "Easy",
        tips: "Show your time management skills and ability to prioritize.",
        expectedAnswer:
          "I break work into prioritized tasks, estimate time, communicate risks early, avoid scope creep, and focus on delivering MVP first before enhancements.",
        keywords: ["prioritize", "time management", "communicate", "MVP", "deadlines"],
      },
      {
        id: 5,
        question: "What is your understanding of Agile methodology?",
        type: "Technical",
        difficulty: "Easy",
        tips: "Mention Scrum, sprints, daily standups, and iterative development.",
        expectedAnswer:
          "Agile is an iterative approach emphasizing customer feedback and continuous improvement. Scrum uses sprints, standups, reviews, and retrospectives to deliver increments.",
        keywords: ["Agile", "Scrum", "sprints", "standups", "retrospectives", "iterative"],
      },
    ],
    Infosys: [
      {
        id: 1,
        question: "Why do you want to join Infosys?",
        type: "HR",
        difficulty: "Easy",
        tips: "Research the company values and align with your career goals.",
      },
      {
        id: 2,
        question: "What is polymorphism in object-oriented programming?",
        type: "Technical",
        difficulty: "Medium",
        tips: "Explain with examples: method overloading and overriding.",
      },
      {
        id: 3,
        question: "How do you stay updated with new technologies?",
        type: "HR",
        difficulty: "Easy",
        tips: "Mention specific resources: blogs, courses, conferences.",
      },
    ],
    Wipro: [
      {
        id: 1,
        question: "Describe your experience with database management systems.",
        type: "Technical",
        difficulty: "Medium",
        tips: "Mention SQL, normalization, indexing, and performance optimization.",
      },
      {
        id: 2,
        question: "How do you handle conflicts in a team environment?",
        type: "Behavioral",
        difficulty: "Medium",
        tips: "Show communication skills and conflict resolution abilities.",
      },
      {
        id: 3,
        question: "What are your salary expectations?",
        type: "HR",
        difficulty: "Hard",
        tips: "Research market rates and be flexible while showing your value.",
      },
    ],
  }

  const currentQuestions = questions[selectedCompany as keyof typeof questions] || questions.TCS

  function evaluateCurrent() {
    const q = currentQuestions[currentQuestion] as any
    if (!q?.expectedAnswer) return null
    const result = evaluateFreeform(
      { prompt: q.question, expectedAnswer: q.expectedAnswer, keywords: q.keywords || [] },
      answer,
      { strict: strictMode },
    )
    setEvaluations((prev) => {
      const next = [...prev]
      next[currentQuestion] = result
      return next
    })
    return result
  }

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (isRunning && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(timeLeft - 1)
      }, 1000)
    } else if (timeLeft === 0) {
      nextQuestion()
    }
    return () => clearInterval(interval)
  }, [isRunning, timeLeft])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`
  }

  const startInterview = () => {
    setIsRunning(true)
    setCurrentQuestion(0)
    setAnswer("")
    setTimeLeft(300)
    setEvaluations([])
  }

  const nextQuestion = () => {
    evaluateCurrent()
    if (currentQuestion < currentQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
      setAnswer("")
      setTimeLeft(300)
    } else {
      finishInterview()
    }
  }

  const finishInterview = () => {
    evaluateCurrent()
    setIsRunning(false)
    setShowResults(true)
  }

  const resetInterview = () => {
    setCurrentQuestion(0)
    setAnswer("")
    setTimeLeft(300)
    setIsRunning(false)
    setShowResults(false)
    setIsRecording(false)
  }

  const toggleRecording = () => {
    setIsRecording(!isRecording)
    // In a real app, this would start/stop audio recording
  }

  if (showResults) {
    const scored = evaluations.filter(Boolean)
    const avg = scored.length ? scored.reduce((s, r) => s + r.score, 0) / scored.length : 0
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-xl font-bold">Mock Interview Results</h1>
            <Button onClick={resetInterview}>
              <RotateCcw className="h-4 w-4 mr-2" />
              Take Another Interview
            </Button>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Interview Completed!</CardTitle>
              <CardDescription>Here's your performance evaluation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-4xl font-bold text-primary mb-2">{avg.toFixed(1)}/10</div>
                <p className="text-muted-foreground">Overall Interview Score</p>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold">Per-Question Scores</h3>
                <div className="space-y-2">
                  {currentQuestions.map((q, idx) => {
                    const r = evaluations[idx]
                    return (
                      <div key={idx} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                        <span className="text-sm">
                          {idx + 1}. {q.type} — {q.difficulty}
                        </span>
                        <Badge variant="outline">{r ? `${r.score}/10` : "N/A"}</Badge>
                      </div>
                    )
                  })}
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="font-semibold">Recommendations:</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>• Practice explaining technical concepts more clearly</li>
                  <li>• Work on providing specific examples from your experience</li>
                  <li>• Improve your knowledge of system design principles</li>
                  <li>• Continue practicing behavioral interview questions</li>
                </ul>
              </div>

              <div className="flex space-x-4">
                <Button className="flex-1" onClick={() => (window.location.href = "/dashboard")}>
                  Back to Dashboard
                </Button>
                <Button variant="outline" className="flex-1 bg-transparent" onClick={resetInterview}>
                  Practice More
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (!isRunning) {
    return (
      <div className="min-h-screen bg-background">
        <header className="border-b bg-card">
          <div className="container mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <MessageSquare className="h-6 w-6 text-primary" />
              <h1 className="text-xl font-bold">Mock Interview</h1>
            </div>
            <Button onClick={() => (window.location.href = "/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </header>

        <div className="container mx-auto px-4 py-8">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-4">Ready for Your Mock Interview?</h2>
              <p className="text-muted-foreground text-balance">
                Practice with real interview questions from top companies
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <Card>
                <CardHeader>
                  <CardTitle>Interview Setup</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Select Company:</label>
                    <select
                      value={selectedCompany}
                      onChange={(e) => setSelectedCompany(e.target.value)}
                      className="w-full mt-1 p-2 border rounded-md"
                    >
                      {companies.map((company) => (
                        <option key={company} value={company}>
                          {company}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="flex justify-between">
                    <span>Questions:</span>
                    <span className="font-semibold">{currentQuestions.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Time per Question:</span>
                    <span className="font-semibold">5 minutes</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Question Types:</span>
                    <span className="font-semibold">HR, Technical, Behavioral</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Recording:</span>
                    <span className="font-semibold">Optional</span>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Interview Tips</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <span className="text-sm">Speak clearly and maintain good posture</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <span className="text-sm">Take time to think before answering</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <span className="text-sm">Use specific examples from your experience</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <span className="text-sm">Ask clarifying questions if needed</span>
                  </div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2"></div>
                    <span className="text-sm">Stay calm and confident throughout</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="text-center mt-8">
              <Button size="lg" onClick={startInterview}>
                <MessageSquare className="h-5 w-5 mr-2" />
                Start Mock Interview
              </Button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  const question = currentQuestions[currentQuestion]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-bold">Mock Interview</h1>
            <Badge variant="outline">{selectedCompany}</Badge>
            <Badge variant="secondary">{question.type}</Badge>
          </div>
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <Clock className="h-4 w-4" />
              <span className="font-mono text-lg">{formatTime(timeLeft)}</span>
            </div>
            <Button variant="outline" onClick={finishInterview}>
              End Interview
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Progress */}
        <div className="mb-6">
          <div className="flex justify-between text-sm mb-2">
            <span>
              Question {currentQuestion + 1} of {currentQuestions.length}
            </span>
            <span>{Math.round(((currentQuestion + 1) / currentQuestions.length) * 100)}% Complete</span>
          </div>
          <Progress value={((currentQuestion + 1) / currentQuestions.length) * 100} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Question */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle>Interview Question</CardTitle>
                <Badge
                  variant={
                    question.difficulty === "Easy"
                      ? "default"
                      : question.difficulty === "Medium"
                        ? "secondary"
                        : "destructive"
                  }
                >
                  {question.difficulty}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-muted rounded-lg">
                <p className="text-lg font-medium">{question.question}</p>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold text-sm">💡 Tip:</h3>
                <p className="text-sm text-muted-foreground">{question.tips}</p>
              </div>

              <div className="flex items-center space-x-2">
                <Button variant={isRecording ? "destructive" : "outline"} size="sm" onClick={toggleRecording}>
                  {isRecording ? (
                    <>
                      <MicOff className="h-4 w-4 mr-2" />
                      Stop Recording
                    </>
                  ) : (
                    <>
                      <Mic className="h-4 w-4 mr-2" />
                      Start Recording
                    </>
                  )}
                </Button>
                {isRecording && (
                  <div className="flex items-center space-x-2 text-red-500">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    <span className="text-sm">Recording...</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Answer */}
          <Card>
            <CardHeader>
              <CardTitle>Your Answer</CardTitle>
              <CardDescription>
                Speak or type your response. Toggle Strict mode for exact-match scoring.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-2">
                <Switch id="strict-mode" checked={strictMode} onCheckedChange={setStrictMode} />
                <Label htmlFor="strict-mode" className="text-sm">
                  Strict mode (exact match)
                </Label>
              </div>

              <SpeechInput value={answer} onChange={setAnswer} placeholder="Speak or type your answer here..." />

              {answer.trim() &&
                (() => {
                  const q: any = currentQuestions[currentQuestion]
                  if (!q?.expectedAnswer) return null
                  const r = evaluateFreeform(
                    { prompt: q.question, expectedAnswer: q.expectedAnswer, keywords: q.keywords || [] },
                    answer,
                    { strict: strictMode },
                  )
                  return (
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <p className="text-sm font-medium text-blue-800">Live Estimate: {r.score}/10</p>
                      <p className="text-xs text-blue-700">
                        Exact match: {r.breakdown.exactMatch ? "Yes" : "No"} · Keywords {r.breakdown.keywordHits}/
                        {r.breakdown.totalKeywords}
                      </p>
                    </div>
                  )
                })()}

              <div className="flex justify-between">
                <div className="text-sm text-muted-foreground">{answer.length} characters</div>
                <div className="flex space-x-2">
                  {currentQuestion > 0 && (
                    <Button variant="outline" size="sm" onClick={() => setCurrentQuestion(currentQuestion - 1)}>
                      <ArrowLeft className="h-4 w-4 mr-2" />
                      Previous
                    </Button>
                  )}
                  <Button size="sm" onClick={nextQuestion} disabled={!answer.trim()}>
                    {currentQuestion < currentQuestions.length - 1 ? (
                      <>
                        Next Question
                        <ArrowRight className="h-4 w-4 ml-2" />
                      </>
                    ) : (
                      <>
                        Finish Interview
                        <CheckCircle className="h-4 w-4 ml-2" />
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
