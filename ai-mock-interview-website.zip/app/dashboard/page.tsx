"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Building2, Code, MessageSquare, Bot, BarChart3, LogOut, Clock, Trophy, Target, ArrowRight } from "lucide-react"

export default function Dashboard() {
  const [user] = useState({
    name: "John Doe",
    email: "user@interview.ai",
    completedTests: 12,
    averageScore: 8.5,
  })

  const companies = [
    { name: "TCS", logo: "🏢", rounds: 4, difficulty: "Medium", color: "bg-blue-500" },
    { name: "Infosys", logo: "💼", rounds: 3, difficulty: "Easy", color: "bg-green-500" },
    { name: "Wipro", logo: "🏭", rounds: 5, difficulty: "Hard", color: "bg-red-500" },
    { name: "Accenture", logo: "⚡", rounds: 3, difficulty: "Medium", color: "bg-yellow-500" },
  ]

  const recentTests = [
    { name: "TCS Coding Test", score: 9, date: "2 days ago", type: "coding" },
    { name: "Infosys Mock Interview", score: 8, date: "1 week ago", type: "interview" },
    { name: "AI Avatar Practice", score: 7, date: "1 week ago", type: "avatar" },
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Bot className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold">InterviewAI Dashboard</h1>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-sm text-muted-foreground">Welcome, {user.name}</span>
            <Button variant="outline" size="sm" onClick={() => (window.location.href = "/")}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Trophy className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{user.completedTests}</p>
                  <p className="text-sm text-muted-foreground">Tests Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Target className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{user.averageScore}/10</p>
                  <p className="text-sm text-muted-foreground">Average Score</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Building2 className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">{companies.length}</p>
                  <p className="text-sm text-muted-foreground">Companies Available</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-2">
                <Clock className="h-5 w-5 text-primary" />
                <div>
                  <p className="text-2xl font-bold">24h</p>
                  <p className="text-sm text-muted-foreground">Time Practiced</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Actions */}
          <div className="lg:col-span-2 space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Start your interview preparation journey</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button
                    className="h-20 flex-col space-y-2 bg-transparent"
                    variant="outline"
                    onClick={() => (window.location.href = "/companies")}
                  >
                    <Building2 className="h-6 w-6" />
                    <span>Browse Companies</span>
                  </Button>
                  <Button
                    className="h-20 flex-col space-y-2 bg-transparent"
                    variant="outline"
                    onClick={() => (window.location.href = "/coding-test")}
                  >
                    <Code className="h-6 w-6" />
                    <span>Coding Test</span>
                  </Button>
                  <Button
                    className="h-20 flex-col space-y-2 bg-transparent"
                    variant="outline"
                    onClick={() => (window.location.href = "/mock-interview")}
                  >
                    <MessageSquare className="h-6 w-6" />
                    <span>Mock Interview</span>
                  </Button>
                  <Button
                    className="h-20 flex-col space-y-2 bg-transparent"
                    variant="outline"
                    onClick={() => (window.location.href = "/ai-avatar")}
                  >
                    <Bot className="h-6 w-6" />
                    <span>AI Avatar</span>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Companies */}
            <Card>
              <CardHeader>
                <CardTitle>Featured Companies</CardTitle>
                <CardDescription>Practice with real company interview processes</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {companies.map((company, index) => (
                    <Card
                      key={index}
                      className="cursor-pointer hover:shadow-md transition-shadow"
                      onClick={() =>
                        (window.location.href = `/companies?company=${company.name.toLowerCase().replace(/\s+/g, "-")}`)
                      }
                    >
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <div className="text-2xl">{company.logo}</div>
                            <div>
                              <h3 className="font-semibold">{company.name}</h3>
                              <p className="text-sm text-muted-foreground">{company.rounds} rounds</p>
                            </div>
                          </div>
                          <Badge
                            variant={
                              company.difficulty === "Easy"
                                ? "default"
                                : company.difficulty === "Medium"
                                  ? "secondary"
                                  : "destructive"
                            }
                          >
                            {company.difficulty}
                          </Badge>
                        </div>
                        <Button size="sm" className="w-full">
                          Start Preparation
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Progress */}
            <Card>
              <CardHeader>
                <CardTitle>Your Progress</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Overall Progress</span>
                    <span>75%</span>
                  </div>
                  <Progress value={75} />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Coding Skills</span>
                    <span>85%</span>
                  </div>
                  <Progress value={85} />
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span>Communication</span>
                    <span>70%</span>
                  </div>
                  <Progress value={70} />
                </div>
              </CardContent>
            </Card>

            {/* Recent Tests */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Tests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentTests.map((test, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                      <div>
                        <p className="font-medium text-sm">{test.name}</p>
                        <p className="text-xs text-muted-foreground">{test.date}</p>
                      </div>
                      <Badge variant="outline">{test.score}/10</Badge>
                    </div>
                  ))}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-4 bg-transparent"
                  onClick={() => (window.location.href = "/results")}
                >
                  <BarChart3 className="h-4 w-4 mr-2" />
                  View All Results
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
