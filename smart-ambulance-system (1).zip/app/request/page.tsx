'use client'

import React, { useState, useEffect } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import type { EmergencyType, Location, Hospital } from '@/lib/types'

const emergencyTypes: { value: EmergencyType; label: string; icon: string }[] = [
  { value: 'accident', label: 'Road Accident', icon: '🚗' },
  { value: 'heart_attack', label: 'Heart Attack', icon: '❤️' },
  { value: 'stroke', label: 'Stroke / Paralysis', icon: '🧠' },
  { value: 'breathing', label: 'Breathing Difficulty', icon: '🫁' },
  { value: 'fire', label: 'Fire / Burns', icon: '🔥' },
  { value: 'other', label: 'Other Emergency', icon: '🏥' },
]

const demoHospitals: Hospital[] = [
  {
    id: 'h1',
    name: 'City General Hospital',
    location: { lat: 28.6225, lng: 77.2105 },
    address: 'NH-44, Near Delhi Gate',
    phone: '+91-11-4444-4444',
    availableBeds: 45,
    availableIcuBeds: 12,
    specialties: ['Trauma', 'Surgery', 'Emergency'],
    rating: 4.8,
    distance: 2.3,
  },
  {
    id: 'h2',
    name: 'Apollo Emergency Care',
    location: { lat: 28.6185, lng: 77.2165 },
    address: 'Main Street, Central Delhi',
    phone: '+91-11-4400-4400',
    availableBeds: 28,
    availableIcuBeds: 8,
    specialties: ['Cardiology', 'Neurology', 'Emergency'],
    rating: 4.9,
    distance: 3.1,
  },
  {
    id: 'h3',
    name: 'St. Paul Medical Center',
    location: { lat: 28.6145, lng: 77.2095 },
    address: 'Park Road Junction',
    phone: '+91-11-4500-4500',
    availableBeds: 52,
    availableIcuBeds: 15,
    specialties: ['Orthopedics', 'General Surgery'],
    rating: 4.6,
    distance: 1.8,
  },
]

export default function RequestPage() {
  const [step, setStep] = useState<'step1' | 'step2' | 'step3' | 'step4' | 'step5' | 'step6'>('step1')
  const [selectedType, setSelectedType] = useState<EmergencyType>('accident')
  const [victimName, setVictimName] = useState('')
  const [victimPhone, setVictimPhone] = useState('')
  const [description, setDescription] = useState('')
  const [location, setLocation] = useState<Location>({ lat: 28.6139, lng: 77.209 })
  const [selectedHospital, setSelectedHospital] = useState<Hospital>(demoHospitals[0])

  // Auto-detect location on mount
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({ lat: position.coords.latitude, lng: position.coords.longitude })
        },
        () => {
          setLocation({ lat: 28.6139 + (Math.random() - 0.5) * 0.05, lng: 77.209 + (Math.random() - 0.5) * 0.05 })
        }
      )
    }
  }, [])

  const steps = [
    { number: 1, title: 'Emergency Request', icon: '📞' },
    { number: 2, title: 'Hospital Selection', icon: '🏥' },
    { number: 3, title: 'Route Optimization', icon: '🛣️' },
    { number: 4, title: 'Ambulance Dispatch', icon: '🚑' },
    { number: 5, title: 'SOS Alerts', icon: '🆘' },
    { number: 6, title: 'Hospital Arrival', icon: '✓' },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 p-4 md:p-8">
      {/* Header */}
      <div className="max-w-6xl mx-auto mb-12">
        <Link href="/" className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-8">
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
          Back to Home
        </Link>
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-primary to-orange-400 bg-clip-text text-transparent mb-2">Emergency Response Flow</h1>
        <p className="text-muted-foreground">Interactive prototype showing how the system responds to emergencies</p>
      </div>

      {/* Progress Steps */}
      <div className="max-w-6xl mx-auto mb-12">
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2 md:gap-4">
          {steps.map((s, idx) => {
            const stepKeys: (typeof step)[] = ['step1', 'step2', 'step3', 'step4', 'step5', 'step6']
            const isActive = stepKeys.indexOf(step) >= idx
            return (
              <button
                key={s.number}
                onClick={() => setStep(stepKeys[idx])}
                className={`p-3 rounded-lg transition-all ${
                  isActive
                    ? 'bg-gradient-to-br from-primary to-orange-500 text-white shadow-lg shadow-primary/50'
                    : 'bg-secondary/50 text-muted-foreground hover:bg-secondary'
                }`}
              >
                <div className="text-lg mb-1">{s.icon}</div>
                <div className="text-xs md:text-sm font-semibold">{s.title}</div>
              </button>
            )
          })}
        </div>
      </div>

      <div className="max-w-6xl mx-auto grid lg:grid-cols-3 gap-8">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Step 1: Emergency Request Form */}
          {step === 'step1' && (
            <Card className="glass-card border-primary/30 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-primary/10 to-orange-500/10 border-b border-primary/20">
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">📞</span>
                  Step 1: Emergency Request
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label className="text-sm font-semibold mb-2 block">Victim Name</Label>
                      <Input
                        placeholder="Enter victim name"
                        value={victimName}
                        onChange={(e) => setVictimName(e.target.value)}
                        className="bg-secondary/50 border-border/50"
                      />
                    </div>
                    <div>
                      <Label className="text-sm font-semibold mb-2 block">Phone Number</Label>
                      <Input
                        placeholder="+91-98765-00000"
                        value={victimPhone}
                        onChange={(e) => setVictimPhone(e.target.value)}
                        className="bg-secondary/50 border-border/50"
                      />
                    </div>
                  </div>

                  <div>
                    <Label className="text-sm font-semibold mb-2 block">Emergency Type</Label>
                    <Select value={selectedType} onValueChange={(v) => setSelectedType(v as EmergencyType)}>
                      <SelectTrigger className="bg-secondary/50 border-border/50">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {emergencyTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            {type.icon} {type.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label className="text-sm font-semibold mb-2 block">Description</Label>
                    <Textarea
                      placeholder="Describe the emergency situation..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                      className="bg-secondary/50 border-border/50 min-h-24"
                    />
                  </div>

                  <div className="bg-secondary/30 p-4 rounded-lg border border-border/50">
                    <div className="flex items-center gap-2 mb-2">
                      <svg className="w-4 h-4 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
                      </svg>
                      <span className="text-xs font-semibold text-cyan-400">Auto-Detected Location</span>
                    </div>
                    <p className="text-sm text-muted-foreground">📍 Latitude: {location.lat.toFixed(4)}, Longitude: {location.lng.toFixed(4)}</p>
                  </div>
                </div>

                <Button
                  onClick={() => setStep('step2')}
                  className="w-full bg-gradient-to-r from-primary to-orange-500 hover:shadow-lg hover:shadow-primary/50"
                >
                  Next: Hospital Selection →
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Step 2: Hospital Selection */}
          {step === 'step2' && (
            <Card className="glass-card border-emerald-500/30 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-emerald-500/10 to-green-500/10 border-b border-emerald-500/20">
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">🏥</span>
                  Step 2: AI Hospital Recommendation
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <p className="text-sm text-muted-foreground mb-4">System analyzed your emergency type and location to recommend optimal hospitals</p>
                <div className="space-y-3">
                  {demoHospitals.map((hospital, idx) => (
                    <div
                      key={hospital.id}
                      onClick={() => setSelectedHospital(hospital)}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        selectedHospital.id === hospital.id
                          ? 'border-emerald-500 bg-emerald-500/10'
                          : 'border-border/50 bg-secondary/30 hover:bg-secondary/50'
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h3 className="font-semibold text-foreground">{hospital.name}</h3>
                          <p className="text-xs text-muted-foreground">{hospital.address}</p>
                        </div>
                        <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                          #{idx + 1} Recommended
                        </Badge>
                      </div>
                      <div className="grid grid-cols-4 gap-2 text-xs">
                        <div>
                          <span className="text-muted-foreground">Distance</span>
                          <p className="font-bold text-foreground">{hospital.distance} km</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Beds</span>
                          <p className="font-bold text-emerald-400">{hospital.availableBeds}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">ICU</span>
                          <p className="font-bold text-blue-400">{hospital.availableIcuBeds}</p>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Rating</span>
                          <p className="font-bold text-primary">⭐ {hospital.rating}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setStep('step1')} className="flex-1">
                    ← Back
                  </Button>
                  <Button onClick={() => setStep('step3')} className="flex-1 bg-gradient-to-r from-emerald-500 to-green-500 hover:shadow-lg hover:shadow-emerald-500/50">
                    Next: Route Optimization →
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 3: Route Optimization via CCTV */}
          {step === 'step3' && (
            <Card className="glass-card border-cyan-500/30 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border-b border-cyan-500/20">
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">🛣️</span>
                  Step 3: CCTV-Powered Route Optimization
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-4">
                  <div className="bg-gradient-to-r from-cyan-500/10 to-blue-500/10 p-4 rounded-lg border border-cyan-500/20">
                    <h3 className="font-semibold text-cyan-400 mb-3 flex items-center gap-2">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                      </svg>
                      Active CCTV Cameras on Route
                    </h3>
                    <div className="grid grid-cols-2 gap-2">
                      {[
                        { name: 'Central Highway Junction', condition: 'clear' },
                        { name: 'Main Street Crossing', condition: 'moderate' },
                        { name: 'Hospital Road Camera', condition: 'clear' },
                        { name: 'North Gate Flyover', condition: 'clear' },
                      ].map((cam, idx) => (
                        <div key={idx} className="text-xs p-2 bg-secondary/50 rounded border border-border/50">
                          <p className="text-foreground font-medium">{cam.name}</p>
                          <Badge className={`mt-1 text-[10px] ${
                            cam.condition === 'clear' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                          }`}>
                            {cam.condition}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <Card className="bg-secondary/50 border-border/50 p-4">
                      <p className="text-xs text-muted-foreground mb-1">Estimated Time</p>
                      <p className="text-2xl font-bold text-primary">8-10 min</p>
                    </Card>
                    <Card className="bg-secondary/50 border-border/50 p-4">
                      <p className="text-xs text-muted-foreground mb-1">Distance</p>
                      <p className="text-2xl font-bold text-emerald-400">{selectedHospital.distance} km</p>
                    </Card>
                  </div>

                  <div className="bg-emerald-500/10 p-4 rounded-lg border border-emerald-500/20">
                    <p className="text-xs text-emerald-400 flex items-start gap-2">
                      <svg className="w-4 h-4 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      <span>Green Corridor activated! Traffic signals optimized for fastest emergency vehicle route.</span>
                    </p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setStep('step2')} className="flex-1">
                    ← Back
                  </Button>
                  <Button onClick={() => setStep('step4')} className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-500 hover:shadow-lg hover:shadow-cyan-500/50">
                    Next: Dispatch Ambulance →
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 4: Ambulance Dispatch */}
          {step === 'step4' && (
            <Card className="glass-card border-orange-500/30 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-orange-500/10 to-red-500/10 border-b border-orange-500/20">
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">🚑</span>
                  Step 4: Ambulance Dispatch & Tracking
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-4">
                  <div className="bg-gradient-to-r from-orange-500/10 to-red-500/10 p-4 rounded-lg border border-orange-500/20">
                    <h3 className="font-semibold text-orange-400 mb-3">Nearest Ambulance Assigned</h3>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Ambulance ID</span>
                        <Badge className="bg-primary/20 text-primary">AMB-2847</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Driver</span>
                        <span className="text-sm font-semibold">Rajesh Kumar</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Distance from scene</span>
                        <span className="text-sm font-semibold text-emerald-400">0.8 km</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">ETA to victim</span>
                        <span className="text-sm font-semibold text-primary">3 min</span>
                      </div>
                    </div>
                  </div>

                  <div className="bg-secondary/30 p-4 rounded-lg border border-border/50">
                    <h3 className="font-semibold text-foreground mb-3">Live Tracking</h3>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-emerald-400"></div>
                        <span>Ambulance picked up from station</span>
                        <span className="text-xs text-muted-foreground ml-auto">00:45</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></div>
                        <span className="text-primary font-semibold">En route to emergency location</span>
                        <span className="text-xs text-muted-foreground ml-auto">01:23</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full bg-slate-600"></div>
                        <span className="text-muted-foreground">Arriving at hospital</span>
                        <span className="text-xs text-muted-foreground ml-auto">Pending...</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setStep('step3')} className="flex-1">
                    ← Back
                  </Button>
                  <Button onClick={() => setStep('step5')} className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:shadow-lg hover:shadow-orange-500/50">
                    Next: SOS Alerts →
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 5: SOS Alerts */}
          {step === 'step5' && (
            <Card className="glass-card border-red-500/30 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-red-500/10 to-pink-500/10 border-b border-red-500/20">
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">🆘</span>
                  Step 5: SOS Broadcast to Nearby Citizens
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <p className="text-sm text-muted-foreground mb-4">SOS alerts automatically sent to 8 people within 500m radius of accident</p>
                <div className="space-y-3">
                  {[
                    { name: 'Suresh Verma', phone: '+91-98765-11111', status: 'acknowledged' },
                    { name: 'Meera Kapoor', phone: '+91-98765-22222', status: 'acknowledged' },
                    { name: 'Arun Nair', phone: '+91-98765-33333', status: 'responded' },
                    { name: 'Sunita Devi', phone: '+91-98765-44444', status: 'acknowledged' },
                    { name: 'Rahul Sharma', phone: '+91-98765-55555', status: 'pending' },
                    { name: 'Kavita Singh', phone: '+91-98765-66666', status: 'acknowledged' },
                    { name: 'Deepak Kumar', phone: '+91-98765-77777', status: 'responded' },
                    { name: 'Anita Gupta', phone: '+91-98765-88888', status: 'acknowledged' },
                  ].map((person, idx) => (
                    <div key={idx} className="p-3 bg-secondary/30 rounded-lg border border-border/50 flex items-center justify-between">
                      <div>
                        <p className="text-sm font-semibold text-foreground">{person.name}</p>
                        <p className="text-xs text-muted-foreground">{person.phone}</p>
                      </div>
                      <Badge className={`${
                        person.status === 'responded' ? 'bg-emerald-500/20 text-emerald-400' :
                        person.status === 'acknowledged' ? 'bg-blue-500/20 text-blue-400' :
                        'bg-slate-500/20 text-slate-400'
                      }`}>
                        {person.status}
                      </Badge>
                    </div>
                  ))}
                </div>

                <div className="bg-blue-500/10 p-4 rounded-lg border border-blue-500/20">
                  <p className="text-xs text-blue-400 flex items-start gap-2">
                    <svg className="w-4 h-4 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>SMS alerts include exact GPS location with Google Maps link for instant navigation</span>
                  </p>
                </div>
                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setStep('step4')} className="flex-1">
                    ← Back
                  </Button>
                  <Button onClick={() => setStep('step6')} className="flex-1 bg-gradient-to-r from-red-500 to-pink-500 hover:shadow-lg hover:shadow-red-500/50">
                    Final: Hospital Arrival →
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Step 6: Hospital Arrival */}
          {step === 'step6' && (
            <Card className="glass-card border-emerald-500/30 overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-emerald-500/10 to-green-500/10 border-b border-emerald-500/20">
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">✓</span>
                  Step 6: Emergency Complete - Victim at Hospital
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="bg-emerald-500/10 p-6 rounded-lg border border-emerald-500/20 text-center">
                  <div className="text-5xl mb-3">🎉</div>
                  <h3 className="text-2xl font-bold text-emerald-400 mb-2">Emergency Response Complete!</h3>
                  <p className="text-sm text-muted-foreground">Victim safely transported to hospital</p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  <Card className="bg-secondary/50 border-border/50 p-4 text-center">
                    <p className="text-xs text-muted-foreground mb-1">Total Response Time</p>
                    <p className="text-2xl font-bold text-primary">12 min</p>
                  </Card>
                  <Card className="bg-secondary/50 border-border/50 p-4 text-center">
                    <p className="text-xs text-muted-foreground mb-1">Distance Traveled</p>
                    <p className="text-2xl font-bold text-orange-400">{selectedHospital.distance} km</p>
                  </Card>
                  <Card className="bg-secondary/50 border-border/50 p-4 text-center">
                    <p className="text-xs text-muted-foreground mb-1">Hospital Beds Free</p>
                    <p className="text-2xl font-bold text-emerald-400">{selectedHospital.availableBeds}</p>
                  </Card>
                </div>

                <div className="space-y-3">
                  <h3 className="font-semibold text-foreground">Hospital Summary</h3>
                  <div className="bg-secondary/30 p-4 rounded-lg border border-border/50 space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Hospital</span>
                      <span className="font-semibold">{selectedHospital.name}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Address</span>
                      <span className="text-sm">{selectedHospital.address}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Contact</span>
                      <span className="font-semibold text-primary">{selectedHospital.phone}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm">Rating</span>
                      <span className="font-semibold">⭐ {selectedHospital.rating}</span>
                    </div>
                  </div>
                </div>

                <div className="border-t border-border/50 pt-4">
                  <p className="text-xs text-muted-foreground mb-4">This prototype demonstrates the complete emergency response workflow.</p>
                  <div className="flex gap-3 flex-col md:flex-row">
                    <Button onClick={() => setStep('step1')} className="flex-1 bg-gradient-to-r from-primary to-orange-500 hover:shadow-lg hover:shadow-primary/50">
                      Start Over
                    </Button>
                    <Link href="/cctv" className="flex-1">
                      <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:shadow-lg hover:shadow-cyan-500/50">
                        View CCTV Center
                      </Button>
                    </Link>
                    <Link href="/" className="flex-1">
                      <Button variant="outline" className="w-full bg-transparent">
                        Back to Home
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar - Key Features */}
        <div className="space-y-6">
          <Card className="glass-card border-primary/30 sticky top-8">
            <CardHeader className="bg-gradient-to-r from-primary/10 to-orange-500/10 border-b border-primary/20">
              <CardTitle className="text-lg flex items-center gap-2">
                <svg className="w-5 h-5 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Key Features
              </CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-3">
              <div className="space-y-2 text-sm">
                <div className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-muted-foreground">Auto GPS location detection</span>
                </div>
                <div className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-emerald-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-muted-foreground">AI-powered hospital selection</span>
                </div>
                <div className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-cyan-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-muted-foreground">CCTV-based route optimization</span>
                </div>
                <div className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-orange-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-muted-foreground">Real-time ambulance tracking</span>
                </div>
                <div className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-red-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-muted-foreground">SOS alerts to nearby citizens</span>
                </div>
                <div className="flex items-start gap-2">
                  <svg className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  <span className="text-muted-foreground">Green corridor traffic control</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="glass-card border-blue-500/30">
            <CardHeader className="bg-gradient-to-r from-blue-500/10 to-cyan-500/10 border-b border-blue-500/20">
              <CardTitle className="text-lg">Live Statistics</CardTitle>
            </CardHeader>
            <CardContent className="p-4 space-y-3">
              <div className="text-center">
                <p className="text-3xl font-bold text-primary">285</p>
                <p className="text-xs text-muted-foreground">Emergencies Today</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-emerald-400">8.2</p>
                <p className="text-xs text-muted-foreground">Avg Response (min)</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-orange-400">47</p>
                <p className="text-xs text-muted-foreground">Active Ambulances</p>
              </div>
              <div className="text-center">
                <p className="text-3xl font-bold text-cyan-400">126</p>
                <p className="text-xs text-muted-foreground">CCTV Cameras</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
