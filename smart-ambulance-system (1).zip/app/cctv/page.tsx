"use client"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Camera,
  AlertTriangle,
  MapPin,
  Phone,
  Clock,
  Activity,
  Zap,
  Eye,
  Radio,
  Navigation,
  Shield,
  Users,
  ChevronRight,
  RefreshCw,
  Bell,
  Ambulance,
  CircleDot,
} from "lucide-react"
import Link from "next/link"

interface CCTVCamera {
  id: string
  name: string
  location: { lat: number; lng: number }
  address: string
  status: "online" | "offline" | "maintenance"
  roadCondition: "clear" | "moderate" | "congested" | "blocked" | "accident"
  lastUpdated: string
  coverageRadius: number
  detectionEnabled: boolean
}

interface DetectedAccident {
  id: string
  cameraId: string
  location: { lat: number; lng: number }
  address: string
  timestamp: string
  severity: "minor" | "moderate" | "severe" | "critical"
  vehiclesInvolved: number
  casualties: number
  description: string
  autoRequestSent: boolean
  emergencyRequestId?: string
  sosAlertsSent: number
  status: "detected" | "verified" | "responding" | "resolved"
  camera?: { name: string; address: string }
}

interface RouteObstacle {
  id: string
  cameraId: string
  location: { lat: number; lng: number }
  type: string
  severity: "low" | "medium" | "high"
  description: string
  detectedAt: string
  camera?: { name: string; address: string }
}

export default function CCTVMonitoringPage() {
  const [cameras, setCameras] = useState<CCTVCamera[]>([])
  const [accidents, setAccidents] = useState<DetectedAccident[]>([])
  const [obstacles, setObstacles] = useState<RouteObstacle[]>([])
  const [selectedCamera, setSelectedCamera] = useState<CCTVCamera | null>(null)
  const [isSimulating, setIsSimulating] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date())
  const [stats, setStats] = useState({
    totalCameras: 0,
    onlineCameras: 0,
    detectionEnabled: 0,
  })

  const fetchData = useCallback(async () => {
    try {
      const [camerasRes, accidentsRes, obstaclesRes] = await Promise.all([
        fetch("/api/cctv"),
        fetch("/api/cctv/accidents"),
        fetch("/api/cctv/route-optimizer"),
      ])

      const camerasData = await camerasRes.json()
      const accidentsData = await accidentsRes.json()
      const obstaclesData = await obstaclesRes.json()

      if (camerasData.success) {
        setCameras(camerasData.cameras)
        setStats({
          totalCameras: camerasData.totalCameras,
          onlineCameras: camerasData.onlineCameras,
          detectionEnabled: camerasData.detectionEnabled,
        })
      }

      if (accidentsData.success) {
        setAccidents(accidentsData.accidents)
      }

      if (obstaclesData.success) {
        setObstacles(obstaclesData.obstacles)
      }

      setLastUpdate(new Date())
    } catch (error) {
      console.error("Error fetching CCTV data:", error)
    }
  }, [])

  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, 5000)
    return () => clearInterval(interval)
  }, [fetchData])

  const simulateAccidentDetection = async () => {
    setIsSimulating(true)
    try {
      // Pick a random online camera
      const onlineCameras = cameras.filter((c) => c.status === "online" && c.roadCondition !== "accident")
      if (onlineCameras.length === 0) {
        alert("No available cameras for simulation")
        setIsSimulating(false)
        return
      }

      const randomCamera = onlineCameras[Math.floor(Math.random() * onlineCameras.length)]

      const response = await fetch("/api/cctv", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          cameraId: randomCamera.id,
          severity: ["minor", "moderate", "severe", "critical"][Math.floor(Math.random() * 4)],
          vehiclesInvolved: Math.floor(Math.random() * 3) + 1,
          casualties: Math.floor(Math.random() * 2),
          description: "AI detected vehicle collision with potential injuries",
        }),
      })

      const data = await response.json()
      if (data.success) {
        await fetchData()
      }
    } catch (error) {
      console.error("Error simulating accident:", error)
    } finally {
      setIsSimulating(false)
    }
  }

  const getRoadConditionColor = (condition: string) => {
    switch (condition) {
      case "clear":
        return "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
      case "moderate":
        return "bg-amber-500/20 text-amber-400 border-amber-500/30"
      case "congested":
        return "bg-orange-500/20 text-orange-400 border-orange-500/30"
      case "blocked":
        return "bg-red-500/20 text-red-400 border-red-500/30"
      case "accident":
        return "bg-red-600/30 text-red-300 border-red-500/50 animate-pulse"
      default:
        return "bg-muted text-muted-foreground"
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical":
        return "bg-red-600 text-white"
      case "severe":
        return "bg-red-500 text-white"
      case "moderate":
        return "bg-orange-500 text-white"
      case "minor":
        return "bg-amber-500 text-black"
      default:
        return "bg-muted"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online":
        return "bg-emerald-500"
      case "offline":
        return "bg-red-500"
      case "maintenance":
        return "bg-amber-500"
      default:
        return "bg-muted"
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-3">
                <div className="relative">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-orange-600 flex items-center justify-center">
                    <Camera className="w-5 h-5 text-white" />
                  </div>
                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border-2 border-background animate-pulse" />
                </div>
                <div>
                  <h1 className="text-lg font-bold text-foreground">CCTV Command Center</h1>
                  <p className="text-xs text-muted-foreground">AI-Powered Accident Detection</p>
                </div>
              </Link>
            </div>

            <div className="flex items-center gap-3">
              <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-full bg-secondary/50 border border-border/50">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs text-muted-foreground">
                  Last update: {lastUpdate.toLocaleTimeString()}
                </span>
              </div>
              <Button variant="outline" size="sm" onClick={fetchData} className="bg-transparent">
                <RefreshCw className="w-4 h-4" />
              </Button>
              <Link href="/admin">
                <Button variant="outline" size="sm" className="bg-transparent">
                  Admin
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 space-y-6">
        {/* Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Total Cameras</p>
                  <p className="text-2xl font-bold text-foreground">{stats.totalCameras}</p>
                </div>
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Camera className="w-5 h-5 text-primary" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Online</p>
                  <p className="text-2xl font-bold text-emerald-400">{stats.onlineCameras}</p>
                </div>
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
                  <Activity className="w-5 h-5 text-emerald-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">AI Detection</p>
                  <p className="text-2xl font-bold text-cyan-400">{stats.detectionEnabled}</p>
                </div>
                <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center">
                  <Eye className="w-5 h-5 text-cyan-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-muted-foreground">Active Alerts</p>
                  <p className="text-2xl font-bold text-red-400">
                    {accidents.filter((a) => a.status !== "resolved").length}
                  </p>
                </div>
                <div className="w-10 h-10 rounded-xl bg-red-500/10 flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Simulate Button */}
        <Card className="bg-gradient-to-r from-primary/10 to-orange-500/10 border-primary/30">
          <CardContent className="p-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/20 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground">AI Accident Detection Demo</h3>
                  <p className="text-sm text-muted-foreground">
                    Simulate an accident detection to see the full system response
                  </p>
                </div>
              </div>
              <Button
                onClick={simulateAccidentDetection}
                disabled={isSimulating}
                className="bg-primary hover:bg-primary/90 text-white"
              >
                {isSimulating ? (
                  <>
                    <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                    Detecting...
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4 mr-2" />
                    Simulate Accident Detection
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Camera Grid */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold text-foreground flex items-center gap-2">
                <Camera className="w-5 h-5 text-primary" />
                Camera Network
              </h2>
              <Badge variant="outline" className="text-xs">
                {cameras.filter((c) => c.roadCondition === "accident").length} accidents detected
              </Badge>
            </div>

            <div className="grid md:grid-cols-2 gap-3">
              {cameras.map((camera) => (
                <Card
                  key={camera.id}
                  className={`bg-card/50 border-border/50 backdrop-blur-sm cursor-pointer transition-all hover:border-primary/50 ${
                    selectedCamera?.id === camera.id ? "border-primary ring-1 ring-primary/30" : ""
                  } ${camera.roadCondition === "accident" ? "border-red-500/50 bg-red-500/5" : ""}`}
                  onClick={() => setSelectedCamera(camera)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <div className="relative">
                          <div className="w-8 h-8 rounded-lg bg-secondary flex items-center justify-center">
                            <Camera className="w-4 h-4 text-muted-foreground" />
                          </div>
                          <div className={`absolute -top-0.5 -right-0.5 w-2.5 h-2.5 rounded-full ${getStatusColor(camera.status)} border border-background`} />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-foreground">{camera.name}</p>
                          <p className="text-xs text-muted-foreground">{camera.id.toUpperCase()}</p>
                        </div>
                      </div>
                      {camera.detectionEnabled && (
                        <div className="px-1.5 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30">
                          <Eye className="w-3 h-3 text-cyan-400" />
                        </div>
                      )}
                    </div>

                    <div className="flex items-center gap-2 mb-2">
                      <MapPin className="w-3 h-3 text-muted-foreground" />
                      <span className="text-xs text-muted-foreground truncate">{camera.address}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <Badge className={`text-xs ${getRoadConditionColor(camera.roadCondition)}`}>
                        {camera.roadCondition === "accident" && (
                          <AlertTriangle className="w-3 h-3 mr-1" />
                        )}
                        {camera.roadCondition.charAt(0).toUpperCase() + camera.roadCondition.slice(1)}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{camera.coverageRadius}m</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-4">
            {/* Selected Camera Details */}
            {selectedCamera && (
              <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm flex items-center gap-2">
                    <Camera className="w-4 h-4 text-primary" />
                    Camera Feed
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Simulated Camera Feed */}
                  <div className="relative aspect-video rounded-lg bg-gradient-to-br from-slate-800 to-slate-900 overflow-hidden">
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="text-center">
                        <Camera className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
                        <p className="text-xs text-muted-foreground">Live Feed</p>
                        <p className="text-xs text-muted-foreground">{selectedCamera.name}</p>
                      </div>
                    </div>
                    <div className="absolute top-2 left-2 flex items-center gap-1.5 px-2 py-1 rounded bg-black/50 backdrop-blur-sm">
                      <div className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
                      <span className="text-xs text-white">LIVE</span>
                    </div>
                    <div className="absolute bottom-2 right-2 px-2 py-1 rounded bg-black/50 backdrop-blur-sm">
                      <span className="text-xs text-white font-mono">
                        {new Date().toLocaleTimeString()}
                      </span>
                    </div>
                    {selectedCamera.roadCondition === "accident" && (
                      <div className="absolute inset-0 bg-red-500/20 flex items-center justify-center">
                        <div className="px-4 py-2 rounded-lg bg-red-600/90 text-white text-sm font-medium animate-pulse">
                          ACCIDENT DETECTED
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Status</span>
                      <Badge variant="outline" className={`${getStatusColor(selectedCamera.status)} text-white text-xs`}>
                        {selectedCamera.status}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Road Condition</span>
                      <Badge className={`${getRoadConditionColor(selectedCamera.roadCondition)} text-xs`}>
                        {selectedCamera.roadCondition}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">AI Detection</span>
                      <span className="text-foreground">
                        {selectedCamera.detectionEnabled ? "Enabled" : "Disabled"}
                      </span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Coverage</span>
                      <span className="text-foreground">{selectedCamera.coverageRadius}m radius</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Detected Accidents */}
            <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center justify-between">
                  <span className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4 text-red-500" />
                    Detected Accidents
                  </span>
                  <Badge variant="destructive" className="text-xs">
                    {accidents.filter((a) => a.status !== "resolved").length}
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 max-h-80 overflow-y-auto">
                {accidents.length === 0 ? (
                  <div className="text-center py-8">
                    <Shield className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                    <p className="text-sm text-muted-foreground">No accidents detected</p>
                    <p className="text-xs text-muted-foreground">All roads are clear</p>
                  </div>
                ) : (
                  accidents.map((accident) => (
                    <div
                      key={accident.id}
                      className="p-3 rounded-lg bg-secondary/30 border border-border/50 space-y-2"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <Badge className={`${getSeverityColor(accident.severity)} text-xs`}>
                            {accident.severity}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {accident.status}
                          </Badge>
                        </div>
                        <span className="text-xs text-muted-foreground">
                          {new Date(accident.timestamp).toLocaleTimeString()}
                        </span>
                      </div>
                      
                      <p className="text-sm text-foreground">{accident.camera?.name}</p>
                      <p className="text-xs text-muted-foreground">{accident.address}</p>
                      
                      <div className="flex items-center gap-4 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <CircleDot className="w-3 h-3" />
                          {accident.vehiclesInvolved} vehicles
                        </span>
                        <span className="flex items-center gap-1">
                          <Users className="w-3 h-3" />
                          {accident.casualties} casualties
                        </span>
                      </div>

                      <div className="flex items-center gap-2 pt-2 border-t border-border/50">
                        {accident.autoRequestSent && (
                          <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30 text-xs">
                            <Ambulance className="w-3 h-3 mr-1" />
                            Ambulance Dispatched
                          </Badge>
                        )}
                        {accident.sosAlertsSent > 0 && (
                          <Badge className="bg-cyan-500/20 text-cyan-400 border-cyan-500/30 text-xs">
                            <Bell className="w-3 h-3 mr-1" />
                            {accident.sosAlertsSent} SOS Sent
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>

            {/* Road Obstacles */}
            <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Navigation className="w-4 h-4 text-amber-500" />
                  Route Obstacles
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {obstacles.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-4">
                    No obstacles detected
                  </p>
                ) : (
                  obstacles.map((obstacle) => (
                    <div
                      key={obstacle.id}
                      className="p-2 rounded-lg bg-secondary/30 border border-border/50"
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-medium text-foreground capitalize">
                          {obstacle.type}
                        </span>
                        <Badge
                          className={`text-xs ${
                            obstacle.severity === "high"
                              ? "bg-red-500/20 text-red-400"
                              : obstacle.severity === "medium"
                              ? "bg-amber-500/20 text-amber-400"
                              : "bg-emerald-500/20 text-emerald-400"
                          }`}
                        >
                          {obstacle.severity}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{obstacle.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {obstacle.camera?.name}
                      </p>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>
        </div>

        {/* How It Works Section */}
        <Card className="bg-card/50 border-border/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-primary" />
              How AI Detection Works
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="text-center p-4 rounded-lg bg-secondary/30">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                  <Camera className="w-6 h-6 text-primary" />
                </div>
                <h4 className="font-medium text-foreground mb-1">1. Monitor</h4>
                <p className="text-xs text-muted-foreground">
                  CCTV cameras continuously monitor roads with AI-powered computer vision
                </p>
              </div>
              <div className="text-center p-4 rounded-lg bg-secondary/30">
                <div className="w-12 h-12 rounded-xl bg-red-500/10 flex items-center justify-center mx-auto mb-3">
                  <AlertTriangle className="w-6 h-6 text-red-500" />
                </div>
                <h4 className="font-medium text-foreground mb-1">2. Detect</h4>
                <p className="text-xs text-muted-foreground">
                  AI instantly detects accidents, analyzes severity, and counts casualties
                </p>
              </div>
              <div className="text-center p-4 rounded-lg bg-secondary/30">
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center mx-auto mb-3">
                  <Ambulance className="w-6 h-6 text-emerald-500" />
                </div>
                <h4 className="font-medium text-foreground mb-1">3. Dispatch</h4>
                <p className="text-xs text-muted-foreground">
                  Auto-dispatches nearest ambulance with optimal route calculation
                </p>
              </div>
              <div className="text-center p-4 rounded-lg bg-secondary/30">
                <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center mx-auto mb-3">
                  <Bell className="w-6 h-6 text-cyan-500" />
                </div>
                <h4 className="font-medium text-foreground mb-1">4. Alert</h4>
                <p className="text-xs text-muted-foreground">
                  SOS alerts sent to nearby people with exact location for immediate assistance
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
