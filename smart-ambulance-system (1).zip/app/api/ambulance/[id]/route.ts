import { NextResponse } from 'next/server'
import { ambulances, emergencyRequests } from '@/lib/store'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const ambulance = ambulances.find((a) => a.id === id || a.driverId === id)

  if (!ambulance) {
    return NextResponse.json(
      { success: false, error: 'Ambulance not found' },
      { status: 404 }
    )
  }

  // Get current request if any
  let currentRequest = null
  if (ambulance.currentRequestId) {
    currentRequest = emergencyRequests.find((r) => r.id === ambulance.currentRequestId)
  }

  return NextResponse.json({
    success: true,
    ambulance,
    currentRequest,
  })
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { location, isAvailable } = body

    const ambulanceIndex = ambulances.findIndex((a) => a.id === id || a.driverId === id)
    if (ambulanceIndex === -1) {
      return NextResponse.json(
        { success: false, error: 'Ambulance not found' },
        { status: 404 }
      )
    }

    // Update ambulance
    if (location) {
      ambulances[ambulanceIndex].location = location
    }
    if (typeof isAvailable === 'boolean') {
      ambulances[ambulanceIndex].isAvailable = isAvailable
    }
    ambulances[ambulanceIndex].lastUpdated = new Date()

    return NextResponse.json({
      success: true,
      ambulance: ambulances[ambulanceIndex],
    })
  } catch (error) {
    console.error('Ambulance update error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
