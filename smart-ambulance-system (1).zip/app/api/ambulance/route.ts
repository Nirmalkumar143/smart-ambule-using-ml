import { NextResponse } from 'next/server'
import { ambulances, calculateDistance } from '@/lib/store'
import type { Location } from '@/lib/types'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const lat = searchParams.get('lat')
  const lng = searchParams.get('lng')
  const available = searchParams.get('available')

  let filteredAmbulances = [...ambulances]

  // Filter by availability
  if (available === 'true') {
    filteredAmbulances = filteredAmbulances.filter((a) => a.isAvailable)
  } else if (available === 'false') {
    filteredAmbulances = filteredAmbulances.filter((a) => !a.isAvailable)
  }

  // Add distance if location provided
  if (lat && lng) {
    const location: Location = { lat: parseFloat(lat), lng: parseFloat(lng) }
    filteredAmbulances = filteredAmbulances.map((amb) => ({
      ...amb,
      distance: Math.round(calculateDistance(location, amb.location) * 10) / 10,
    }))
    // Sort by distance
    filteredAmbulances.sort((a, b) => (a as any).distance - (b as any).distance)
  }

  return NextResponse.json({
    success: true,
    ambulances: filteredAmbulances,
    total: ambulances.length,
    available: ambulances.filter((a) => a.isAvailable).length,
  })
}
