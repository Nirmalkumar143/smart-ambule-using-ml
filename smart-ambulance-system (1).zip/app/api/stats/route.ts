import { NextResponse } from 'next/server'
import { emergencyRequests, ambulances, trafficSignals, hospitals } from '@/lib/store'
import type { SystemStats } from '@/lib/types'

export async function GET() {
  const now = new Date()
  const startOfDay = new Date(now.getFullYear(), now.getMonth(), now.getDate())

  // Calculate statistics
  const activeEmergencies = emergencyRequests.filter(
    (r) => !['completed', 'cancelled'].includes(r.status)
  ).length

  const completedToday = emergencyRequests.filter(
    (r) => r.status === 'completed' && r.completedAt && new Date(r.completedAt) >= startOfDay
  ).length

  const availableAmbulances = ambulances.filter((a) => a.isAvailable).length
  const greenCorridorsActive = trafficSignals.filter((s) => s.overrideActive).length

  // Calculate average response time (simulated)
  const completedRequests = emergencyRequests.filter((r) => r.status === 'completed')
  let averageResponseTime = 8 // Default 8 minutes
  if (completedRequests.length > 0) {
    const totalTime = completedRequests.reduce((acc, r) => {
      if (r.completedAt && r.createdAt) {
        const responseTime = (new Date(r.completedAt).getTime() - new Date(r.createdAt).getTime()) / 60000
        return acc + responseTime
      }
      return acc + 8
    }, 0)
    averageResponseTime = Math.round(totalTime / completedRequests.length)
  }

  const stats: SystemStats = {
    activeEmergencies,
    availableAmbulances,
    totalAmbulances: ambulances.length,
    averageResponseTime,
    completedToday,
    greenCorridorsActive,
  }

  // Additional detailed stats
  const emergencyTypeBreakdown = emergencyRequests.reduce((acc, r) => {
    acc[r.emergencyType] = (acc[r.emergencyType] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  const hospitalCapacity = hospitals.map((h) => ({
    id: h.id,
    name: h.name,
    availableBeds: h.availableBeds,
    totalBeds: h.totalBeds,
    occupancyRate: Math.round(((h.totalBeds - h.availableBeds) / h.totalBeds) * 100),
  }))

  return NextResponse.json({
    success: true,
    stats,
    emergencyTypeBreakdown,
    hospitalCapacity,
    timestamp: now.toISOString(),
  })
}
