import { NextResponse } from 'next/server'
import { trafficSignals, findNearbyTrafficSignals, calculateDistance } from '@/lib/store'
import type { Location, TrafficLightStatus } from '@/lib/types'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const lat = searchParams.get('lat')
  const lng = searchParams.get('lng')
  const radius = searchParams.get('radius')

  // If location provided, get nearby signals
  if (lat && lng) {
    const location: Location = { lat: parseFloat(lat), lng: parseFloat(lng) }
    const radiusKm = radius ? parseFloat(radius) : 0.1
    const nearbySignals = findNearbyTrafficSignals(location, radiusKm)

    return NextResponse.json({
      success: true,
      signals: nearbySignals.map((s) => ({
        ...s,
        distance: Math.round(calculateDistance(location, s.location) * 1000), // meters
      })),
    })
  }

  return NextResponse.json({
    success: true,
    signals: trafficSignals,
    total: trafficSignals.length,
    activeOverrides: trafficSignals.filter((s) => s.overrideActive).length,
  })
}

// Traffic override endpoint
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { signal_id, action, duration, ambulanceLocation } = body

    // If ambulance location provided, find and update nearby signals
    if (ambulanceLocation) {
      const nearbySignals = findNearbyTrafficSignals(ambulanceLocation, 0.15) // 150m radius

      const updatedSignals = nearbySignals.map((signal) => {
        const signalIndex = trafficSignals.findIndex((s) => s.id === signal.id)
        if (signalIndex !== -1) {
          trafficSignals[signalIndex].currentStatus = 'green'
          trafficSignals[signalIndex].overrideActive = true
          trafficSignals[signalIndex].overrideUntil = new Date(Date.now() + (duration || 60) * 1000)
          trafficSignals[signalIndex].lastUpdated = new Date()
        }
        return trafficSignals[signalIndex]
      })

      return NextResponse.json({
        success: true,
        message: `Updated ${updatedSignals.length} traffic signals to GREEN`,
        signals: updatedSignals,
      })
    }

    // Single signal override
    if (signal_id) {
      const signalIndex = trafficSignals.findIndex((s) => s.id === signal_id)
      if (signalIndex === -1) {
        return NextResponse.json(
          { success: false, error: 'Traffic signal not found' },
          { status: 404 }
        )
      }

      const newStatus: TrafficLightStatus = action?.toUpperCase() === 'GREEN' ? 'green' : 'red'
      trafficSignals[signalIndex].currentStatus = newStatus
      trafficSignals[signalIndex].overrideActive = newStatus === 'green'
      trafficSignals[signalIndex].overrideUntil = new Date(Date.now() + (duration || 60) * 1000)
      trafficSignals[signalIndex].lastUpdated = new Date()

      return NextResponse.json({
        success: true,
        message: `Traffic signal ${signal_id} set to ${newStatus.toUpperCase()}`,
        signal: trafficSignals[signalIndex],
      })
    }

    return NextResponse.json(
      { success: false, error: 'signal_id or ambulanceLocation required' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Traffic override error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
