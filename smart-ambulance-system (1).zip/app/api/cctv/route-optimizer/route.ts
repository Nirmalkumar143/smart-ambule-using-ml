import { NextResponse } from 'next/server'
import {
  calculateOptimalRoute,
  cctvCameras,
  routeObstacles,
  findCamerasOnRoute,
} from '@/lib/store'

// POST - Get optimized route based on real-time CCTV data
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { origin, destination, emergencyType = 'accident' } = body

    if (!origin || !destination) {
      return NextResponse.json({ 
        success: false, 
        error: 'Origin and destination required' 
      }, { status: 400 })
    }

    // Calculate optimal route
    const route = calculateOptimalRoute(origin, destination, emergencyType)

    // Get camera details
    const cameras = findCamerasOnRoute(origin, destination)
    const cameraDetails = cameras.map(cam => ({
      id: cam.id,
      name: cam.name,
      location: cam.location,
      roadCondition: cam.roadCondition,
      status: cam.status,
    }))

    // Get real-time obstacles
    const obstacles = route.obstacles.map(obs => ({
      ...obs,
      camera: cctvCameras.find(c => c.id === obs.cameraId)?.name,
      detectedAt: obs.detectedAt.toISOString(),
    }))

    return NextResponse.json({
      success: true,
      route: {
        ...route,
        cameras: cameraDetails,
        obstacles,
      },
      recommendations: route.isOptimal 
        ? ['Proceed on current route', 'Green corridor will be activated']
        : [
            'Consider alternative route',
            `Obstacle detected: ${route.reason}`,
            route.alternativeRoutes[1].obstacleCount === 0 
              ? 'Route 3 is completely clear' 
              : 'Route 2 has fewer obstacles'
          ],
    })
  } catch (error) {
    console.error('Error calculating route:', error)
    return NextResponse.json({ success: false, error: 'Failed to calculate route' }, { status: 500 })
  }
}

// GET - Get all current obstacles on roads
export async function GET() {
  const obstaclesWithCameras = routeObstacles.map(obs => {
    const camera = cctvCameras.find(c => c.id === obs.cameraId)
    return {
      ...obs,
      detectedAt: obs.detectedAt.toISOString(),
      camera: camera ? {
        name: camera.name,
        address: camera.address,
      } : null,
    }
  })

  const roadConditions = cctvCameras.reduce((acc, cam) => {
    acc[cam.roadCondition] = (acc[cam.roadCondition] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  return NextResponse.json({
    success: true,
    obstacles: obstaclesWithCameras,
    roadConditions,
    totalCameras: cctvCameras.length,
    onlineCameras: cctvCameras.filter(c => c.status === 'online').length,
  })
}
