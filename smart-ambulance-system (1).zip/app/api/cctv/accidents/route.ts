import { NextResponse } from 'next/server'
import { detectedAccidents, cctvCameras, sosAlerts } from '@/lib/store'

// GET - Fetch all detected accidents
export async function GET() {
  const accidentsWithDetails = detectedAccidents.map(accident => {
    const camera = cctvCameras.find(c => c.id === accident.cameraId)
    const alerts = sosAlerts.filter(a => a.accidentId === accident.id)
    
    return {
      ...accident,
      timestamp: accident.timestamp.toISOString(),
      camera: camera ? {
        name: camera.name,
        address: camera.address,
      } : null,
      sosAlerts: alerts.map(a => ({
        recipientName: a.recipientName,
        status: a.status,
        distance: a.distance,
      })),
    }
  }).sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

  return NextResponse.json({
    success: true,
    accidents: accidentsWithDetails,
    total: accidentsWithDetails.length,
    active: accidentsWithDetails.filter(a => a.status !== 'resolved').length,
  })
}
