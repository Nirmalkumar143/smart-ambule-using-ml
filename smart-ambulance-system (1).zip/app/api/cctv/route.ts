import { NextResponse } from 'next/server'
import {
  cctvCameras,
  detectedAccidents,
  routeObstacles,
  generateId,
  findNearbyPeople,
  findNearestAmbulance,
  emergencyRequests,
  ambulances,
  sosAlerts,
  calculateDistance,
} from '@/lib/store'
import type { DetectedAccident, SOSAlert, EmergencyRequest } from '@/lib/types'

// GET - Fetch all CCTV cameras and their status
export async function GET() {
  return NextResponse.json({
    success: true,
    cameras: cctvCameras.map(cam => ({
      ...cam,
      lastUpdated: cam.lastUpdated.toISOString(),
    })),
    totalCameras: cctvCameras.length,
    onlineCameras: cctvCameras.filter(c => c.status === 'online').length,
    detectionEnabled: cctvCameras.filter(c => c.detectionEnabled).length,
  })
}

// POST - Report detected accident (simulates AI detection from CCTV)
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const {
      cameraId,
      severity = 'moderate',
      vehiclesInvolved = 1,
      casualties = 0,
      description = 'Accident detected by AI system',
    } = body

    // Find the camera
    const camera = cctvCameras.find(c => c.id === cameraId)
    if (!camera) {
      return NextResponse.json({ success: false, error: 'Camera not found' }, { status: 404 })
    }

    // Create accident record
    const accidentId = generateId()
    const accident: DetectedAccident = {
      id: accidentId,
      cameraId,
      location: camera.location,
      address: camera.address,
      timestamp: new Date(),
      severity,
      vehiclesInvolved,
      casualties,
      description,
      autoRequestSent: false,
      sosAlertsSent: 0,
      status: 'detected',
    }

    detectedAccidents.push(accident)

    // Update camera road condition
    camera.roadCondition = 'accident'
    camera.lastUpdated = new Date()

    // Auto-create emergency request
    const nearestAmbulance = findNearestAmbulance(camera.location)
    
    const emergencyRequest: EmergencyRequest = {
      id: generateId(),
      victimId: 'cctv-auto',
      victimName: 'CCTV Auto-Detection',
      victimPhone: 'AI-System',
      location: camera.location,
      address: camera.address,
      emergencyType: 'accident',
      description: `[AUTO-DETECTED] ${description}. Severity: ${severity}. Vehicles: ${vehiclesInvolved}. Potential casualties: ${casualties}`,
      status: nearestAmbulance ? 'assigned' : 'pending',
      assignedAmbulanceId: nearestAmbulance?.id,
      assignedDriverId: nearestAmbulance?.driverId,
      createdAt: new Date(),
      updatedAt: new Date(),
      eta: nearestAmbulance ? Math.round(calculateDistance(nearestAmbulance.location, camera.location) * 3) : undefined,
    }

    emergencyRequests.push(emergencyRequest)

    // Update ambulance status
    if (nearestAmbulance) {
      const ambIndex = ambulances.findIndex(a => a.id === nearestAmbulance.id)
      if (ambIndex !== -1) {
        ambulances[ambIndex].isAvailable = false
        ambulances[ambIndex].currentRequestId = emergencyRequest.id
      }
    }

    accident.autoRequestSent = true
    accident.emergencyRequestId = emergencyRequest.id
    accident.status = 'verified'

    // Send SOS to nearby people
    const nearbyPeople = findNearbyPeople(camera.location, 0.5)
    const sentAlerts: SOSAlert[] = []

    for (const person of nearbyPeople.slice(0, 5)) {
      const alert: SOSAlert = {
        id: generateId(),
        accidentId,
        recipientPhone: person.phone,
        recipientName: person.name,
        location: camera.location,
        address: camera.address,
        message: `EMERGENCY SOS: Accident detected at ${camera.address}. Location: https://maps.google.com/?q=${camera.location.lat},${camera.location.lng}. If you're nearby, please assist until ambulance arrives. Ambulance ETA: ${emergencyRequest.eta || 'Dispatching'} minutes.`,
        sentAt: new Date(),
        status: 'sent',
        distance: person.distance,
      }
      sosAlerts.push(alert)
      sentAlerts.push(alert)
    }

    accident.sosAlertsSent = sentAlerts.length

    return NextResponse.json({
      success: true,
      accident: {
        ...accident,
        timestamp: accident.timestamp.toISOString(),
      },
      emergencyRequest: {
        ...emergencyRequest,
        createdAt: emergencyRequest.createdAt.toISOString(),
        updatedAt: emergencyRequest.updatedAt.toISOString(),
      },
      ambulanceAssigned: nearestAmbulance ? {
        id: nearestAmbulance.id,
        vehicleNumber: nearestAmbulance.vehicleNumber,
        driverName: nearestAmbulance.driverName,
        eta: emergencyRequest.eta,
      } : null,
      sosAlerts: {
        sent: sentAlerts.length,
        recipients: sentAlerts.map(a => ({
          name: a.recipientName,
          distance: `${(a.distance * 1000).toFixed(0)}m away`,
        })),
      },
    })
  } catch (error) {
    console.error('Error processing accident detection:', error)
    return NextResponse.json({ success: false, error: 'Failed to process accident' }, { status: 500 })
  }
}
