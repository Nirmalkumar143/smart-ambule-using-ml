import { NextResponse } from 'next/server'
import { emergencyRequests, ambulances } from '@/lib/store'
import type { RequestStatus } from '@/lib/types'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params
  const emergencyRequest = emergencyRequests.find((r) => r.id === id)

  if (!emergencyRequest) {
    return NextResponse.json(
      { success: false, error: 'Request not found' },
      { status: 404 }
    )
  }

  // Get assigned ambulance info if any
  let ambulanceInfo = null
  if (emergencyRequest.assignedAmbulanceId) {
    const ambulance = ambulances.find((a) => a.id === emergencyRequest.assignedAmbulanceId)
    if (ambulance) {
      ambulanceInfo = {
        id: ambulance.id,
        vehicleNumber: ambulance.vehicleNumber,
        driverName: ambulance.driverName,
        location: ambulance.location,
      }
    }
  }

  return NextResponse.json({
    success: true,
    request: emergencyRequest,
    ambulance: ambulanceInfo,
  })
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { status, ambulanceId, driverId } = body

    const requestIndex = emergencyRequests.findIndex((r) => r.id === id)
    if (requestIndex === -1) {
      return NextResponse.json(
        { success: false, error: 'Request not found' },
        { status: 404 }
      )
    }

    // Update request
    const updatedRequest = { ...emergencyRequests[requestIndex] }

    if (status) {
      updatedRequest.status = status as RequestStatus
      if (status === 'completed') {
        updatedRequest.completedAt = new Date()
      }
    }

    if (ambulanceId) {
      updatedRequest.assignedAmbulanceId = ambulanceId
      // Mark ambulance as unavailable
      const ambulance = ambulances.find((a) => a.id === ambulanceId)
      if (ambulance) {
        ambulance.isAvailable = false
        ambulance.currentRequestId = id
      }
    }

    if (driverId) {
      updatedRequest.assignedDriverId = driverId
    }

    updatedRequest.updatedAt = new Date()
    emergencyRequests[requestIndex] = updatedRequest

    // If completed, release ambulance
    if (status === 'completed' && updatedRequest.assignedAmbulanceId) {
      const ambulance = ambulances.find((a) => a.id === updatedRequest.assignedAmbulanceId)
      if (ambulance) {
        ambulance.isAvailable = true
        ambulance.currentRequestId = undefined
      }
    }

    return NextResponse.json({
      success: true,
      request: updatedRequest,
    })
  } catch (error) {
    console.error('Update error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
