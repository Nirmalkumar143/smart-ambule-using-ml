import { NextResponse } from 'next/server'
import {
  emergencyRequests,
  ambulances,
  generateId,
  findNearestAmbulance,
} from '@/lib/store'
import { getBestHospital } from '@/lib/ml-service'
import type { EmergencyRequest, EmergencyType } from '@/lib/types'

export async function GET() {
  return NextResponse.json({
    success: true,
    requests: emergencyRequests,
    count: emergencyRequests.length,
  })
}

export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { victimName, victimPhone, location, emergencyType, description } = body

    // Validate required fields
    if (!victimName || !victimPhone || !location || !emergencyType) {
      return NextResponse.json(
        { success: false, error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Find nearest ambulance
    const nearestAmbulance = findNearestAmbulance(location)
    if (!nearestAmbulance) {
      return NextResponse.json(
        { success: false, error: 'No ambulances available at the moment' },
        { status: 503 }
      )
    }

    // Get ML hospital recommendation
    const hospitalRecommendation = getBestHospital(location, emergencyType as EmergencyType)

    // Create emergency request
    const newRequest: EmergencyRequest = {
      id: generateId(),
      victimId: generateId(),
      victimName,
      victimPhone,
      location,
      emergencyType,
      description,
      status: 'pending',
      recommendedHospitalId: hospitalRecommendation?.hospitalId,
      createdAt: new Date(),
      updatedAt: new Date(),
      eta: hospitalRecommendation?.estimatedArrival,
    }

    // Add to store
    emergencyRequests.push(newRequest)

    // Simulate notification to driver (in real app, this would be WebSocket/Push)
    console.log(`[NOTIFICATION] Alert sent to ambulance ${nearestAmbulance.vehicleNumber}`)

    return NextResponse.json({
      success: true,
      request: newRequest,
      nearestAmbulance: {
        id: nearestAmbulance.id,
        vehicleNumber: nearestAmbulance.vehicleNumber,
        driverName: nearestAmbulance.driverName,
      },
      recommendedHospital: hospitalRecommendation,
    })
  } catch (error) {
    console.error('Emergency request error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
