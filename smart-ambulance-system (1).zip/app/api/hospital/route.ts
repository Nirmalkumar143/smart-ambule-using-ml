import { NextResponse } from 'next/server'
import { hospitals, calculateDistance } from '@/lib/store'
import { recommendHospital } from '@/lib/ml-service'
import type { Location, EmergencyType } from '@/lib/types'

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const lat = searchParams.get('lat')
  const lng = searchParams.get('lng')
  const recommend = searchParams.get('recommend')
  const type = searchParams.get('type') as EmergencyType | null

  let hospitalList = [...hospitals]

  // Add distance if location provided
  if (lat && lng) {
    const location: Location = { lat: parseFloat(lat), lng: parseFloat(lng) }
    hospitalList = hospitalList.map((h) => ({
      ...h,
      distance: Math.round(calculateDistance(location, h.location) * 10) / 10,
    }))
    // Sort by distance
    hospitalList.sort((a, b) => (a.distance || 0) - (b.distance || 0))

    // If recommend=true, return ML recommendations
    if (recommend === 'true' && type) {
      const recommendations = recommendHospital(location, type)
      return NextResponse.json({
        success: true,
        recommendations,
        hospitals: hospitalList,
        total: hospitals.length,
      })
    }
  }

  return NextResponse.json({
    success: true,
    hospitals: hospitalList,
    recommendations: [], // Always include recommendations array
    total: hospitals.length,
  })
}

// ML-powered hospital recommendation
export async function POST(request: Request) {
  try {
    const body = await request.json()
    const { location, emergencyType } = body

    if (!location || !emergencyType) {
      return NextResponse.json(
        { success: false, error: 'location and emergencyType required' },
        { status: 400 }
      )
    }

    const recommendations = recommendHospital(location as Location, emergencyType as EmergencyType)

    return NextResponse.json({
      success: true,
      recommendations,
      bestHospital: recommendations[0] || null,
    })
  } catch (error) {
    console.error('Hospital recommendation error:', error)
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    )
  }
}
