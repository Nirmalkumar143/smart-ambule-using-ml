'use client'

import { useState, useEffect } from 'react'
import { DriverDashboard } from '@/components/driver-dashboard'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import type { Ambulance } from '@/lib/types'
import Link from 'next/link'

export default function DriverPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [selectedDriver, setSelectedDriver] = useState<string>('')
  const [ambulance, setAmbulance] = useState<Ambulance | null>(null)
  const [ambulances, setAmbulances] = useState<Ambulance[]>([])
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    const fetchAmbulances = async () => {
      try {
        const response = await fetch('/api/ambulance')
        const data = await response.json()
        if (data.success) {
          setAmbulances(data.ambulances)
        }
      } catch (error) {
        console.error('Failed to fetch ambulances:', error)
      }
    }
    fetchAmbulances()
  }, [])

  const handleLogin = async () => {
    if (!selectedDriver) return
    setIsLoading(true)
    try {
      const response = await fetch(`/api/ambulance/${selectedDriver}`)
      const data = await response.json()
      if (data.success) {
        setAmbulance(data.ambulance)
        setIsLoggedIn(true)
      }
    } catch (error) {
      console.error('Login failed:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setAmbulance(null)
    setSelectedDriver('')
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <div className="font-bold text-foreground">Driver Portal</div>
              <div className="text-[10px] text-muted-foreground">RapidRescue System</div>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            {isLoggedIn && ambulance && (
              <div className="text-right mr-4">
                <div className="text-xs text-muted-foreground">Logged in as</div>
                <div className="font-semibold text-foreground">{ambulance.driverName}</div>
              </div>
            )}
            {isLoggedIn && (
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                Logout
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="pt-16">
        {!isLoggedIn ? (
          <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
            <div className="w-full max-w-md px-4">
              <Card className="glass-card border-0">
                <CardHeader className="text-center pb-2">
                  <div className="w-20 h-20 mx-auto mb-4 rounded-2xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                    <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                    </svg>
                  </div>
                  <CardTitle className="text-2xl text-foreground">Driver Login</CardTitle>
                  <CardDescription>Select your ambulance to start receiving emergency requests</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Select Your Ambulance</label>
                    <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                      <SelectTrigger className="bg-secondary/50 border-border/50">
                        <SelectValue placeholder="Choose your ambulance" />
                      </SelectTrigger>
                      <SelectContent>
                        {ambulances.map((amb) => (
                          <SelectItem key={amb.id} value={amb.driverId}>
                            <div className="flex items-center gap-2">
                              <span className="font-medium">{amb.vehicleNumber}</span>
                              <span className="text-muted-foreground">- {amb.driverName}</span>
                              {!amb.isAvailable && (
                                <Badge variant="secondary" className="text-xs bg-yellow-500/20 text-yellow-400">
                                  Busy
                                </Badge>
                              )}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <Button
                    className="w-full h-12 bg-gradient-to-r from-blue-500 to-blue-600 hover:opacity-90"
                    onClick={handleLogin}
                    disabled={!selectedDriver || isLoading}
                  >
                    {isLoading ? (
                      <span className="flex items-center gap-2">
                        <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        Logging in...
                      </span>
                    ) : (
                      'Login to Dashboard'
                    )}
                  </Button>

                  <div className="text-center text-sm text-muted-foreground">
                    <p>Demo credentials are pre-loaded.</p>
                    <p>Select any driver to continue.</p>
                  </div>
                </CardContent>
              </Card>

              {/* Fleet Stats */}
              <div className="grid grid-cols-2 gap-4 mt-6">
                <Card className="glass-card border-0">
                  <CardContent className="p-4 text-center">
                    <div className="text-3xl font-bold text-emerald-400">
                      {ambulances.filter((a) => a.isAvailable).length}
                    </div>
                    <div className="text-sm text-muted-foreground">Available</div>
                  </CardContent>
                </Card>
                <Card className="glass-card border-0">
                  <CardContent className="p-4 text-center">
                    <div className="text-3xl font-bold text-blue-400">{ambulances.length}</div>
                    <div className="text-sm text-muted-foreground">Total Fleet</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        ) : ambulance ? (
          <div className="px-4 py-8">
            <DriverDashboard driverId={selectedDriver} ambulance={ambulance} />
          </div>
        ) : (
          <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
            <div className="text-center">
              <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <div className="text-muted-foreground">Loading dashboard...</div>
            </div>
          </div>
        )}
      </main>
    </div>
  )
}
