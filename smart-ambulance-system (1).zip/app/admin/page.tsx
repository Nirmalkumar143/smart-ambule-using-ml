'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { LiveMap } from '@/components/live-map'
import type { EmergencyRequest, Ambulance, TrafficSignal, Hospital, SystemStats } from '@/lib/types'
import Link from 'next/link'

export default function AdminPage() {
  const [stats, setStats] = useState<SystemStats | null>(null)
  const [emergencies, setEmergencies] = useState<EmergencyRequest[]>([])
  const [ambulances, setAmbulances] = useState<Ambulance[]>([])
  const [trafficSignals, setTrafficSignals] = useState<TrafficSignal[]>([])
  const [hospitals, setHospitals] = useState<Hospital[]>([])
  const [hospitalCapacity, setHospitalCapacity] = useState<any[]>([])
  const [emergencyBreakdown, setEmergencyBreakdown] = useState<Record<string, number>>({})
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('overview')

  const fetchData = useCallback(async () => {
    try {
      const [statsRes, emergencyRes, ambulanceRes, trafficRes, hospitalRes] = await Promise.all([
        fetch('/api/stats'),
        fetch('/api/emergency'),
        fetch('/api/ambulance'),
        fetch('/api/traffic'),
        fetch('/api/hospital'),
      ])

      const [statsData, emergencyData, ambulanceData, trafficData, hospitalData] = await Promise.all([
        statsRes.json(),
        emergencyRes.json(),
        ambulanceRes.json(),
        trafficRes.json(),
        hospitalRes.json(),
      ])

      if (statsData.success) {
        setStats(statsData.stats)
        setHospitalCapacity(statsData.hospitalCapacity)
        setEmergencyBreakdown(statsData.emergencyTypeBreakdown)
      }
      if (emergencyData.success) setEmergencies(emergencyData.requests)
      if (ambulanceData.success) setAmbulances(ambulanceData.ambulances)
      if (trafficData.success) setTrafficSignals(trafficData.signals)
      if (hospitalData.success) setHospitals(hospitalData.hospitals)
    } catch (error) {
      console.error('Failed to fetch data:', error)
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchData()
    const interval = setInterval(fetchData, 5000)
    return () => clearInterval(interval)
  }, [fetchData])

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      pending: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      assigned: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
      en_route_to_victim: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
      picked_up: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
      en_route_to_hospital: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      completed: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
      cancelled: 'bg-gray-500/20 text-gray-400 border-gray-500/30',
    }
    return colors[status] || 'bg-gray-500/20 text-gray-400'
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <div className="text-muted-foreground">Loading dashboard...</div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 glass border-b border-border/50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-orange-500 flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
              </svg>
            </div>
            <div>
              <div className="font-bold text-foreground">Admin Dashboard</div>
              <div className="text-[10px] text-muted-foreground">RapidRescue Control Center</div>
            </div>
          </Link>
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-sm">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-muted-foreground">Live</span>
            </div>
            <div className="text-sm text-muted-foreground">
              Updated: {new Date().toLocaleTimeString()}
            </div>
          </div>
        </div>
      </header>

      <main className="pt-20 pb-8 px-4 max-w-7xl mx-auto">
        {/* Stats Overview */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
          {[
            { label: 'Active Emergencies', value: stats?.activeEmergencies || 0, color: 'from-red-500 to-red-600', icon: '🚨' },
            { label: 'Available Ambulances', value: stats?.availableAmbulances || 0, color: 'from-emerald-500 to-emerald-600', icon: '🚑' },
            { label: 'Total Fleet', value: stats?.totalAmbulances || 0, color: 'from-blue-500 to-blue-600', icon: '📊' },
            { label: 'Avg Response (min)', value: stats?.averageResponseTime || 0, color: 'from-orange-500 to-orange-600', icon: '⏱️' },
            { label: 'Completed Today', value: stats?.completedToday || 0, color: 'from-indigo-500 to-indigo-600', icon: '✅' },
            { label: 'Green Corridors', value: stats?.greenCorridorsActive || 0, color: 'from-green-500 to-green-600', icon: '🟢' },
          ].map((stat, idx) => (
            <Card key={idx} className="glass-card border-0">
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-2xl">{stat.icon}</span>
                  <div className={`w-2 h-8 rounded-full bg-gradient-to-b ${stat.color}`} />
                </div>
                <div className="text-3xl font-bold text-foreground">{stat.value}</div>
                <div className="text-xs text-muted-foreground">{stat.label}</div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="glass-card border-0 p-1 mb-6">
            <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Live Map
            </TabsTrigger>
            <TabsTrigger value="emergencies" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Emergencies
            </TabsTrigger>
            <TabsTrigger value="ambulances" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Ambulances
            </TabsTrigger>
            <TabsTrigger value="hospitals" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Hospitals
            </TabsTrigger>
            <TabsTrigger value="traffic" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Traffic
            </TabsTrigger>
          </TabsList>

          {/* Live Map Tab */}
          <TabsContent value="overview">
            <div className="grid lg:grid-cols-3 gap-6">
              <Card className="glass-card border-0 lg:col-span-2 overflow-hidden">
                <LiveMap
                  ambulances={ambulances}
                  trafficSignals={trafficSignals}
                  hospitals={hospitals}
                  victimLocation={emergencies.find((e) => !['completed', 'cancelled'].includes(e.status))?.location}
                  className="h-[500px]"
                />
              </Card>

              <div className="space-y-6">
                {/* Active Emergencies */}
                <Card className="glass-card border-0">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg flex items-center gap-2 text-foreground">
                      <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                      Active Emergencies
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {emergencies.filter((e) => !['completed', 'cancelled'].includes(e.status)).length === 0 ? (
                      <div className="text-center py-8 text-muted-foreground">No active emergencies</div>
                    ) : (
                      <div className="space-y-3">
                        {emergencies
                          .filter((e) => !['completed', 'cancelled'].includes(e.status))
                          .slice(0, 4)
                          .map((emergency) => (
                            <div key={emergency.id} className="p-3 rounded-lg bg-red-500/5 border border-red-500/20">
                              <div className="flex items-center justify-between mb-1">
                                <span className="font-medium text-foreground">{emergency.victimName}</span>
                                <Badge className={getStatusColor(emergency.status)}>
                                  {emergency.status.replace(/_/g, ' ')}
                                </Badge>
                              </div>
                              <div className="text-sm text-muted-foreground capitalize">
                                {emergency.emergencyType.replace('_', ' ')}
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Emergency Type Breakdown */}
                <Card className="glass-card border-0">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg text-foreground">Emergency Types</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {Object.entries(emergencyBreakdown).map(([type, count]) => (
                        <div key={type} className="flex items-center justify-between">
                          <span className="text-sm text-muted-foreground capitalize">{type.replace('_', ' ')}</span>
                          <Badge variant="secondary">{count}</Badge>
                        </div>
                      ))}
                      {Object.keys(emergencyBreakdown).length === 0 && (
                        <div className="text-center py-4 text-muted-foreground text-sm">No data yet</div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Emergencies Tab */}
          <TabsContent value="emergencies">
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="text-foreground">All Emergency Requests</CardTitle>
                <CardDescription>Complete history of emergency requests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b border-border/50">
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">ID</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Victim</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Type</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Status</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Location</th>
                        <th className="text-left py-3 px-4 font-medium text-muted-foreground">Time</th>
                      </tr>
                    </thead>
                    <tbody>
                      {emergencies.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="text-center py-8 text-muted-foreground">
                            No emergency requests yet
                          </td>
                        </tr>
                      ) : (
                        emergencies.map((emergency) => (
                          <tr key={emergency.id} className="border-b border-border/30 hover:bg-white/5">
                            <td className="py-3 px-4 font-mono text-sm text-foreground">
                              {emergency.id.substring(0, 8).toUpperCase()}
                            </td>
                            <td className="py-3 px-4">
                              <div className="text-foreground">{emergency.victimName}</div>
                              <div className="text-sm text-muted-foreground">{emergency.victimPhone}</div>
                            </td>
                            <td className="py-3 px-4 capitalize text-foreground">
                              {emergency.emergencyType.replace('_', ' ')}
                            </td>
                            <td className="py-3 px-4">
                              <Badge className={getStatusColor(emergency.status)}>
                                {emergency.status.replace(/_/g, ' ')}
                              </Badge>
                            </td>
                            <td className="py-3 px-4 text-sm text-muted-foreground">
                              {emergency.location.lat.toFixed(4)}, {emergency.location.lng.toFixed(4)}
                            </td>
                            <td className="py-3 px-4 text-sm text-muted-foreground">
                              {new Date(emergency.createdAt).toLocaleString()}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Ambulances Tab */}
          <TabsContent value="ambulances">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {ambulances.map((ambulance) => (
                <Card key={ambulance.id} className={`glass-card border-0 ${ambulance.isAvailable ? 'ring-1 ring-emerald-500/30' : 'ring-1 ring-yellow-500/30'}`}>
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg text-foreground">{ambulance.vehicleNumber}</CardTitle>
                      <Badge className={ambulance.isAvailable ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'}>
                        {ambulance.isAvailable ? 'Available' : 'On Call'}
                      </Badge>
                    </div>
                    <CardDescription>{ambulance.driverName}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Location</span>
                        <span className="text-foreground">{ambulance.location.lat.toFixed(4)}, {ambulance.location.lng.toFixed(4)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Last Updated</span>
                        <span className="text-foreground">{new Date(ambulance.lastUpdated).toLocaleTimeString()}</span>
                      </div>
                      <div className="pt-2">
                        <span className="text-muted-foreground text-xs">Equipment:</span>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {ambulance.equipment.slice(0, 3).map((eq) => (
                            <Badge key={eq} variant="secondary" className="text-xs">
                              {eq}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Hospitals Tab */}
          <TabsContent value="hospitals">
            <div className="grid md:grid-cols-2 gap-4">
              {hospitalCapacity.map((hospital) => (
                <Card key={hospital.id} className="glass-card border-0">
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg text-foreground">{hospital.name}</CardTitle>
                      <Badge className={
                        hospital.occupancyRate > 90
                          ? 'bg-red-500/20 text-red-400 border-red-500/30'
                          : hospital.occupancyRate > 70
                            ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30'
                            : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                      }>
                        {hospital.occupancyRate}% Occupied
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Available Beds</span>
                        <span className="font-semibold text-emerald-400">
                          {hospital.availableBeds} / {hospital.totalBeds}
                        </span>
                      </div>
                      <div className="w-full bg-secondary rounded-full h-2">
                        <div
                          className={`h-2 rounded-full transition-all ${
                            hospital.occupancyRate > 90
                              ? 'bg-red-500'
                              : hospital.occupancyRate > 70
                                ? 'bg-yellow-500'
                                : 'bg-emerald-500'
                          }`}
                          style={{ width: `${hospital.occupancyRate}%` }}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Traffic Signals Tab */}
          <TabsContent value="traffic">
            <Card className="glass-card border-0">
              <CardHeader>
                <CardTitle className="text-foreground">Traffic Signal Control</CardTitle>
                <CardDescription>Green corridor management for emergency vehicles</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {trafficSignals.map((signal) => (
                    <div
                      key={signal.id}
                      className={`p-4 rounded-xl ${
                        signal.overrideActive
                          ? 'bg-emerald-500/10 border border-emerald-500/30'
                          : 'bg-secondary/50 border border-border/50'
                      }`}
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div
                          className={`w-6 h-6 rounded-full ${
                            signal.currentStatus === 'green'
                              ? 'bg-green-500 shadow-lg shadow-green-500/50'
                              : signal.currentStatus === 'yellow'
                                ? 'bg-yellow-500'
                                : 'bg-red-500'
                          }`}
                        />
                        <div>
                          <div className="font-medium text-foreground">{signal.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {signal.location.lat.toFixed(4)}, {signal.location.lng.toFixed(4)}
                          </div>
                        </div>
                      </div>
                      {signal.overrideActive && (
                        <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
                          Green Corridor Active
                        </Badge>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}
