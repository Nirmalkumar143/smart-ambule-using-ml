'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

export default function HomePage() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  return (
    <div className="relative w-full bg-background">
      {/* Animated background */}
      <div className="fixed inset-0 -z-10 overflow-hidden">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      {/* Navigation */}
      <nav className="sticky top-0 z-40 border-b border-border/50 bg-background/80 backdrop-blur-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-primary to-orange-500 flex items-center justify-center">
              <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div className="font-bold text-lg">SafeRoute</div>
          </div>

          <div className="flex items-center gap-6">
            <Link href="/request" className="text-sm font-medium hover:text-primary transition-colors">Request Help</Link>
            <Link href="/cctv" className="text-sm font-medium hover:text-primary transition-colors flex items-center gap-1">
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
              </svg>
              CCTV
            </Link>
            <Link href="/admin" className="text-sm font-medium hover:text-primary transition-colors">Admin</Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-[calc(100vh-4rem)] flex items-center justify-center overflow-hidden px-4 py-20">
        <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8" style={{ transform: `translateY(${scrollY * 0.3}px)` }}>
            <div className="space-y-4">
              <Badge className="w-fit bg-primary/20 text-primary border-primary/30 hover:bg-primary/30">Hackathon Innovation</Badge>
              <h1 className="text-5xl lg:text-6xl font-bold bg-gradient-to-r from-foreground via-primary to-orange-500 bg-clip-text text-transparent leading-tight">
                AI-Powered Emergency Response System
              </h1>
              <p className="text-xl text-muted-foreground">Real-time ambulance dispatch, CCTV accident detection, and intelligent route optimization using ML algorithms.</p>
            </div>

            <div className="flex flex-wrap gap-4">
              <Link href="/request">
                <Button size="lg" className="bg-gradient-to-r from-primary to-orange-500 hover:shadow-lg hover:shadow-primary/50 transition-all">
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                  Emergency Request
                </Button>
              </Link>
              <Link href="/cctv">
                <Button size="lg" variant="outline" className="border-cyan-500/30 hover:bg-cyan-500/10 bg-transparent">
                  <svg className="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  CCTV Control Center
                </Button>
              </Link>
            </div>

            <div className="grid grid-cols-3 gap-4 pt-4">
              <div>
                <div className="text-3xl font-bold text-primary">10+</div>
                <p className="text-sm text-muted-foreground">CCTV Cameras</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-accent">15</div>
                <p className="text-sm text-muted-foreground">Hospitals</p>
              </div>
              <div>
                <div className="text-3xl font-bold text-cyan-400">4.2min</div>
                <p className="text-sm text-muted-foreground">Avg Response</p>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="relative h-96 lg:h-full min-h-96">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/20 to-accent/20 rounded-2xl blur-xl animate-pulse" />
            <div className="absolute inset-0 rounded-2xl border border-primary/20 flex items-center justify-center overflow-hidden">
              <svg className="w-full h-full p-8 text-primary/20" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
              </svg>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Core Features</h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">Advanced emergency response powered by AI, CCTV detection, and real-time optimization</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: '🚑',
                title: 'Smart Ambulance Dispatch',
                description: 'ML-based nearest ambulance detection with real-time location tracking and automatic routing',
                color: 'from-red-500/20 to-red-600/20',
                accentColor: 'text-red-400',
              },
              {
                icon: '📹',
                title: 'CCTV Accident Detection',
                description: 'AI cameras auto-detect accidents and instantly dispatch ambulances without human intervention',
                color: 'from-cyan-500/20 to-blue-500/20',
                accentColor: 'text-cyan-400',
              },
              {
                icon: '🗺️',
                title: 'Smart Route Optimizer',
                description: 'Real-time traffic monitoring via CCTV to calculate fastest routes avoiding congestion',
                color: 'from-violet-500/20 to-purple-500/20',
                accentColor: 'text-violet-400',
              },
              {
                icon: '🏥',
                title: 'AI Hospital Recommendation',
                description: 'RandomForest ML model recommends optimal hospitals based on injury type and availability',
                color: 'from-emerald-500/20 to-green-500/20',
                accentColor: 'text-emerald-400',
              },
              {
                icon: '🚦',
                title: 'Green Corridor System',
                description: 'Automatic traffic signal override for emergency vehicles with real-time coordination',
                color: 'from-lime-500/20 to-yellow-500/20',
                accentColor: 'text-lime-400',
              },
              {
                icon: '🆘',
                title: 'SOS Alert Network',
                description: 'Broadcasts emergency alerts to nearby people with exact GPS coordinates for immediate assistance',
                color: 'from-orange-500/20 to-pink-500/20',
                accentColor: 'text-orange-400',
              },
            ].map((feature, idx) => (
              <Card key={idx} className={`glass-card border-0 bg-gradient-to-br ${feature.color} overflow-hidden hover:shadow-lg transition-all group`}>
                <CardContent className="p-6">
                  <div className="text-4xl mb-4">{feature.icon}</div>
                  <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Live Demo Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-transparent to-primary/5">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Live System Status</h2>
            <p className="text-lg text-muted-foreground">Real-time monitoring and metrics from the emergency response network</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { label: 'Active Ambulances', value: '42', icon: '🚑', color: 'text-red-400' },
              { label: 'Online Cameras', value: '10', icon: '📹', color: 'text-cyan-400' },
              { label: 'Hospitals Online', value: '15', icon: '🏥', color: 'text-emerald-400' },
              { label: 'Avg Response Time', value: '4.2m', icon: '⏱️', color: 'text-primary' },
            ].map((stat, idx) => (
              <Card key={idx} className="glass-card border-0 text-center p-6 hover:shadow-lg transition-all">
                <div className="text-4xl mb-3">{stat.icon}</div>
                <div className={`text-3xl font-bold ${stat.color} mb-2`}>{stat.value}</div>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Tech Stack */}
      <section className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Technology Stack</h2>
            <p className="text-lg text-muted-foreground">Built with cutting-edge technologies for performance and reliability</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              'Next.js 16',
              'React 19',
              'TypeScript',
              'Tailwind CSS',
              'ML/AI Models',
              'CCTV Integration',
              'Real-time APIs',
              'Geolocation',
            ].map((tech, idx) => (
              <Card key={idx} className="glass-card border-0 p-4 text-center">
                <p className="font-medium">{tech}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6">Ready to Save Lives?</h2>
          <p className="text-xl text-muted-foreground mb-8">Experience the future of emergency response systems</p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/request">
              <Button size="lg" className="bg-gradient-to-r from-primary to-orange-500 hover:shadow-lg hover:shadow-primary/50">
                Start Emergency Request
              </Button>
            </Link>
            <Link href="/cctv">
              <Button size="lg" variant="outline">
                View CCTV Dashboard
              </Button>
            </Link>
            <Link href="/admin">
              <Button size="lg" variant="outline">
                Admin Control Panel
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/50 py-12 px-4 bg-background/50">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="font-semibold mb-4">SafeRoute</h3>
              <p className="text-sm text-muted-foreground">AI-powered emergency response for modern cities</p>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Features</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/request" className="hover:text-foreground transition-colors">Emergency Request</Link></li>
                <li><Link href="/cctv" className="hover:text-foreground transition-colors">CCTV Monitoring</Link></li>
                <li><Link href="/driver" className="hover:text-foreground transition-colors">Driver Portal</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">System</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li><Link href="/admin" className="hover:text-foreground transition-colors">Admin Dashboard</Link></li>
                <li><a href="#" className="hover:text-foreground transition-colors">Documentation</a></li>
                <li><a href="#" className="hover:text-foreground transition-colors">API Status</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-3">Innovation</h4>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>AI Detection</li>
                <li>Real-time Tracking</li>
                <li>Smart Routing</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-border/50 pt-8 flex justify-between items-center">
            <p className="text-sm text-muted-foreground">© 2025 SafeRoute. All rights reserved.</p>
            <div className="flex items-center gap-2">
              <Badge variant="secondary" className="bg-primary/10 text-primary border-primary/20">Hackathon 2025</Badge>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
