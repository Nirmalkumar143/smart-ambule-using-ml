// In-memory store for demonstration (simulates database)
import type {
  EmergencyRequest,
  Ambulance,
  Hospital,
  TrafficSignal,
  User,
  Location,
  CCTVCamera,
  DetectedAccident,
  SOSAlert,
  RouteObstacle,
} from './types'

// Helper to generate IDs
export const generateId = () => Math.random().toString(36).substring(2, 15)

// Sample hospitals in a major city area
export const hospitals: Hospital[] = [
  {
    id: 'h1',
    name: 'City General Hospital',
    location: { lat: 28.6139, lng: 77.2090 },
    address: '123 Main Street, Central District',
    phone: '+91-11-2345-6789',
    totalBeds: 500,
    availableBeds: 45,
    icuBeds: 50,
    availableIcuBeds: 8,
    emergencyCapacity: 30,
    specialties: ['Trauma', 'Cardiology', 'Neurology', 'Burns'],
    rating: 4.5,
  },
  {
    id: 'h2',
    name: 'Apollo Emergency Care',
    location: { lat: 28.6280, lng: 77.2185 },
    address: '456 Health Avenue, North Zone',
    phone: '+91-11-2345-1234',
    totalBeds: 350,
    availableBeds: 28,
    icuBeds: 40,
    availableIcuBeds: 5,
    emergencyCapacity: 25,
    specialties: ['Cardiology', 'Orthopedics', 'General Surgery'],
    rating: 4.7,
  },
  {
    id: 'h3',
    name: 'Max Super Specialty Hospital',
    location: { lat: 28.5980, lng: 77.2250 },
    address: '789 Medical Park, South District',
    phone: '+91-11-2345-5678',
    totalBeds: 600,
    availableBeds: 52,
    icuBeds: 60,
    availableIcuBeds: 12,
    emergencyCapacity: 40,
    specialties: ['Trauma', 'Neurology', 'Pediatrics', 'Oncology'],
    rating: 4.8,
  },
  {
    id: 'h4',
    name: 'Fortis Heart Institute',
    location: { lat: 28.6350, lng: 77.1980 },
    address: '321 Cardiac Lane, West Zone',
    phone: '+91-11-2345-9012',
    totalBeds: 250,
    availableBeds: 18,
    icuBeds: 35,
    availableIcuBeds: 4,
    emergencyCapacity: 20,
    specialties: ['Cardiology', 'Cardiac Surgery', 'Vascular Surgery'],
    rating: 4.9,
  },
  {
    id: 'h5',
    name: 'AIIMS Trauma Center',
    location: { lat: 28.5670, lng: 77.2100 },
    address: '555 Research Road, Institute Area',
    phone: '+91-11-2345-3456',
    totalBeds: 800,
    availableBeds: 65,
    icuBeds: 80,
    availableIcuBeds: 15,
    emergencyCapacity: 50,
    specialties: ['Trauma', 'Burns', 'Neurology', 'Orthopedics', 'General Medicine'],
    rating: 4.6,
  },
]

// Sample ambulances
export const ambulances: Ambulance[] = [
  {
    id: 'amb1',
    vehicleNumber: 'DL-01-AB-1234',
    driverId: 'd1',
    driverName: 'Rajesh Kumar',
    location: { lat: 28.6200, lng: 77.2150 },
    isAvailable: true,
    equipment: ['Defibrillator', 'Oxygen', 'First Aid', 'Stretcher'],
    lastUpdated: new Date(),
  },
  {
    id: 'amb2',
    vehicleNumber: 'DL-01-CD-5678',
    driverId: 'd2',
    driverName: 'Amit Singh',
    location: { lat: 28.6050, lng: 77.2200 },
    isAvailable: true,
    equipment: ['Defibrillator', 'Oxygen', 'Ventilator', 'First Aid'],
    lastUpdated: new Date(),
  },
  {
    id: 'amb3',
    vehicleNumber: 'DL-01-EF-9012',
    driverId: 'd3',
    driverName: 'Priya Sharma',
    location: { lat: 28.6300, lng: 77.2050 },
    isAvailable: true,
    equipment: ['Oxygen', 'First Aid', 'Stretcher', 'ECG Monitor'],
    lastUpdated: new Date(),
  },
  {
    id: 'amb4',
    vehicleNumber: 'DL-01-GH-3456',
    driverId: 'd4',
    driverName: 'Vikram Patel',
    location: { lat: 28.5900, lng: 77.2300 },
    isAvailable: false,
    currentRequestId: 'demo-active',
    equipment: ['Defibrillator', 'Oxygen', 'First Aid', 'Cardiac Monitor'],
    lastUpdated: new Date(),
  },
]

// Sample traffic signals
export const trafficSignals: TrafficSignal[] = [
  {
    id: 'ts1',
    location: { lat: 28.6150, lng: 77.2120 },
    name: 'Central Junction Signal',
    currentStatus: 'red',
    overrideActive: false,
    lastUpdated: new Date(),
  },
  {
    id: 'ts2',
    location: { lat: 28.6180, lng: 77.2160 },
    name: 'Main Street Crossing',
    currentStatus: 'green',
    overrideActive: false,
    lastUpdated: new Date(),
  },
  {
    id: 'ts3',
    location: { lat: 28.6220, lng: 77.2100 },
    name: 'Hospital Road Signal',
    currentStatus: 'red',
    overrideActive: false,
    lastUpdated: new Date(),
  },
  {
    id: 'ts4',
    location: { lat: 28.6100, lng: 77.2200 },
    name: 'Market Square Junction',
    currentStatus: 'yellow',
    overrideActive: false,
    lastUpdated: new Date(),
  },
  {
    id: 'ts5',
    location: { lat: 28.6250, lng: 77.2180 },
    name: 'North Gate Signal',
    currentStatus: 'red',
    overrideActive: false,
    lastUpdated: new Date(),
  },
]

// Active emergency requests
export const emergencyRequests: EmergencyRequest[] = []

// Users database
export const users: User[] = [
  {
    id: 'd1',
    name: 'Rajesh Kumar',
    email: 'rajesh@ambulance.com',
    role: 'driver',
    phone: '+91-98765-43210',
    createdAt: new Date(),
  },
  {
    id: 'd2',
    name: 'Amit Singh',
    email: 'amit@ambulance.com',
    role: 'driver',
    phone: '+91-98765-43211',
    createdAt: new Date(),
  },
  {
    id: 'd3',
    name: 'Priya Sharma',
    email: 'priya@ambulance.com',
    role: 'driver',
    phone: '+91-98765-43212',
    createdAt: new Date(),
  },
  {
    id: 'd4',
    name: 'Vikram Patel',
    email: 'vikram@ambulance.com',
    role: 'driver',
    phone: '+91-98765-43213',
    createdAt: new Date(),
  },
  {
    id: 'admin1',
    name: 'Admin User',
    email: 'admin@emergency.com',
    role: 'admin',
    phone: '+91-98765-00000',
    createdAt: new Date(),
  },
]

// Utility functions
export function calculateDistance(loc1: Location, loc2: Location): number {
  // Haversine formula for distance calculation
  const R = 6371 // Earth's radius in km
  const dLat = ((loc2.lat - loc1.lat) * Math.PI) / 180
  const dLng = ((loc2.lng - loc1.lng) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((loc1.lat * Math.PI) / 180) *
      Math.cos((loc2.lat * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c // Distance in km
}

export function findNearestAmbulance(location: Location): Ambulance | null {
  const availableAmbulances = ambulances.filter((a) => a.isAvailable)
  if (availableAmbulances.length === 0) return null

  let nearest = availableAmbulances[0]
  let minDistance = calculateDistance(location, nearest.location)

  for (const amb of availableAmbulances) {
    const dist = calculateDistance(location, amb.location)
    if (dist < minDistance) {
      minDistance = dist
      nearest = amb
    }
  }

  return nearest
}

export function findNearbyTrafficSignals(location: Location, radiusKm: number = 0.1): TrafficSignal[] {
  return trafficSignals.filter((signal) => {
    const dist = calculateDistance(location, signal.location)
    return dist <= radiusKm
  })
}

export function getEmergencySeverity(type: string): number {
  const severityMap: Record<string, number> = {
    heart_attack: 10,
    stroke: 9,
    accident: 8,
    breathing: 8,
    fire: 7,
    other: 5,
  }
  return severityMap[type] || 5
}

// CCTV Cameras across the city
export const cctvCameras: CCTVCamera[] = [
  {
    id: 'cam1',
    name: 'Central Highway Junction',
    location: { lat: 28.6145, lng: 77.2095 },
    address: 'NH-44 Central Junction',
    status: 'online',
    roadCondition: 'clear',
    lastUpdated: new Date(),
    coverageRadius: 200,
    detectionEnabled: true,
  },
  {
    id: 'cam2',
    name: 'Main Street Crossing',
    location: { lat: 28.6185, lng: 77.2165 },
    address: 'Main Street & Park Road',
    status: 'online',
    roadCondition: 'moderate',
    lastUpdated: new Date(),
    coverageRadius: 150,
    detectionEnabled: true,
  },
  {
    id: 'cam3',
    name: 'Hospital Road Camera',
    location: { lat: 28.6225, lng: 77.2105 },
    address: 'Near City General Hospital',
    status: 'online',
    roadCondition: 'clear',
    lastUpdated: new Date(),
    coverageRadius: 180,
    detectionEnabled: true,
  },
  {
    id: 'cam4',
    name: 'Market Square',
    location: { lat: 28.6105, lng: 77.2205 },
    address: 'Market Square Junction',
    status: 'online',
    roadCondition: 'congested',
    lastUpdated: new Date(),
    coverageRadius: 120,
    detectionEnabled: true,
  },
  {
    id: 'cam5',
    name: 'North Gate Flyover',
    location: { lat: 28.6255, lng: 77.2185 },
    address: 'North Gate Flyover Entry',
    status: 'online',
    roadCondition: 'clear',
    lastUpdated: new Date(),
    coverageRadius: 250,
    detectionEnabled: true,
  },
  {
    id: 'cam6',
    name: 'Industrial Area',
    location: { lat: 28.6020, lng: 77.2280 },
    address: 'Industrial Zone Gate 3',
    status: 'online',
    roadCondition: 'moderate',
    lastUpdated: new Date(),
    coverageRadius: 200,
    detectionEnabled: true,
  },
  {
    id: 'cam7',
    name: 'Ring Road West',
    location: { lat: 28.6320, lng: 77.1950 },
    address: 'Ring Road West Entry',
    status: 'online',
    roadCondition: 'clear',
    lastUpdated: new Date(),
    coverageRadius: 300,
    detectionEnabled: true,
  },
  {
    id: 'cam8',
    name: 'Railway Station',
    location: { lat: 28.5950, lng: 77.2150 },
    address: 'Central Railway Station',
    status: 'online',
    roadCondition: 'congested',
    lastUpdated: new Date(),
    coverageRadius: 150,
    detectionEnabled: true,
  },
  {
    id: 'cam9',
    name: 'South Bridge',
    location: { lat: 28.5700, lng: 77.2080 },
    address: 'South Bridge Underpass',
    status: 'maintenance',
    roadCondition: 'moderate',
    lastUpdated: new Date(),
    coverageRadius: 180,
    detectionEnabled: false,
  },
  {
    id: 'cam10',
    name: 'Tech Park Gate',
    location: { lat: 28.6380, lng: 77.2020 },
    address: 'Tech Park Main Gate',
    status: 'online',
    roadCondition: 'clear',
    lastUpdated: new Date(),
    coverageRadius: 200,
    detectionEnabled: true,
  },
]

// Detected accidents (initially empty, populated by AI detection)
export const detectedAccidents: DetectedAccident[] = []

// SOS alerts sent
export const sosAlerts: SOSAlert[] = []

// Route obstacles detected by cameras
export const routeObstacles: RouteObstacle[] = [
  {
    id: 'obs1',
    cameraId: 'cam4',
    location: { lat: 28.6105, lng: 77.2205 },
    type: 'traffic',
    severity: 'medium',
    description: 'Heavy traffic congestion at Market Square',
    detectedAt: new Date(),
    estimatedClearTime: 15,
  },
  {
    id: 'obs2',
    cameraId: 'cam8',
    location: { lat: 28.5950, lng: 77.2150 },
    type: 'traffic',
    severity: 'high',
    description: 'Rush hour traffic near Railway Station',
    detectedAt: new Date(),
    estimatedClearTime: 30,
  },
]

// Nearby people database for SOS (simulated)
export const nearbyPeople = [
  { id: 'p1', name: 'Suresh Verma', phone: '+91-98765-11111', location: { lat: 28.6150, lng: 77.2100 } },
  { id: 'p2', name: 'Meera Kapoor', phone: '+91-98765-22222', location: { lat: 28.6160, lng: 77.2110 } },
  { id: 'p3', name: 'Arun Nair', phone: '+91-98765-33333', location: { lat: 28.6170, lng: 77.2090 } },
  { id: 'p4', name: 'Sunita Devi', phone: '+91-98765-44444', location: { lat: 28.6140, lng: 77.2080 } },
  { id: 'p5', name: 'Rahul Sharma', phone: '+91-98765-55555', location: { lat: 28.6180, lng: 77.2120 } },
  { id: 'p6', name: 'Kavita Singh', phone: '+91-98765-66666', location: { lat: 28.6130, lng: 77.2130 } },
  { id: 'p7', name: 'Deepak Kumar', phone: '+91-98765-77777', location: { lat: 28.6200, lng: 77.2140 } },
  { id: 'p8', name: 'Anita Gupta', phone: '+91-98765-88888', location: { lat: 28.6120, lng: 77.2160 } },
]

// Find nearby people within radius
export function findNearbyPeople(location: Location, radiusKm: number = 0.5) {
  return nearbyPeople.filter((person) => {
    const dist = calculateDistance(location, person.location)
    return dist <= radiusKm
  }).map((person) => ({
    ...person,
    distance: calculateDistance(location, person.location)
  })).sort((a, b) => a.distance - b.distance)
}

// Find cameras along a route
export function findCamerasOnRoute(origin: Location, destination: Location): CCTVCamera[] {
  const routeBuffer = 0.3 // km buffer around route
  return cctvCameras.filter((camera) => {
    const distToOrigin = calculateDistance(origin, camera.location)
    const distToDest = calculateDistance(destination, camera.location)
    const routeLength = calculateDistance(origin, destination)
    return (distToOrigin + distToDest) <= (routeLength + routeBuffer * 2)
  })
}

// Get route obstacles
export function getRouteObstacles(cameras: CCTVCamera[]): RouteObstacle[] {
  const cameraIds = cameras.map(c => c.id)
  return routeObstacles.filter(obs => cameraIds.includes(obs.cameraId))
}

// Calculate optimal route based on camera data
export function calculateOptimalRoute(origin: Location, destination: Location, emergencyType: string) {
  const camerasOnRoute = findCamerasOnRoute(origin, destination)
  const obstacles = getRouteObstacles(camerasOnRoute)
  
  const baseDistance = calculateDistance(origin, destination)
  const baseTime = (baseDistance / 40) * 60 // 40 km/h average, in minutes
  
  // Calculate delay from obstacles
  let totalDelay = 0
  obstacles.forEach(obs => {
    if (obs.severity === 'high') totalDelay += 10
    else if (obs.severity === 'medium') totalDelay += 5
    else totalDelay += 2
  })
  
  // Check for blocked routes
  const blockedCameras = camerasOnRoute.filter(c => c.roadCondition === 'blocked' || c.roadCondition === 'accident')
  
  return {
    routeId: generateId(),
    origin,
    destination,
    waypoints: camerasOnRoute.map(c => c.location),
    totalDistance: baseDistance,
    estimatedTime: Math.round(baseTime + totalDelay),
    obstacles,
    alternativeRoutes: [
      { distance: baseDistance * 1.2, time: Math.round(baseTime * 1.1), obstacleCount: Math.max(0, obstacles.length - 1) },
      { distance: baseDistance * 1.4, time: Math.round(baseTime * 1.3), obstacleCount: 0 },
    ],
    camerasOnRoute: camerasOnRoute.map(c => c.id),
    isOptimal: blockedCameras.length === 0,
    reason: blockedCameras.length > 0 
      ? `Route blocked at ${blockedCameras[0].name}. Alternative suggested.`
      : obstacles.length > 0 
        ? `${obstacles.length} obstacle(s) detected. Estimated delay: ${totalDelay} min`
        : 'Route is clear for emergency vehicle'
  }
}
