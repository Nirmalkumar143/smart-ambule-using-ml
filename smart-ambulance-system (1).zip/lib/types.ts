// Types for Smart Ambulance System

export type EmergencyType = 'accident' | 'heart_attack' | 'fire' | 'stroke' | 'breathing' | 'other'

export type RequestStatus = 'pending' | 'assigned' | 'en_route_to_victim' | 'picked_up' | 'en_route_to_hospital' | 'completed' | 'cancelled'

export type UserRole = 'victim' | 'driver' | 'admin'

export type TrafficLightStatus = 'red' | 'yellow' | 'green'

export interface Location {
  lat: number
  lng: number
}

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  phone?: string
  createdAt: Date
}

export interface EmergencyRequest {
  id: string
  victimId: string
  victimName: string
  victimPhone: string
  location: Location
  address?: string
  emergencyType: EmergencyType
  description?: string
  status: RequestStatus
  assignedAmbulanceId?: string
  assignedDriverId?: string
  recommendedHospitalId?: string
  createdAt: Date
  updatedAt: Date
  completedAt?: Date
  eta?: number // minutes
}

export interface Ambulance {
  id: string
  vehicleNumber: string
  driverId: string
  driverName: string
  location: Location
  isAvailable: boolean
  currentRequestId?: string
  equipment: string[]
  lastUpdated: Date
}

export interface Hospital {
  id: string
  name: string
  location: Location
  address: string
  phone: string
  totalBeds: number
  availableBeds: number
  icuBeds: number
  availableIcuBeds: number
  emergencyCapacity: number
  specialties: string[]
  rating: number
  distance?: number
  estimatedTime?: number
}

export interface TrafficSignal {
  id: string
  location: Location
  name: string
  currentStatus: TrafficLightStatus
  overrideActive: boolean
  overrideUntil?: Date
  lastUpdated: Date
}

export interface HospitalRecommendation {
  hospitalId: string
  hospital: Hospital
  score: number
  reasons: string[]
  estimatedArrival: number
}

export interface RouteInfo {
  origin: Location
  destination: Location
  distance: number // meters
  duration: number // seconds
  polyline: string
  trafficSignals: TrafficSignal[]
}

export interface DriverStats {
  totalTrips: number
  completedToday: number
  averageResponseTime: number
  rating: number
}

export interface SystemStats {
  activeEmergencies: number
  availableAmbulances: number
  totalAmbulances: number
  averageResponseTime: number
  completedToday: number
  greenCorridorsActive: number
}

// CCTV and Accident Detection Types
export type CCTVStatus = 'online' | 'offline' | 'maintenance'
export type RoadCondition = 'clear' | 'moderate' | 'congested' | 'blocked' | 'accident'
export type SOSStatus = 'pending' | 'sent' | 'acknowledged' | 'responded'

export interface CCTVCamera {
  id: string
  name: string
  location: Location
  address: string
  status: CCTVStatus
  roadCondition: RoadCondition
  lastUpdated: Date
  coverageRadius: number // meters
  feedUrl?: string
  detectionEnabled: boolean
}

export interface DetectedAccident {
  id: string
  cameraId: string
  location: Location
  address: string
  timestamp: Date
  severity: 'minor' | 'moderate' | 'severe' | 'critical'
  vehiclesInvolved: number
  casualties: number
  description: string
  imageSnapshot?: string
  autoRequestSent: boolean
  emergencyRequestId?: string
  sosAlertsSent: number
  status: 'detected' | 'verified' | 'responding' | 'resolved'
}

export interface SOSAlert {
  id: string
  accidentId: string
  recipientPhone: string
  recipientName?: string
  location: Location
  address: string
  message: string
  sentAt: Date
  status: SOSStatus
  distance: number // km from accident
}

export interface RouteObstacle {
  id: string
  cameraId: string
  location: Location
  type: 'traffic' | 'construction' | 'accident' | 'roadblock' | 'flooding'
  severity: 'low' | 'medium' | 'high'
  description: string
  detectedAt: Date
  estimatedClearTime?: number // minutes
}

export interface OptimizedRoute {
  routeId: string
  origin: Location
  destination: Location
  waypoints: Location[]
  totalDistance: number
  estimatedTime: number
  obstacles: RouteObstacle[]
  alternativeRoutes: {
    distance: number
    time: number
    obstacleCount: number
  }[]
  camerasOnRoute: string[]
  isOptimal: boolean
  reason: string
}
