// ML Hospital Recommendation Service
// Simulates a RandomForest-like scoring algorithm

import type { Hospital, Location, EmergencyType, HospitalRecommendation } from './types'
import { hospitals, calculateDistance, getEmergencySeverity } from './store'

interface MLFeatures {
  distance: number
  availableBeds: number
  icuAvailability: number
  emergencyCapacity: number
  specialtyMatch: number
  hospitalRating: number
  severity: number
  trafficDelay: number
}

// Specialty requirements for each emergency type
const emergencySpecialtyMap: Record<EmergencyType, string[]> = {
  accident: ['Trauma', 'Orthopedics', 'General Surgery'],
  heart_attack: ['Cardiology', 'Cardiac Surgery', 'ICU'],
  stroke: ['Neurology', 'ICU', 'Trauma'],
  fire: ['Burns', 'Trauma', 'Plastic Surgery'],
  breathing: ['Pulmonology', 'ICU', 'General Medicine'],
  other: ['General Medicine', 'Emergency'],
}

// Feature weights (simulating learned weights from RandomForest)
const featureWeights = {
  distance: -0.25, // Negative because closer is better
  availableBeds: 0.15,
  icuAvailability: 0.20,
  emergencyCapacity: 0.15,
  specialtyMatch: 0.25,
  hospitalRating: 0.10,
  severity: 0.05,
  trafficDelay: -0.15, // Negative because less delay is better
}

// Normalize value to 0-1 range
function normalize(value: number, min: number, max: number): number {
  if (max === min) return 0.5
  return Math.max(0, Math.min(1, (value - min) / (max - min)))
}

// Calculate specialty match score
function calculateSpecialtyMatch(hospital: Hospital, emergencyType: EmergencyType): number {
  const requiredSpecialties = emergencySpecialtyMap[emergencyType] || []
  if (requiredSpecialties.length === 0) return 0.5

  const matches = requiredSpecialties.filter((spec) =>
    hospital.specialties.some((hs) => hs.toLowerCase().includes(spec.toLowerCase()))
  ).length

  return matches / requiredSpecialties.length
}

// Simulate traffic delay based on time of day and distance
function estimateTrafficDelay(distance: number): number {
  const hour = new Date().getHours()
  let trafficMultiplier = 1

  // Peak hours
  if ((hour >= 8 && hour <= 10) || (hour >= 17 && hour <= 20)) {
    trafficMultiplier = 1.8
  } else if (hour >= 11 && hour <= 16) {
    trafficMultiplier = 1.3
  } else {
    trafficMultiplier = 1.0
  }

  // Base time: 2 min per km, adjusted for traffic
  return distance * 2 * trafficMultiplier
}

// Extract features for ML model
function extractFeatures(
  hospital: Hospital,
  victimLocation: Location,
  emergencyType: EmergencyType
): MLFeatures {
  const distance = calculateDistance(victimLocation, hospital.location)
  const trafficDelay = estimateTrafficDelay(distance)

  return {
    distance,
    availableBeds: hospital.availableBeds,
    icuAvailability: hospital.availableIcuBeds / Math.max(hospital.icuBeds, 1),
    emergencyCapacity: hospital.emergencyCapacity,
    specialtyMatch: calculateSpecialtyMatch(hospital, emergencyType),
    hospitalRating: hospital.rating,
    severity: getEmergencySeverity(emergencyType),
    trafficDelay,
  }
}

// Calculate ML score (simulating RandomForest prediction)
function calculateMLScore(features: MLFeatures, allFeatures: MLFeatures[]): number {
  // Get min/max for normalization
  const distances = allFeatures.map((f) => f.distance)
  const beds = allFeatures.map((f) => f.availableBeds)
  const capacities = allFeatures.map((f) => f.emergencyCapacity)
  const delays = allFeatures.map((f) => f.trafficDelay)

  // Normalize features
  const normalizedFeatures = {
    distance: normalize(features.distance, Math.min(...distances), Math.max(...distances)),
    availableBeds: normalize(features.availableBeds, Math.min(...beds), Math.max(...beds)),
    icuAvailability: features.icuAvailability,
    emergencyCapacity: normalize(features.emergencyCapacity, Math.min(...capacities), Math.max(...capacities)),
    specialtyMatch: features.specialtyMatch,
    hospitalRating: normalize(features.hospitalRating, 3, 5),
    severity: normalize(features.severity, 1, 10),
    trafficDelay: normalize(features.trafficDelay, Math.min(...delays), Math.max(...delays)),
  }

  // Calculate weighted score
  let score = 0
  score += normalizedFeatures.distance * featureWeights.distance
  score += normalizedFeatures.availableBeds * featureWeights.availableBeds
  score += normalizedFeatures.icuAvailability * featureWeights.icuAvailability
  score += normalizedFeatures.emergencyCapacity * featureWeights.emergencyCapacity
  score += normalizedFeatures.specialtyMatch * featureWeights.specialtyMatch
  score += normalizedFeatures.hospitalRating * featureWeights.hospitalRating
  score += normalizedFeatures.severity * featureWeights.severity
  score += normalizedFeatures.trafficDelay * featureWeights.trafficDelay

  // Convert to 0-100 scale
  return Math.round((score + 1) * 50)
}

// Generate recommendation reasons
function generateReasons(features: MLFeatures, hospital: Hospital, emergencyType: EmergencyType): string[] {
  const reasons: string[] = []

  if (features.distance < 3) {
    reasons.push(`Only ${features.distance.toFixed(1)} km away`)
  }

  if (features.specialtyMatch >= 0.7) {
    reasons.push(`Excellent specialty match for ${emergencyType.replace('_', ' ')}`)
  } else if (features.specialtyMatch >= 0.4) {
    reasons.push('Good specialty coverage')
  }

  if (hospital.availableIcuBeds >= 5) {
    reasons.push(`${hospital.availableIcuBeds} ICU beds available`)
  }

  if (hospital.rating >= 4.5) {
    reasons.push(`High rating: ${hospital.rating}/5`)
  }

  if (features.trafficDelay < 10) {
    reasons.push('Low traffic expected')
  }

  if (hospital.emergencyCapacity >= 30) {
    reasons.push('High emergency capacity')
  }

  return reasons.slice(0, 3)
}

// Main recommendation function
export function recommendHospital(
  victimLocation: Location,
  emergencyType: EmergencyType
): HospitalRecommendation[] {
  // Extract features for all hospitals
  const hospitalFeatures = hospitals.map((hospital) => ({
    hospital,
    features: extractFeatures(hospital, victimLocation, emergencyType),
  }))

  const allFeatures = hospitalFeatures.map((hf) => hf.features)

  // Calculate scores and create recommendations
  const recommendations: HospitalRecommendation[] = hospitalFeatures
    .map(({ hospital, features }) => {
      const score = calculateMLScore(features, allFeatures)
      const estimatedArrival = Math.round(features.distance * 2 + features.trafficDelay)

      return {
        hospitalId: hospital.id,
        hospital: {
          ...hospital,
          distance: Math.round(features.distance * 10) / 10,
          estimatedTime: estimatedArrival,
        },
        score,
        reasons: generateReasons(features, hospital, emergencyType),
        estimatedArrival,
      }
    })
    .sort((a, b) => b.score - a.score)

  return recommendations
}

// Get single best hospital
export function getBestHospital(
  victimLocation: Location,
  emergencyType: EmergencyType
): HospitalRecommendation | null {
  const recommendations = recommendHospital(victimLocation, emergencyType)
  return recommendations.length > 0 ? recommendations[0] : null
}
