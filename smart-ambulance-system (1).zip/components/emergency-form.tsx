'use client'

import React from "react"

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import type { Location, EmergencyType } from '@/lib/types'

interface EmergencyFormProps {
  onSubmit: (data: {
    victimName: string
    victimPhone: string
    location: Location
    emergencyType: EmergencyType
    description: string
  }) => Promise<void>
  isLoading?: boolean
}

const emergencyTypes: { value: EmergencyType; label: string }[] = [
  { value: 'accident', label: 'Road Accident' },
  { value: 'heart_attack', label: 'Heart Attack / Chest Pain' },
  { value: 'stroke', label: 'Stroke / Paralysis' },
  { value: 'breathing', label: 'Breathing Difficulty' },
  { value: 'fire', label: 'Fire / Burns' },
  { value: 'other', label: 'Other Medical Emergency' },
]

export function EmergencyForm({ onSubmit, isLoading }: EmergencyFormProps) {
  const [victimName, setVictimName] = useState('')
  const [victimPhone, setVictimPhone] = useState('')
  const [emergencyType, setEmergencyType] = useState<EmergencyType>('accident')
  const [description, setDescription] = useState('')
  const [location, setLocation] = useState<Location | null>(null)
  const [locationStatus, setLocationStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle')
  const [locationAddress, setLocationAddress] = useState('')

  // Auto-detect GPS location
  useEffect(() => {
    detectLocation()
  }, [])

  const detectLocation = () => {
    setLocationStatus('loading')
    
    if (!navigator.geolocation) {
      setLocationStatus('error')
      // Use default location (Delhi)
      setLocation({ lat: 28.6139, lng: 77.2090 })
      setLocationAddress('Default Location (GPS not available)')
      return
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const loc = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        }
        setLocation(loc)
        setLocationAddress(`${loc.lat.toFixed(6)}, ${loc.lng.toFixed(6)}`)
        setLocationStatus('success')
      },
      (error) => {
        console.error('Geolocation error:', error)
        setLocationStatus('error')
        // Use simulated location
        const simulatedLoc = { 
          lat: 28.6139 + (Math.random() - 0.5) * 0.05, 
          lng: 77.2090 + (Math.random() - 0.5) * 0.05 
        }
        setLocation(simulatedLoc)
        setLocationAddress(`Simulated: ${simulatedLoc.lat.toFixed(6)}, ${simulatedLoc.lng.toFixed(6)}`)
      }
    )
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!location) {
      alert('Location is required. Please enable GPS or wait for location detection.')
      return
    }

    await onSubmit({
      victimName,
      victimPhone,
      location,
      emergencyType,
      description,
    })
  }

  return (
    <Card className="w-full max-w-lg mx-auto border-destructive/20">
      <CardHeader className="text-center pb-4">
        <CardTitle className="text-2xl text-destructive">Emergency Request</CardTitle>
        <CardDescription>
          Fill in details below. Help is on the way!
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Location Status */}
          <div className="p-3 rounded-lg bg-secondary/50 border border-border">
            <div className="flex items-center justify-between mb-2">
              <Label className="text-sm font-medium">Your Location</Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={detectLocation}
                disabled={locationStatus === 'loading'}
              >
                {locationStatus === 'loading' ? 'Detecting...' : 'Refresh'}
              </Button>
            </div>
            <div className="flex items-center gap-2">
              <div
                className={`w-3 h-3 rounded-full ${
                  locationStatus === 'success'
                    ? 'bg-green-500'
                    : locationStatus === 'loading'
                    ? 'bg-yellow-500 animate-pulse'
                    : locationStatus === 'error'
                    ? 'bg-orange-500'
                    : 'bg-muted'
                }`}
              />
              <span className="text-sm text-muted-foreground">
                {locationStatus === 'loading' && 'Detecting your location...'}
                {locationStatus === 'success' && locationAddress}
                {locationStatus === 'error' && locationAddress}
                {locationStatus === 'idle' && 'Click to detect location'}
              </span>
            </div>
          </div>

          {/* Name */}
          <div className="space-y-2">
            <Label htmlFor="name">Your Name</Label>
            <Input
              id="name"
              value={victimName}
              onChange={(e) => setVictimName(e.target.value)}
              placeholder="Enter your name"
              required
            />
          </div>

          {/* Phone */}
          <div className="space-y-2">
            <Label htmlFor="phone">Phone Number</Label>
            <Input
              id="phone"
              type="tel"
              value={victimPhone}
              onChange={(e) => setVictimPhone(e.target.value)}
              placeholder="+91 XXXXX XXXXX"
              required
            />
          </div>

          {/* Emergency Type */}
          <div className="space-y-2">
            <Label htmlFor="type">Type of Emergency</Label>
            <Select
              value={emergencyType}
              onValueChange={(value) => setEmergencyType(value as EmergencyType)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Select emergency type" />
              </SelectTrigger>
              <SelectContent>
                {emergencyTypes.map((type) => (
                  <SelectItem key={type.value} value={type.value}>
                    {type.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label htmlFor="description">Additional Details (Optional)</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe the situation, number of victims, visible injuries..."
              rows={3}
            />
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            className="w-full h-14 text-lg font-semibold bg-destructive text-destructive-foreground hover:bg-destructive/90"
            disabled={isLoading || !location}
          >
            {isLoading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-5 w-5" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                Requesting Ambulance...
              </span>
            ) : (
              'REQUEST AMBULANCE'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
