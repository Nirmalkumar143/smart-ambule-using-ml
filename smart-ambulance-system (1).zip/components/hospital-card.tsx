'use client'

import type { Hospital, HospitalRecommendation } from '@/lib/types'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

interface HospitalCardProps {
  hospital: Hospital
  recommendation?: HospitalRecommendation
  isSelected?: boolean
  onSelect?: () => void
  showRoute?: () => void
  distance?: number
  estimatedTime?: number
}

export function HospitalCard({
  hospital,
  recommendation,
  isSelected,
  onSelect,
  showRoute,
  distance,
  estimatedTime,
}: HospitalCardProps) {
  const score = recommendation?.score || 0
  const reasons = recommendation?.reasons || []

  return (
    <div
      className={`glass-card rounded-xl p-4 transition-all duration-300 cursor-pointer ${
        isSelected
          ? 'ring-2 ring-primary bg-primary/5'
          : 'hover:bg-white/5'
      }`}
      onClick={onSelect}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shrink-0">
              <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-1 11h-4v4h-4v-4H6v-4h4V6h4v4h4v4z" />
              </svg>
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-foreground truncate">{hospital.name}</h3>
              <p className="text-xs text-muted-foreground truncate">{hospital.address}</p>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-4 gap-2 mt-3">
            <div className="text-center">
              <div className="text-lg font-bold text-emerald-400">{hospital.availableBeds}</div>
              <div className="text-[10px] text-muted-foreground">Beds</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-blue-400">{hospital.availableIcuBeds}</div>
              <div className="text-[10px] text-muted-foreground">ICU</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-yellow-400">{hospital.rating}</div>
              <div className="text-[10px] text-muted-foreground">Rating</div>
            </div>
            <div className="text-center">
              <div className="text-lg font-bold text-primary">{distance?.toFixed(1) || '?'}</div>
              <div className="text-[10px] text-muted-foreground">km</div>
            </div>
          </div>

          {/* Specialties */}
          <div className="flex flex-wrap gap-1 mt-3">
            {hospital.specialties.slice(0, 4).map((spec) => (
              <Badge key={spec} variant="secondary" className="text-[10px] px-1.5 py-0">
                {spec}
              </Badge>
            ))}
            {hospital.specialties.length > 4 && (
              <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                +{hospital.specialties.length - 4}
              </Badge>
            )}
          </div>

          {/* ML Recommendation reasons */}
          {reasons.length > 0 && (
            <div className="mt-3 pt-3 border-t border-border/50">
              <div className="text-[10px] text-muted-foreground mb-1">AI Recommendation:</div>
              <div className="flex flex-col gap-1">
                {reasons.map((reason, idx) => (
                  <div key={idx} className="flex items-center gap-1 text-xs text-foreground/80">
                    <svg className="w-3 h-3 text-emerald-400 shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                    {reason}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Score and actions */}
        <div className="flex flex-col items-end gap-2">
          {score > 0 && (
            <div className={`text-2xl font-bold ${
              score >= 70 ? 'text-emerald-400' : score >= 50 ? 'text-yellow-400' : 'text-muted-foreground'
            }`}>
              {score}
              <span className="text-xs text-muted-foreground font-normal">/100</span>
            </div>
          )}
          
          {estimatedTime && (
            <div className="text-center">
              <div className="text-sm font-semibold text-primary">{estimatedTime} min</div>
              <div className="text-[10px] text-muted-foreground">ETA</div>
            </div>
          )}

          {showRoute && (
            <Button
              size="sm"
              variant={isSelected ? "default" : "outline"}
              onClick={(e) => {
                e.stopPropagation()
                showRoute()
              }}
              className="text-xs"
            >
              {isSelected ? 'Selected' : 'View Route'}
            </Button>
          )}
        </div>
      </div>
    </div>
  )
}
