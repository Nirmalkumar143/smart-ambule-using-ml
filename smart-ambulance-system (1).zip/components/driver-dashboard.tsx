'use client'

import { useState, useEffect, useCallback } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { LiveMap } from './live-map'
import type { EmergencyRequest, Ambulance, TrafficSignal, Location, HospitalRecommendation, Hospital } from '@/lib/types'

interface DriverDashboardProps {
  driverId: string
  ambulance: Ambulance
}

export function DriverDashboard({ driverId, ambulance }: DriverDashboardProps) {
  const [currentRequest, setCurrentRequest] = useState<EmergencyRequest | null>(null)
  const [pendingRequests, setPendingRequests] = useState<EmergencyRequest[]>([])
  const [trafficSignals, setTrafficSignals] = useState<TrafficSignal[]>([])
  const [hospitals, setHospitals] = useState<Hospital[]>([])
  const [recommendedHospital, setRecommendedHospital] = useState<HospitalRecommendation | null>(null)
  const [currentLocation, setCurrentLocation] = useState<Location>(ambulance.location)
  const [isOnline, setIsOnline] = useState(ambulance.isAvailable)
  const [greenCorridorActive, setGreenCorridorActive] = useState(false)

  const fetchPendingRequests = useCallback(async () => {
    try {
      const response = await fetch('/api/emergency')
      const data = await response.json()
      if (data.success) {
        const pending = data.requests.filter(
          (r: EmergencyRequest) => r.status === 'pending' && !r.assignedAmbulanceId
        )
        setPendingRequests(pending)
      }
    } catch (error) {
      console.error('Failed to fetch requests:', error)
    }
  }, [])

  const fetchTrafficSignals = useCallback(async () => {
    try {
      const [trafficRes, hospitalRes] = await Promise.all([
        fetch(`/api/traffic?lat=${currentLocation.lat}&lng=${currentLocation.lng}&radius=0.5`),
        fetch('/api/hospital'),
      ])
      const [trafficData, hospitalData] = await Promise.all([trafficRes.json(), hospitalRes.json()])
      if (trafficData.success) setTrafficSignals(trafficData.signals)
      if (hospitalData.success) setHospitals(hospitalData.hospitals)
    } catch (error) {
      console.error('Failed to fetch data:', error)
    }
  }, [currentLocation])

  useEffect(() => {
    fetchPendingRequests()
    fetchTrafficSignals()
    const interval = setInterval(() => {
      fetchPendingRequests()
      fetchTrafficSignals()
    }, 5000)
    return () => clearInterval(interval)
  }, [fetchPendingRequests, fetchTrafficSignals])

  useEffect(() => {
    const locationInterval = setInterval(() => {
      setCurrentLocation((prev) => ({
        lat: prev.lat + (Math.random() - 0.5) * 0.001,
        lng: prev.lng + (Math.random() - 0.5) * 0.001,
      }))
    }, 3000)
    return () => clearInterval(locationInterval)
  }, [])

  useEffect(() => {
    const updateLocation = async () => {
      await fetch(`/api/ambulance/${ambulance.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ location: currentLocation }),
      })
      if (currentRequest && ['en_route_to_victim', 'en_route_to_hospital'].includes(currentRequest.status)) {
        await fetch('/api/traffic', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ambulanceLocation: currentLocation, duration: 60 }),
        })
        setGreenCorridorActive(true)
      }
    }
    updateLocation()
  }, [currentLocation, ambulance.id, currentRequest])

  const handleAcceptRequest = async (request: EmergencyRequest) => {
    try {
      const response = await fetch(`/api/emergency/${request.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'assigned', ambulanceId: ambulance.id, driverId }),
      })
      const data = await response.json()
      if (data.success) {
        setCurrentRequest(data.request)
        setPendingRequests((prev) => prev.filter((r) => r.id !== request.id))
        setIsOnline(false)
        const hospitalResponse = await fetch('/api/hospital', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ location: request.location, emergencyType: request.emergencyType }),
        })
        const hospitalData = await hospitalResponse.json()
        if (hospitalData.success && hospitalData.bestHospital) {
          setRecommendedHospital(hospitalData.bestHospital)
        }
      }
    } catch (error) {
      console.error('Failed to accept request:', error)
    }
  }

  const handleStatusUpdate = async (newStatus: string) => {
    if (!currentRequest) return
    try {
      const response = await fetch(`/api/emergency/${currentRequest.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      })
      const data = await response.json()
      if (data.success) {
        setCurrentRequest(data.request)
        if (newStatus === 'completed') {
          setCurrentRequest(null)
          setRecommendedHospital(null)
          setIsOnline(true)
          setGreenCorridorActive(false)
        }
      }
    } catch (error) {
      console.error('Failed to update status:', error)
    }
  }

  const toggleOnlineStatus = async () => {
    if (currentRequest) return
    try {
      await fetch(`/api/ambulance/${ambulance.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isAvailable: !isOnline }),
      })
      setIsOnline(!isOnline)
    } catch (error) {
      console.error('Failed to toggle status:', error)
    }
  }

  return (
    <div className="max-w-7xl mx-auto space-y-6">
      {/* Driver Status Card */}
      <Card className="glass-card border-0 border-l-4 border-l-blue-500">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-xl bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center">
                <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
              <div>
                <CardTitle className="text-xl text-foreground">{ambulance.driverName}</CardTitle>
                <CardDescription className="flex items-center gap-2">
                  {ambulance.vehicleNumber}
                  <Badge className={isOnline ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-500/20 text-gray-400'}>
                    {isOnline ? 'Online' : 'Offline'}
                  </Badge>
                </CardDescription>
              </div>
            </div>
            <Button
              onClick={toggleOnlineStatus}
              disabled={!!currentRequest}
              className={isOnline ? 'bg-emerald-500 hover:bg-emerald-600' : 'bg-gray-500 hover:bg-gray-600'}
            >
              {isOnline ? 'Go Offline' : 'Go Online'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 mt-4">
            <div className="text-center p-3 rounded-lg bg-secondary/50">
              <div className="text-2xl font-bold text-foreground">{currentLocation.lat.toFixed(4)}</div>
              <div className="text-xs text-muted-foreground">Latitude</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-secondary/50">
              <div className="text-2xl font-bold text-foreground">{currentLocation.lng.toFixed(4)}</div>
              <div className="text-xs text-muted-foreground">Longitude</div>
            </div>
            <div className="text-center p-3 rounded-lg bg-secondary/50">
              <div className="flex items-center justify-center gap-2">
                <span className={`w-3 h-3 rounded-full ${greenCorridorActive ? 'bg-green-500 animate-pulse' : 'bg-gray-500'}`} />
                <span className={`text-lg font-semibold ${greenCorridorActive ? 'text-green-400' : 'text-muted-foreground'}`}>
                  {greenCorridorActive ? 'Active' : 'Inactive'}
                </span>
              </div>
              <div className="text-xs text-muted-foreground">Green Corridor</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Request */}
      {currentRequest && (
        <Card className="glass-card border-0 ring-2 ring-primary/50 animate-pulse-glow">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-red-600 flex items-center justify-center animate-pulse">
                  <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                </div>
                <div>
                  <CardTitle className="text-lg text-foreground">Active Emergency</CardTitle>
                  <CardDescription className="capitalize">{currentRequest.emergencyType.replace('_', ' ')}</CardDescription>
                </div>
              </div>
              <Badge className="bg-primary/20 text-primary border-primary/30 text-sm px-3 py-1">
                {currentRequest.status.replace(/_/g, ' ').toUpperCase()}
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 rounded-lg bg-secondary/50">
                <div className="text-sm text-muted-foreground mb-1">Victim</div>
                <div className="font-semibold text-foreground">{currentRequest.victimName}</div>
                <div className="text-sm text-muted-foreground">{currentRequest.victimPhone}</div>
              </div>
              <div className="p-4 rounded-lg bg-secondary/50">
                <div className="text-sm text-muted-foreground mb-1">Location</div>
                <div className="font-semibold text-foreground">
                  {currentRequest.location.lat.toFixed(5)}, {currentRequest.location.lng.toFixed(5)}
                </div>
              </div>
            </div>

            {currentRequest.description && (
              <div className="p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20">
                <div className="text-sm text-yellow-400 mb-1">Additional Details</div>
                <div className="text-foreground">{currentRequest.description}</div>
              </div>
            )}

            {/* Recommended Hospital */}
            {recommendedHospital && (
              <div className="p-4 rounded-lg bg-emerald-500/10 border border-emerald-500/20">
                <div className="flex items-center gap-2 mb-2">
                  <svg className="w-5 h-5 text-emerald-400" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-1 11h-4v4h-4v-4H6v-4h4V6h4v4h4v4z" />
                  </svg>
                  <span className="text-emerald-400 font-medium">AI Recommended Hospital</span>
                  <Badge className="bg-emerald-500/20 text-emerald-400 ml-auto">Score: {recommendedHospital.score}/100</Badge>
                </div>
                <div className="font-semibold text-foreground">{recommendedHospital.hospital.name}</div>
                <div className="text-sm text-muted-foreground">{recommendedHospital.hospital.address}</div>
                <div className="flex gap-4 mt-2 text-sm">
                  <span className="text-emerald-400">ETA: {recommendedHospital.estimatedArrival} min</span>
                  <span className="text-muted-foreground">Beds: {recommendedHospital.hospital.availableBeds}</span>
                </div>
              </div>
            )}

            {/* Status Update Buttons */}
            <div className="flex flex-wrap gap-3">
              {currentRequest.status === 'assigned' && (
                <Button onClick={() => handleStatusUpdate('en_route_to_victim')} className="bg-blue-500 hover:bg-blue-600">
                  Start Navigation to Victim
                </Button>
              )}
              {currentRequest.status === 'en_route_to_victim' && (
                <Button onClick={() => handleStatusUpdate('picked_up')} className="bg-indigo-500 hover:bg-indigo-600">
                  Patient Picked Up
                </Button>
              )}
              {currentRequest.status === 'picked_up' && (
                <Button onClick={() => handleStatusUpdate('en_route_to_hospital')} className="bg-purple-500 hover:bg-purple-600">
                  En Route to Hospital
                </Button>
              )}
              {currentRequest.status === 'en_route_to_hospital' && (
                <Button onClick={() => handleStatusUpdate('completed')} className="bg-emerald-500 hover:bg-emerald-600">
                  Complete Emergency
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Map */}
        <Card className="glass-card border-0 lg:col-span-2 overflow-hidden">
          <LiveMap
            ambulances={[{ ...ambulance, location: currentLocation }]}
            hospitals={hospitals}
            trafficSignals={trafficSignals}
            victimLocation={currentRequest?.location}
            selectedHospital={recommendedHospital?.hospital as Hospital | undefined}
            showRoute={!!currentRequest}
            ambulanceOnRoute={{ ...ambulance, location: currentLocation }}
            className="h-[400px]"
          />
        </Card>

        {/* Pending Requests */}
        <Card className="glass-card border-0">
          <CardHeader>
            <CardTitle className="text-foreground flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse" />
              Incoming Requests
            </CardTitle>
            <CardDescription>{pendingRequests.length} pending</CardDescription>
          </CardHeader>
          <CardContent>
            {!isOnline ? (
              <div className="text-center py-8 text-muted-foreground">Go online to receive requests</div>
            ) : pendingRequests.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No pending requests</div>
            ) : (
              <div className="space-y-3 max-h-[300px] overflow-y-auto">
                {pendingRequests.map((request) => (
                  <div key={request.id} className="p-4 rounded-xl bg-yellow-500/10 border border-yellow-500/30">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <div className="font-semibold text-foreground">{request.victimName}</div>
                        <div className="text-sm text-muted-foreground capitalize">{request.emergencyType.replace('_', ' ')}</div>
                      </div>
                      <Badge className="bg-yellow-500/20 text-yellow-400">New</Badge>
                    </div>
                    <div className="text-xs text-muted-foreground mb-3">
                      {new Date(request.createdAt).toLocaleTimeString()}
                    </div>
                    <Button
                      size="sm"
                      onClick={() => handleAcceptRequest(request)}
                      disabled={!!currentRequest}
                      className="w-full bg-gradient-to-r from-primary to-orange-500 hover:opacity-90"
                    >
                      Accept Emergency
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
