'use client'

import React from "react"

import { useEffect, useRef, useState, useCallback } from 'react'
import type { Location, Ambulance, TrafficSignal, Hospital } from '@/lib/types'

interface MapMarker {
  id: string
  location: Location
  type: 'victim' | 'ambulance' | 'hospital' | 'traffic_signal'
  label?: string
  status?: string
}

interface MapViewProps {
  center?: Location
  zoom?: number
  markers?: MapMarker[]
  showRoute?: boolean
  origin?: Location
  destination?: Location
  ambulances?: Ambulance[]
  trafficSignals?: TrafficSignal[]
  hospitals?: Hospital[]
  victimLocation?: Location
  onMapClick?: (location: Location) => void
  className?: string
}

// Marker colors
const markerColors = {
  victim: '#dc2626', // red
  ambulance: '#2563eb', // blue
  hospital: '#16a34a', // green
  traffic_signal: '#eab308', // yellow
}

// Marker icons as SVG
const MarkerIcon = ({ type, status }: { type: string; status?: string }) => {
  const color = markerColors[type as keyof typeof markerColors] || '#6b7280'
  const isGreen = status === 'green'
  
  if (type === 'traffic_signal') {
    return (
      <div className={`w-4 h-4 rounded-full border-2 border-foreground/20 ${isGreen ? 'bg-green-500' : 'bg-red-500'}`} />
    )
  }
  
  if (type === 'ambulance') {
    return (
      <div className="flex items-center justify-center w-8 h-8 bg-blue-600 rounded-full text-white text-xs font-bold shadow-lg">
        AMB
      </div>
    )
  }
  
  if (type === 'hospital') {
    return (
      <div className="flex items-center justify-center w-8 h-8 bg-green-600 rounded-full text-white text-xs font-bold shadow-lg">
        H
      </div>
    )
  }
  
  if (type === 'victim') {
    return (
      <div className="flex items-center justify-center w-8 h-8 bg-red-600 rounded-full text-white text-xs font-bold shadow-lg animate-pulse">
        SOS
      </div>
    )
  }
  
  return <div className="w-4 h-4 rounded-full" style={{ backgroundColor: color }} />
}

export function MapView({
  center = { lat: 28.6139, lng: 77.2090 },
  zoom = 13,
  markers = [],
  ambulances = [],
  trafficSignals = [],
  hospitals = [],
  victimLocation,
  onMapClick,
  className = '',
}: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null)
  const [mapCenter, setMapCenter] = useState(center)
  const [isDragging, setIsDragging] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [offset, setOffset] = useState({ x: 0, y: 0 })

  // Convert lat/lng to pixel position (simplified Mercator projection)
  const latLngToPixel = useCallback((location: Location, containerSize: { width: number; height: number }) => {
    const scale = Math.pow(2, zoom) * 0.5
    const centerX = containerSize.width / 2
    const centerY = containerSize.height / 2
    
    const x = centerX + (location.lng - mapCenter.lng) * scale * 100 + offset.x
    const y = centerY - (location.lat - mapCenter.lat) * scale * 100 + offset.y
    
    return { x, y }
  }, [mapCenter, zoom, offset])

  // Handle map click
  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!onMapClick || !mapRef.current) return
    
    const rect = mapRef.current.getBoundingClientRect()
    const x = e.clientX - rect.left
    const y = e.clientY - rect.top
    
    const scale = Math.pow(2, zoom) * 0.5
    const lng = mapCenter.lng + (x - rect.width / 2 - offset.x) / (scale * 100)
    const lat = mapCenter.lat - (y - rect.height / 2 - offset.y) / (scale * 100)
    
    onMapClick({ lat, lng })
  }

  // Handle drag
  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    setDragStart({ x: e.clientX - offset.x, y: e.clientY - offset.y })
  }

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return
    setOffset({
      x: e.clientX - dragStart.x,
      y: e.clientY - dragStart.y,
    })
  }

  const handleMouseUp = () => {
    setIsDragging(false)
  }

  // Combine all markers
  const allMarkers: MapMarker[] = [
    ...markers,
    ...ambulances.map((a) => ({
      id: a.id,
      location: a.location,
      type: 'ambulance' as const,
      label: a.vehicleNumber,
      status: a.isAvailable ? 'available' : 'busy',
    })),
    ...trafficSignals.map((s) => ({
      id: s.id,
      location: s.location,
      type: 'traffic_signal' as const,
      label: s.name,
      status: s.currentStatus,
    })),
    ...hospitals.map((h) => ({
      id: h.id,
      location: h.location,
      type: 'hospital' as const,
      label: h.name,
    })),
  ]

  if (victimLocation) {
    allMarkers.push({
      id: 'victim',
      location: victimLocation,
      type: 'victim',
      label: 'Emergency Location',
    })
  }

  return (
    <div
      ref={mapRef}
      className={`relative overflow-hidden bg-secondary/30 rounded-lg border border-border ${className}`}
      style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
      onClick={handleMapClick}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Grid overlay to simulate map tiles */}
      <div className="absolute inset-0 opacity-20">
        <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
              <path d="M 50 0 L 0 0 0 50" fill="none" stroke="currentColor" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      {/* Simulated roads */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/2 left-0 right-0 h-1 bg-muted-foreground transform -translate-y-1/2" />
        <div className="absolute top-0 bottom-0 left-1/2 w-1 bg-muted-foreground transform -translate-x-1/2" />
        <div className="absolute top-1/4 left-0 right-0 h-0.5 bg-muted-foreground/50" />
        <div className="absolute top-3/4 left-0 right-0 h-0.5 bg-muted-foreground/50" />
        <div className="absolute top-0 bottom-0 left-1/4 w-0.5 bg-muted-foreground/50" />
        <div className="absolute top-0 bottom-0 left-3/4 w-0.5 bg-muted-foreground/50" />
      </div>

      {/* Markers */}
      {mapRef.current && allMarkers.map((marker) => {
        const containerSize = {
          width: mapRef.current?.offsetWidth || 400,
          height: mapRef.current?.offsetHeight || 300,
        }
        const pos = latLngToPixel(marker.location, containerSize)
        
        // Only render if within bounds
        if (pos.x < -50 || pos.x > containerSize.width + 50 || pos.y < -50 || pos.y > containerSize.height + 50) {
          return null
        }
        
        return (
          <div
            key={marker.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
            style={{ left: pos.x, top: pos.y, zIndex: marker.type === 'victim' ? 100 : 10 }}
          >
            <div className="relative group">
              <MarkerIcon type={marker.type} status={marker.status} />
              {marker.label && (
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-1 px-2 py-1 bg-card text-card-foreground text-xs rounded shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                  {marker.label}
                </div>
              )}
            </div>
          </div>
        )
      })}

      {/* Map attribution */}
      <div className="absolute bottom-2 right-2 text-xs text-muted-foreground bg-background/80 px-2 py-1 rounded">
        Smart Ambulance Map
      </div>

      {/* Zoom controls */}
      <div className="absolute top-2 right-2 flex flex-col gap-1">
        <button
          type="button"
          className="w-8 h-8 bg-card text-card-foreground rounded shadow flex items-center justify-center hover:bg-secondary transition-colors"
          onClick={(e) => {
            e.stopPropagation()
            setOffset({ x: 0, y: 0 })
          }}
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
      </div>

      {/* Legend */}
      <div className="absolute bottom-2 left-2 bg-card/90 backdrop-blur-sm rounded-lg p-2 text-xs">
        <div className="flex flex-col gap-1">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-600" />
            <span className="text-card-foreground">Emergency</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-600" />
            <span className="text-card-foreground">Ambulance</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-600" />
            <span className="text-card-foreground">Hospital</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <span className="text-card-foreground">Signal</span>
          </div>
        </div>
      </div>
    </div>
  )
}
