'use client'

import React, { useEffect, useRef, useState, useCallback } from 'react'
import type { Location, Ambulance, Hospital, TrafficSignal } from '@/lib/types'

interface LiveMapProps {
  center?: Location
  ambulances?: Ambulance[]
  hospitals?: Hospital[]
  trafficSignals?: TrafficSignal[]
  victimLocation?: Location
  selectedHospital?: Hospital
  showRoute?: boolean
  ambulanceOnRoute?: Ambulance
  className?: string
  onHospitalClick?: (hospital: Hospital) => void
}

// SVG path for smooth curve between two points
function createCurvePath(from: { x: number; y: number }, to: { x: number; y: number }): string {
  const midX = (from.x + to.x) / 2
  const midY = (from.y + to.y) / 2 - 30
  return `M ${from.x} ${from.y} Q ${midX} ${midY} ${to.x} ${to.y}`
}

export function LiveMap({
  center = { lat: 28.6139, lng: 77.209 },
  ambulances = [],
  hospitals = [],
  trafficSignals = [],
  victimLocation,
  selectedHospital,
  showRoute = false,
  ambulanceOnRoute,
  className = '',
  onHospitalClick,
}: LiveMapProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [dimensions, setDimensions] = useState({ width: 800, height: 500 })
  const [hoveredHospital, setHoveredHospital] = useState<string | null>(null)
  const [mapOffset, setMapOffset] = useState({ x: 0, y: 0 })
  const [zoom] = useState(14)

  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.offsetWidth,
          height: containerRef.current.offsetHeight,
        })
      }
    }
    updateDimensions()
    window.addEventListener('resize', updateDimensions)
    return () => window.removeEventListener('resize', updateDimensions)
  }, [])

  const latLngToPixel = useCallback(
    (location: Location) => {
      const scale = Math.pow(2, zoom) * 0.5
      const centerX = dimensions.width / 2
      const centerY = dimensions.height / 2
      const x = centerX + (location.lng - center.lng) * scale * 100 + mapOffset.x
      const y = centerY - (location.lat - center.lat) * scale * 100 + mapOffset.y
      return { x, y }
    },
    [center, zoom, dimensions, mapOffset]
  )

  // Generate road network
  const roads = [
    // Main roads
    { from: { x: 0, y: dimensions.height * 0.3 }, to: { x: dimensions.width, y: dimensions.height * 0.3 } },
    { from: { x: 0, y: dimensions.height * 0.6 }, to: { x: dimensions.width, y: dimensions.height * 0.6 } },
    { from: { x: dimensions.width * 0.25, y: 0 }, to: { x: dimensions.width * 0.25, y: dimensions.height } },
    { from: { x: dimensions.width * 0.5, y: 0 }, to: { x: dimensions.width * 0.5, y: dimensions.height } },
    { from: { x: dimensions.width * 0.75, y: 0 }, to: { x: dimensions.width * 0.75, y: dimensions.height } },
    // Diagonal roads
    { from: { x: 0, y: 0 }, to: { x: dimensions.width * 0.5, y: dimensions.height * 0.5 } },
    { from: { x: dimensions.width, y: 0 }, to: { x: dimensions.width * 0.5, y: dimensions.height * 0.5 } },
  ]

  return (
    <div ref={containerRef} className={`relative overflow-hidden rounded-xl ${className}`}>
      {/* Background with grid */}
      <div className="absolute inset-0 bg-[#0a1628]">
        {/* Subtle grid pattern */}
        <svg className="absolute inset-0 w-full h-full opacity-20">
          <defs>
            <pattern id="mapGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#mapGrid)" />
        </svg>

        {/* Road network */}
        <svg className="absolute inset-0 w-full h-full">
          {roads.map((road, i) => (
            <line
              key={i}
              x1={road.from.x}
              y1={road.from.y}
              x2={road.to.x}
              y2={road.to.y}
              stroke="rgba(255,255,255,0.08)"
              strokeWidth="3"
            />
          ))}
          {/* Secondary roads */}
          {[0.1, 0.4, 0.7, 0.9].map((pos) => (
            <React.Fragment key={pos}>
              <line
                x1={0}
                y1={dimensions.height * pos}
                x2={dimensions.width}
                y2={dimensions.height * pos}
                stroke="rgba(255,255,255,0.04)"
                strokeWidth="1"
              />
              <line
                x1={dimensions.width * pos}
                y1={0}
                x2={dimensions.width * pos}
                y2={dimensions.height}
                stroke="rgba(255,255,255,0.04)"
                strokeWidth="1"
              />
            </React.Fragment>
          ))}
        </svg>
      </div>

      {/* Route visualization */}
      {showRoute && victimLocation && selectedHospital && (
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <defs>
            <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="hsl(14, 100%, 57%)" />
              <stop offset="100%" stopColor="hsl(166, 76%, 45%)" />
            </linearGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="3" result="coloredBlur" />
              <feMerge>
                <feMergeNode in="coloredBlur" />
                <feMergeNode in="SourceGraphic" />
              </feMerge>
            </filter>
          </defs>
          {/* Route line with glow */}
          <path
            d={createCurvePath(latLngToPixel(victimLocation), latLngToPixel(selectedHospital.location))}
            fill="none"
            stroke="url(#routeGradient)"
            strokeWidth="4"
            strokeDasharray="10 5"
            className="animate-route-dash"
            filter="url(#glow)"
          />
          {/* Solid background line */}
          <path
            d={createCurvePath(latLngToPixel(victimLocation), latLngToPixel(selectedHospital.location))}
            fill="none"
            stroke="rgba(255,255,255,0.1)"
            strokeWidth="8"
          />
        </svg>
      )}

      {/* Ambulance route to victim */}
      {showRoute && victimLocation && ambulanceOnRoute && (
        <svg className="absolute inset-0 w-full h-full pointer-events-none">
          <path
            d={createCurvePath(latLngToPixel(ambulanceOnRoute.location), latLngToPixel(victimLocation))}
            fill="none"
            stroke="hsl(217, 91%, 60%)"
            strokeWidth="3"
            strokeDasharray="8 4"
            className="animate-route-dash"
            filter="url(#glow)"
          />
        </svg>
      )}

      {/* Traffic Signals */}
      {trafficSignals.map((signal) => {
        const pos = latLngToPixel(signal.location)
        if (pos.x < -20 || pos.x > dimensions.width + 20 || pos.y < -20 || pos.y > dimensions.height + 20) return null
        return (
          <div
            key={signal.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
            style={{ left: pos.x, top: pos.y, zIndex: 5 }}
          >
            <div
              className={`w-3 h-3 rounded-full border border-white/20 transition-colors duration-500 ${
                signal.currentStatus === 'green' ? 'bg-green-500 shadow-lg shadow-green-500/50' : 'bg-red-500'
              }`}
            />
          </div>
        )
      })}

      {/* Hospitals */}
      {hospitals.map((hospital) => {
        const pos = latLngToPixel(hospital.location)
        if (pos.x < -50 || pos.x > dimensions.width + 50 || pos.y < -50 || pos.y > dimensions.height + 50) return null
        const isSelected = selectedHospital?.id === hospital.id
        const isHovered = hoveredHospital === hospital.id
        return (
          <div
            key={hospital.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 cursor-pointer"
            style={{ left: pos.x, top: pos.y, zIndex: isSelected || isHovered ? 30 : 10 }}
            onMouseEnter={() => setHoveredHospital(hospital.id)}
            onMouseLeave={() => setHoveredHospital(null)}
            onClick={() => onHospitalClick?.(hospital)}
          >
            <div className="relative group">
              {/* Hospital marker */}
              <div
                className={`relative flex items-center justify-center transition-all duration-300 ${
                  isSelected
                    ? 'w-14 h-14 bg-gradient-to-br from-emerald-500 to-emerald-600 shadow-lg shadow-emerald-500/40'
                    : 'w-10 h-10 bg-gradient-to-br from-emerald-500/80 to-emerald-600/80 hover:from-emerald-500 hover:to-emerald-600'
                } rounded-xl`}
              >
                <svg
                  className={`${isSelected ? 'w-7 h-7' : 'w-5 h-5'} text-white`}
                  fill="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-1 11h-4v4h-4v-4H6v-4h4V6h4v4h4v4z" />
                </svg>
                {/* Bed availability indicator */}
                <div
                  className={`absolute -top-1 -right-1 w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center ${
                    hospital.availableBeds > 10
                      ? 'bg-green-500'
                      : hospital.availableBeds > 0
                        ? 'bg-yellow-500'
                        : 'bg-red-500'
                  } text-white`}
                >
                  {hospital.availableBeds}
                </div>
              </div>

              {/* Hospital info popup */}
              {(isHovered || isSelected) && (
                <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 w-64 glass-card rounded-lg p-3 shadow-xl z-50">
                  <div className="font-semibold text-foreground text-sm">{hospital.name}</div>
                  <div className="text-xs text-muted-foreground mt-1">{hospital.address}</div>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    <div className="text-xs">
                      <span className="text-muted-foreground">Beds:</span>
                      <span className="ml-1 text-emerald-400 font-medium">{hospital.availableBeds}</span>
                    </div>
                    <div className="text-xs">
                      <span className="text-muted-foreground">ICU:</span>
                      <span className="ml-1 text-emerald-400 font-medium">{hospital.availableIcuBeds}</span>
                    </div>
                    <div className="text-xs">
                      <span className="text-muted-foreground">Rating:</span>
                      <span className="ml-1 text-yellow-400 font-medium">{hospital.rating}/5</span>
                    </div>
                    <div className="text-xs">
                      <span className="text-muted-foreground">Phone:</span>
                      <span className="ml-1 text-foreground">{hospital.phone}</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-2">
                    {hospital.specialties.slice(0, 3).map((spec) => (
                      <span key={spec} className="px-1.5 py-0.5 text-[10px] bg-secondary rounded text-foreground">
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        )
      })}

      {/* Ambulances */}
      {ambulances.map((ambulance) => {
        const pos = latLngToPixel(ambulance.location)
        if (pos.x < -50 || pos.x > dimensions.width + 50 || pos.y < -50 || pos.y > dimensions.height + 50) return null
        const isOnRoute = ambulanceOnRoute?.id === ambulance.id
        return (
          <div
            key={ambulance.id}
            className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-1000"
            style={{ left: pos.x, top: pos.y, zIndex: isOnRoute ? 40 : 20 }}
          >
            <div className="relative group">
              {/* Ambulance marker */}
              <div
                className={`relative flex items-center justify-center transition-all duration-300 ${
                  isOnRoute
                    ? 'w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 shadow-lg shadow-blue-500/50 animate-pulse'
                    : ambulance.isAvailable
                      ? 'w-10 h-10 bg-gradient-to-br from-blue-500/80 to-blue-600/80'
                      : 'w-10 h-10 bg-gradient-to-br from-gray-500/80 to-gray-600/80'
                } rounded-xl`}
              >
                <svg
                  className={`${isOnRoute ? 'w-7 h-7' : 'w-5 h-5'} text-white`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 10V3L4 14h7v7l9-11h-7z"
                  />
                </svg>
              </div>
              {/* Vehicle number tooltip */}
              <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-1 px-2 py-1 bg-card text-card-foreground text-xs rounded shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                {ambulance.vehicleNumber}
                {ambulance.isAvailable ? (
                  <span className="ml-1 text-green-400">Available</span>
                ) : (
                  <span className="ml-1 text-yellow-400">On Call</span>
                )}
              </div>
            </div>
          </div>
        )
      })}

      {/* Victim location */}
      {victimLocation && (
        <div
          className="absolute transform -translate-x-1/2 -translate-y-1/2"
          style={{ ...latLngToPixel(victimLocation), zIndex: 50 }}
        >
          <div className="relative">
            {/* Pulsing rings */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-20 h-20 rounded-full bg-red-500/20 animate-ping" />
            </div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-16 h-16 rounded-full bg-red-500/30 animate-pulse" />
            </div>
            {/* Main marker */}
            <div className="relative w-12 h-12 bg-gradient-to-br from-red-500 to-red-600 rounded-full flex items-center justify-center shadow-lg shadow-red-500/50 animate-pulse-glow">
              <span className="text-white font-bold text-sm">SOS</span>
            </div>
          </div>
        </div>
      )}

      {/* Legend */}
      <div className="absolute bottom-4 left-4 glass-card rounded-lg p-3 z-40">
        <div className="text-xs font-medium text-foreground mb-2">Map Legend</div>
        <div className="flex flex-col gap-1.5">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-lg bg-gradient-to-br from-red-500 to-red-600" />
            <span className="text-xs text-muted-foreground">Emergency</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600" />
            <span className="text-xs text-muted-foreground">Ambulance</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-600" />
            <span className="text-xs text-muted-foreground">Hospital</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500" />
            <span className="text-xs text-muted-foreground">Green Signal</span>
          </div>
        </div>
      </div>

      {/* Map controls */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 z-40">
        <button
          type="button"
          onClick={() => setMapOffset({ x: 0, y: 0 })}
          className="w-10 h-10 glass-card rounded-lg flex items-center justify-center hover:bg-white/10 transition-colors"
        >
          <svg className="w-5 h-5 text-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"
            />
          </svg>
        </button>
      </div>
    </div>
  )
}
