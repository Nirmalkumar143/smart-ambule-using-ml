'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { MapView } from './map-view'
import type { EmergencyRequest, HospitalRecommendation } from '@/lib/types'

interface RequestStatusProps {
  request: EmergencyRequest
  ambulance?: {
    id: string
    vehicleNumber: string
    driverName: string
    location?: { lat: number; lng: number }
  }
  hospital?: HospitalRecommendation
  onCancel?: () => void
}

const statusConfig: Record<string, { label: string; color: string; description: string }> = {
  pending: {
    label: 'Pending',
    color: 'bg-yellow-500 text-white',
    description: 'Finding the nearest ambulance...',
  },
  assigned: {
    label: 'Assigned',
    color: 'bg-blue-500 text-white',
    description: 'Ambulance assigned and driver notified',
  },
  en_route_to_victim: {
    label: 'On The Way',
    color: 'bg-orange-500 text-white',
    description: 'Ambulance is heading to your location',
  },
  picked_up: {
    label: 'Picked Up',
    color: 'bg-blue-600 text-white',
    description: 'Patient picked up, heading to hospital',
  },
  en_route_to_hospital: {
    label: 'To Hospital',
    color: 'bg-indigo-500 text-white',
    description: 'En route to hospital with green corridor',
  },
  completed: {
    label: 'Completed',
    color: 'bg-green-500 text-white',
    description: 'Emergency response completed',
  },
  cancelled: {
    label: 'Cancelled',
    color: 'bg-gray-500 text-white',
    description: 'Request has been cancelled',
  },
}

export function RequestStatus({ request, ambulance, hospital, onCancel }: RequestStatusProps) {
  const [eta, setEta] = useState(request.eta || 8)
  const status = statusConfig[request.status] || statusConfig.pending

  // Simulate ETA countdown
  useEffect(() => {
    if (request.status === 'en_route_to_victim' || request.status === 'assigned') {
      const interval = setInterval(() => {
        setEta((prev) => Math.max(1, prev - 0.1))
      }, 6000)
      return () => clearInterval(interval)
    }
  }, [request.status])

  return (
    <div className="space-y-4">
      {/* Status Card */}
      <Card className="border-2 border-primary/20">
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between">
            <CardTitle className="text-xl">Request Status</CardTitle>
            <Badge className={status.color}>{status.label}</Badge>
          </div>
          <CardDescription>{status.description}</CardDescription>
        </CardHeader>
        <CardContent>
          {/* ETA Display */}
          {['pending', 'assigned', 'en_route_to_victim'].includes(request.status) && (
            <div className="text-center py-4 bg-secondary/30 rounded-lg mb-4">
              <div className="text-4xl font-bold text-primary">{Math.ceil(eta)}</div>
              <div className="text-sm text-muted-foreground">minutes estimated arrival</div>
            </div>
          )}

          {/* Progress Steps */}
          <div className="flex items-center justify-between mb-4">
            {['pending', 'assigned', 'en_route_to_victim', 'picked_up', 'completed'].map((step, index) => {
              const stepOrder = ['pending', 'assigned', 'en_route_to_victim', 'picked_up', 'en_route_to_hospital', 'completed']
              const currentIndex = stepOrder.indexOf(request.status)
              const stepIndex = stepOrder.indexOf(step)
              const isActive = stepIndex <= currentIndex
              
              return (
                <div key={step} className="flex items-center">
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                      isActive ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground'
                    }`}
                  >
                    {index + 1}
                  </div>
                  {index < 4 && (
                    <div
                      className={`w-8 h-1 ${
                        stepIndex < currentIndex ? 'bg-primary' : 'bg-muted'
                      }`}
                    />
                  )}
                </div>
              )
            })}
          </div>

          {/* Request Details */}
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-muted-foreground">Request ID</div>
              <div className="font-medium">{request.id.substring(0, 8).toUpperCase()}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Emergency Type</div>
              <div className="font-medium capitalize">{request.emergencyType.replace('_', ' ')}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Created At</div>
              <div className="font-medium">
                {new Date(request.createdAt).toLocaleTimeString()}
              </div>
            </div>
            <div>
              <div className="text-muted-foreground">Location</div>
              <div className="font-medium">
                {request.location.lat.toFixed(4)}, {request.location.lng.toFixed(4)}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Ambulance Info */}
      {ambulance && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Assigned Ambulance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <div className="font-semibold text-lg">{ambulance.vehicleNumber}</div>
                <div className="text-muted-foreground">Driver: {ambulance.driverName}</div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Hospital Info */}
      {hospital && (
        <Card className="border-green-200 bg-green-50/50">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg text-green-700">Recommended Hospital</CardTitle>
            <CardDescription>Selected by ML based on availability, distance & specialty</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="font-semibold text-lg">{hospital.hospital.name}</div>
              <div className="text-sm text-muted-foreground">{hospital.hospital.address}</div>
              <div className="flex flex-wrap gap-2 mt-2">
                {hospital.reasons.map((reason, i) => (
                  <Badge key={i} variant="secondary" className="bg-green-100 text-green-700">
                    {reason}
                  </Badge>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-4 mt-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-600">{hospital.hospital.distance}</div>
                  <div className="text-xs text-muted-foreground">km away</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">{hospital.hospital.availableBeds}</div>
                  <div className="text-xs text-muted-foreground">beds available</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">{hospital.score}</div>
                  <div className="text-xs text-muted-foreground">ML score</div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Map View */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-lg">Live Tracking</CardTitle>
        </CardHeader>
        <CardContent>
          <MapView
            center={request.location}
            victimLocation={request.location}
            ambulances={ambulance?.location ? [{
              id: ambulance.id,
              vehicleNumber: ambulance.vehicleNumber,
              driverId: '',
              driverName: ambulance.driverName,
              location: ambulance.location,
              isAvailable: false,
              equipment: [],
              lastUpdated: new Date(),
            }] : []}
            hospitals={hospital ? [hospital.hospital] : []}
            className="h-64"
          />
        </CardContent>
      </Card>

      {/* Cancel Button */}
      {['pending', 'assigned'].includes(request.status) && onCancel && (
        <Button
          variant="outline"
          className="w-full border-destructive text-destructive hover:bg-destructive/10 bg-transparent"
          onClick={onCancel}
        >
          Cancel Request
        </Button>
      )}
    </div>
  )
}
